package com.visionaid.ai

/**
 * Placeholder establishing the "ai" module boundary in Phase 1.
 *
 * Purpose: Houses the AI tool interfaces (ObjectDetectionTool, OCRTool, etc.) defined starting Phase 2. Depends on core only.
 *
 * INTENTIONALLY EMPTY OF LOGIC. This module exists so that:
 *  1. Its Gradle dependency boundary is fixed early (other modules depend on
 *     this modules public API surface, not its internals).
 *  2. Later phases add real classes here without needing to restructure the
 *     project or touch unrelated modules.
 *
 * Do not add AI models, camera code, or business logic here during Phase 1 --
 * that is explicitly out of scope per the Phase 1 spec in
 * Vision_Aid_Glasses_Master_Roadmap.md.
 */
object AiModulePlaceholder {
    const val MODULE_NAME = "ai"
}
