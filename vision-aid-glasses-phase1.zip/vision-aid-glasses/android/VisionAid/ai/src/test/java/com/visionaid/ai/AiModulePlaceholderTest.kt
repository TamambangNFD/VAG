package com.visionaid.ai

import org.junit.Assert.assertEquals
import org.junit.Test

class AiModulePlaceholderTest {
    @Test
    fun `module name is correct`() {
        assertEquals("ai", AiModulePlaceholder.MODULE_NAME)
    }
}
