package com.visionaid.ai.currency

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Identifies banknote/coin denomination. Initial target: Cameroon CFA franc
 * (XAF), per roadmap Phase 10 and Section 0.5. Designed so additional
 * currencies can be added without changing this interface.
 *
 * PHASE 10 CHANGE: [CurrencyCode] was a closed `enum class` with only XAF
 * as a member — adding any future currency would have required editing
 * this shared interface file every time. Changed to an open value type
 * (ISO 4217 code as a plain string) so a new currency is just a new
 * reference-embedding data file (see MODEL_REGISTRY.md), never a code
 * change here. `CurrencyCode.XAF` still works exactly as before at every
 * existing call site.
 *
 * Input contract: a [FrameContext].
 * Output contract: [CurrencyOutput] — a [Denomination] or, when confidence
 * is insufficient or the image quality is too poor to judge, an explicit
 * unknown result. A low-confidence result must never be reported as
 * certain (roadmap: "Never state a low-confidence result as certain").
 *
 * Offline capability: OFFLINE_ONLY.
 */
interface CurrencyRecognitionTool {

    val operationMode: OperationMode

    fun availability(): ToolAvailability

    suspend fun recognizeCurrency(frame: FrameContext): ToolResult<CurrencyOutput>
}

data class CurrencyOutput(
    val denomination: Denomination?,
    val currency: CurrencyCode,
    val imageQualitySufficient: Boolean
)

/** Open ISO-4217-style currency code — see interface KDoc for why this isn't a closed enum. */
data class CurrencyCode(val isoCode: String) {
    companion object {
        val XAF = CurrencyCode("XAF") // Cameroon / CEMAC Central African CFA franc
    }
}

data class Denomination(
    val currency: CurrencyCode,
    val value: Int,
    val isCoin: Boolean
)
