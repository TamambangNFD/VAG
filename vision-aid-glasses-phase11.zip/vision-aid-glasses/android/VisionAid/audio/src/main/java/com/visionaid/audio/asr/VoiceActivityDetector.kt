package com.visionaid.audio.asr

/**
 * Frame-level voice activity detection. Pure, Android-independent — no
 * dependency on `AudioRecord` or any platform audio API — so it's fully
 * unit-testable with synthetic PCM sample arrays.
 *
 * HONEST LIMITATION: this is simple energy-based (RMS) VAD, not a neural
 * VAD (e.g. WebRTC VAD or Silero VAD), which would better distinguish
 * speech from non-speech noise (wind, traffic, music) at similar volume.
 * Energy-based VAD is a standard, legitimate baseline technique — cheap,
 * dependency-free, and fine for a "loud enough to be speech" gate — but it
 * WILL treat any sufficiently loud sound as speech, not just human voice.
 * Documented here rather than silently assumed to be more capable than it
 * is, consistent with this project's other documented simplifications
 * (Phase 4's greedy tracker, Phase 5's monocular depth, Phase 8's document
 * edge detection).
 */
object VoiceActivityDetector {

    /** RMS energy (of 16-bit PCM samples, so up to ~32767) above this is treated as speech. */
    const val DEFAULT_ENERGY_THRESHOLD = 500.0

    fun isSpeech(frame: ShortArray, threshold: Double = DEFAULT_ENERGY_THRESHOLD): Boolean {
        if (frame.isEmpty()) return false
        return rmsEnergy(frame) >= threshold
    }

    fun rmsEnergy(frame: ShortArray): Double {
        if (frame.isEmpty()) return 0.0
        var sumSquares = 0.0
        for (sample in frame) {
            sumSquares += sample.toDouble() * sample.toDouble()
        }
        return kotlin.math.sqrt(sumSquares / frame.size)
    }
}
