package com.visionaid.audio.asr

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.LocaleTag
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolError
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.speech.SpeechRecognitionOutput
import com.visionaid.ai.speech.SpeechRecognitionTool

/**
 * Real implementation of Phase 2's [SpeechRecognitionTool], using
 * [WhisperCppEngine]. [audioData] is expected to be little-endian 16-bit
 * PCM bytes at 16kHz mono — exactly what [UtteranceSegmenter] /
 * [MicrophoneAudioSource] produce, keeping the microphone-capture and
 * transcription pieces cleanly separated (mirrors the camera pipeline's
 * `CameraFrameSource` -> `ObjectDetectionTool` separation from Phase 3).
 */
class RealSpeechRecognitionTool(private val engine: WhisperCppEngine) : SpeechRecognitionTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    override fun availability(): ToolAvailability =
        if (engine.isAvailable()) ToolAvailability.AVAILABLE else ToolAvailability.UNAVAILABLE_MODEL_NOT_LOADED

    override suspend fun transcribe(
        audioData: ByteArray,
        locale: LocaleTag
    ): ToolResult<SpeechRecognitionOutput> {
        val timestamp = System.currentTimeMillis()

        if (!engine.isAvailable()) {
            return ToolResult.Failure(ToolError.ModelNotLoaded, timestamp)
        }
        if (audioData.isEmpty()) {
            return ToolResult.Failure(ToolError.NoInputProvided, timestamp)
        }

        val pcmSamples = bytesToShorts(audioData)
        val transcript = engine.transcribe(pcmSamples, locale)
            ?: return ToolResult.Failure(ToolError.InternalError("Whisper transcription failed"), timestamp)

        if (transcript.isBlank()) {
            // Silence/noise that passed the VAD gate but produced no
            // recognizable speech — a valid "nothing understood" outcome,
            // not an error.
            return ToolResult.Success(
                data = SpeechRecognitionOutput(transcript = "", locale = locale),
                confidence = Confidence.unknown(),
                timestampMillis = timestamp
            )
        }

        return ToolResult.Success(
            data = SpeechRecognitionOutput(transcript = transcript.trim(), locale = locale),
            confidence = Confidence.of(ConfidenceLevel.MEDIUM), // whisper.cpp doesn't expose a calibrated confidence score via this simple API
            timestampMillis = timestamp
        )
    }

    private fun bytesToShorts(bytes: ByteArray): ShortArray {
        val shorts = ShortArray(bytes.size / 2)
        for (i in shorts.indices) {
            val low = bytes[i * 2].toInt() and 0xFF
            val high = bytes[i * 2 + 1].toInt()
            shorts[i] = ((high shl 8) or low).toShort()
        }
        return shorts
    }
}
