package com.visionaid.audio.asr

import android.Manifest
import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.annotation.RequiresPermission
import com.visionaid.core.logging.VisionAidLogger
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Wraps `AudioRecord` to capture 16kHz mono 16-bit PCM from the microphone
 * — the exact format whisper.cpp expects — and feeds frames into an
 * [UtteranceSegmenter], invoking a callback with each completed utterance's
 * raw PCM bytes.
 *
 * Kept separate from [UtteranceSegmenter] (which is pure and testable) so
 * this class is the only piece that actually needs `AudioRecord` and a real
 * device/emulator to exercise.
 */
class MicrophoneAudioSource(
    private val segmenter: UtteranceSegmenter = UtteranceSegmenter()
) {
    private val isRecording = AtomicBoolean(false)
    private val executor = Executors.newSingleThreadExecutor()
    private var audioRecord: AudioRecord? = null

    @SuppressLint("MissingPermission")
    @RequiresPermission(Manifest.permission.RECORD_AUDIO)
    fun start(onUtteranceComplete: (ByteArray) -> Unit) {
        if (isRecording.get()) return

        val minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE_HZ, CHANNEL_CONFIG, AUDIO_FORMAT)
        if (minBufferSize <= 0) {
            VisionAidLogger.e(TAG, "AudioRecord.getMinBufferSize returned invalid size: $minBufferSize")
            return
        }

        val record = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE_HZ,
            CHANNEL_CONFIG,
            AUDIO_FORMAT,
            minBufferSize * 2
        )

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            VisionAidLogger.e(TAG, "AudioRecord failed to initialize")
            record.release()
            return
        }

        audioRecord = record
        isRecording.set(true)
        record.startRecording()

        executor.execute {
            val frame = ShortArray(FRAME_SIZE_SAMPLES)
            while (isRecording.get()) {
                val read = record.read(frame, 0, frame.size)
                if (read > 0) {
                    val exact = if (read == frame.size) frame else frame.copyOf(read)
                    segmenter.addFrame(exact)?.let { completedUtterance ->
                        onUtteranceComplete(completedUtterance)
                    }
                }
            }
        }

        VisionAidLogger.i(TAG, "Microphone capture started (${SAMPLE_RATE_HZ}Hz mono PCM16)")
    }

    fun stop() {
        if (!isRecording.compareAndSet(true, false)) return
        segmenter.flush()
        audioRecord?.apply {
            stop()
            release()
        }
        audioRecord = null
        VisionAidLogger.i(TAG, "Microphone capture stopped")
    }

    companion object {
        private const val TAG = "MicrophoneAudioSource"
        const val SAMPLE_RATE_HZ = 16000 // whisper.cpp's expected input rate
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val FRAME_SIZE_SAMPLES = 480 // 30ms at 16kHz — a common VAD frame size
    }
}
