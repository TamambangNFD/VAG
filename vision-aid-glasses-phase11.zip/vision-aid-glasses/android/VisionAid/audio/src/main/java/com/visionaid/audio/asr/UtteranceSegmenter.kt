package com.visionaid.audio.asr

import java.io.ByteArrayOutputStream

/**
 * Stateful utterance boundary detection: buffers incoming audio frames
 * while [VoiceActivityDetector] reports speech, and finalizes ("closes")
 * the utterance after a configurable amount of trailing silence. Pure,
 * Android-independent (operates on plain `ShortArray` frames, not
 * `AudioRecord`) so it's fully unit-testable with a synthetic frame
 * sequence — the real microphone wiring is [MicrophoneAudioSource].
 *
 * A completed utterance is emitted as little-endian 16-bit PCM bytes,
 * matching what [com.visionaid.ai.speech.SpeechRecognitionTool.transcribe]
 * expects as its opaque `audioData` parameter.
 */
class UtteranceSegmenter(
    private val silenceFramesToEndUtterance: Int = 15,
    private val vadThreshold: Double = VoiceActivityDetector.DEFAULT_ENERGY_THRESHOLD
) {
    private val buffer = ByteArrayOutputStream()
    private var inUtterance = false
    private var consecutiveSilentFrames = 0

    /**
     * Feeds one frame of audio in. Returns the completed utterance's PCM
     * bytes if this frame ended one (enough trailing silence after speech
     * was detected), or null if the utterance is still in progress / no
     * speech has started yet.
     */
    fun addFrame(frame: ShortArray): ByteArray? {
        val isSpeech = VoiceActivityDetector.isSpeech(frame, vadThreshold)

        if (isSpeech) {
            inUtterance = true
            consecutiveSilentFrames = 0
            appendFrame(frame)
            return null
        }

        if (!inUtterance) {
            // Silence before any speech has started — nothing to do yet.
            return null
        }

        // We were in an utterance and this frame is silent.
        consecutiveSilentFrames++
        appendFrame(frame) // keep a little trailing silence for natural cadence
        if (consecutiveSilentFrames >= silenceFramesToEndUtterance) {
            return finalizeUtterance()
        }
        return null
    }

    /** Forces the current utterance (if any) to finalize, e.g. on explicit "stop listening." */
    fun flush(): ByteArray? {
        if (!inUtterance) return null
        return finalizeUtterance()
    }

    private fun finalizeUtterance(): ByteArray {
        val result = buffer.toByteArray()
        buffer.reset()
        inUtterance = false
        consecutiveSilentFrames = 0
        return result
    }

    private fun appendFrame(frame: ShortArray) {
        for (sample in frame) {
            buffer.write(sample.toInt() and 0xFF)
            buffer.write((sample.toInt() shr 8) and 0xFF)
        }
    }

    fun isInUtterance(): Boolean = inUtterance
}
