package com.visionaid.audio.asr

import android.content.Context
import com.visionaid.ai.common.LocaleTag
import com.visionaid.core.logging.VisionAidLogger
import java.io.File

/**
 * JNI bridge to whisper.cpp (MIT license, github.com/ggml-org/whisper.cpp —
 * a C/C++ port of OpenAI's Whisper ASR model, whose original weights are
 * also MIT licensed by OpenAI). See MODEL_REGISTRY.md for the full
 * provenance/license write-up and — importantly — for what this class
 * does NOT include.
 *
 * HONEST SCOPE NOTE: the `external fun` declarations below and the
 * `System.loadLibrary` call are real, standard Android JNI boilerplate.
 * What is NOT included in this repository is the native C++ side: the
 * actual whisper.cpp source tree, its `CMakeLists.txt`/NDK build
 * configuration, and the JNI glue C++ file implementing these native
 * methods. That is a real build-tooling task (cloning whisper.cpp as a
 * source dependency, wiring Android's `externalNativeBuild` Gradle config
 * to compile it via CMake/NDK) that requires an actual Android NDK
 * toolchain to author and verify correctly — not something safely
 * hand-written as unverified C++ in this sandbox. MODEL_REGISTRY.md
 * documents the exact integration steps to complete this. Until the native
 * library is built and present, [isAvailable] correctly reports false and
 * [transcribe] returns null rather than crashing on a missing native
 * method implementation.
 */
class WhisperCppEngine(private val context: Context) {

    private var nativeLibraryLoaded = false
    private var modelLoaded = false

    init {
        nativeLibraryLoaded = try {
            System.loadLibrary(NATIVE_LIBRARY_NAME)
            true
        } catch (e: UnsatisfiedLinkError) {
            VisionAidLogger.w(
                TAG,
                "Native library '$NATIVE_LIBRARY_NAME' not found — whisper.cpp has not been " +
                    "built into this app yet. See MODEL_REGISTRY.md for the required NDK/CMake " +
                    "integration steps. Speech recognition will report unavailable until then."
            )
            false
        }
    }

    fun isAvailable(): Boolean {
        if (!nativeLibraryLoaded) return false
        ensureModelLoaded()
        return modelLoaded
    }

    private fun ensureModelLoaded() {
        if (modelLoaded) return
        val modelFile = File(context.filesDir, MODEL_FILE_NAME)
        if (!modelFile.exists()) {
            copyModelFromAssetsIfPresent(modelFile)
        }
        if (!modelFile.exists()) {
            VisionAidLogger.w(
                TAG,
                "Whisper ggml model not found at ${modelFile.path} — supply " +
                    "$MODEL_FILE_NAME per MODEL_REGISTRY.md."
            )
            return
        }
        modelLoaded = try {
            nativeLoadModel(modelFile.absolutePath)
        } catch (e: UnsatisfiedLinkError) {
            VisionAidLogger.e(TAG, "Native nativeLoadModel implementation missing", e)
            false
        }
    }

    private fun copyModelFromAssetsIfPresent(destFile: File) {
        try {
            context.assets.open(MODEL_FILE_NAME).use { input ->
                destFile.outputStream().use { output -> input.copyTo(output) }
            }
        } catch (e: Exception) {
            // Expected until the model file is bundled — see MODEL_REGISTRY.md.
        }
    }

    fun transcribe(pcmAudio: ShortArray, locale: LocaleTag): String? {
        if (!isAvailable()) return null
        val languageCode = whisperLanguageCode(locale)
        return try {
            nativeTranscribe(pcmAudio, languageCode)
        } catch (e: UnsatisfiedLinkError) {
            VisionAidLogger.e(TAG, "Native nativeTranscribe implementation missing", e)
            null
        } catch (e: Exception) {
            VisionAidLogger.e(TAG, "Whisper transcription failed", e)
            null
        }
    }

    private fun whisperLanguageCode(locale: LocaleTag): String = when (locale) {
        LocaleTag.ENGLISH -> "en"
        LocaleTag.FRENCH -> "fr"
    }

    // --- JNI native method declarations ---
    // Real implementations live in a C++ file (not present in this repo yet)
    // compiled against the whisper.cpp source tree — see class KDoc and
    // MODEL_REGISTRY.md.
    private external fun nativeLoadModel(modelPath: String): Boolean
    private external fun nativeTranscribe(pcmAudio: ShortArray, languageCode: String): String?

    companion object {
        private const val TAG = "WhisperCppEngine"
        const val NATIVE_LIBRARY_NAME = "whisper_jni"
        const val MODEL_FILE_NAME = "ggml-base.bin"
    }
}
