package com.visionaid.audio.asr

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UtteranceSegmenterTest {

    private val loudFrame = ShortArray(480) { 10000 }
    private val silentFrame = ShortArray(480) { 0 }

    @Test
    fun `pure silence never starts or completes an utterance`() {
        val segmenter = UtteranceSegmenter(silenceFramesToEndUtterance = 3)
        repeat(10) {
            assertNull(segmenter.addFrame(silentFrame))
        }
        assertTrue(!segmenter.isInUtterance())
    }

    @Test
    fun `speech followed by enough silence completes the utterance`() {
        val segmenter = UtteranceSegmenter(silenceFramesToEndUtterance = 3)
        assertNull(segmenter.addFrame(loudFrame))
        assertTrue(segmenter.isInUtterance())

        assertNull(segmenter.addFrame(silentFrame)) // 1 silent frame
        assertNull(segmenter.addFrame(silentFrame)) // 2
        val result = segmenter.addFrame(silentFrame) // 3 -> should complete

        assertNotNull(result)
        assertTrue(!segmenter.isInUtterance())
    }

    @Test
    fun `brief silence within speech does not end the utterance early`() {
        val segmenter = UtteranceSegmenter(silenceFramesToEndUtterance = 5)
        segmenter.addFrame(loudFrame)
        segmenter.addFrame(silentFrame) // 1 silent frame, below threshold of 5
        segmenter.addFrame(silentFrame) // 2
        val result = segmenter.addFrame(loudFrame) // speech resumes — should reset silence counter

        assertNull(result)
        assertTrue(segmenter.isInUtterance())
    }

    @Test
    fun `completed utterance contains the expected number of PCM bytes`() {
        val segmenter = UtteranceSegmenter(silenceFramesToEndUtterance = 1)
        segmenter.addFrame(loudFrame) // 480 samples buffered
        val result = segmenter.addFrame(silentFrame) // +480 samples, then finalizes

        assertNotNull(result)
        assertEquals(960 * 2, result!!.size) // 2 bytes per 16-bit sample
    }

    @Test
    fun `flush finalizes an in-progress utterance`() {
        val segmenter = UtteranceSegmenter()
        segmenter.addFrame(loudFrame)
        assertTrue(segmenter.isInUtterance())

        val result = segmenter.flush()
        assertNotNull(result)
        assertTrue(!segmenter.isInUtterance())
    }

    @Test
    fun `flush with no active utterance returns null`() {
        val segmenter = UtteranceSegmenter()
        assertNull(segmenter.flush())
    }
}
