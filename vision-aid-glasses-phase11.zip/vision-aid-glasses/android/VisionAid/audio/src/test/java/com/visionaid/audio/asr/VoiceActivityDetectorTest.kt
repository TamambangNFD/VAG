package com.visionaid.audio.asr

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceActivityDetectorTest {

    @Test
    fun `loud frame is detected as speech`() {
        val loudFrame = ShortArray(480) { 10000 }
        assertTrue(VoiceActivityDetector.isSpeech(loudFrame))
    }

    @Test
    fun `silent frame is not detected as speech`() {
        val silentFrame = ShortArray(480) { 0 }
        assertFalse(VoiceActivityDetector.isSpeech(silentFrame))
    }

    @Test
    fun `quiet background noise below threshold is not speech`() {
        val quietFrame = ShortArray(480) { 50 }
        assertFalse(VoiceActivityDetector.isSpeech(quietFrame))
    }

    @Test
    fun `empty frame is not speech`() {
        assertFalse(VoiceActivityDetector.isSpeech(ShortArray(0)))
    }

    @Test
    fun `rmsEnergy of a constant-amplitude frame equals that amplitude`() {
        val frame = ShortArray(100) { 1000 }
        assertEquals(1000.0, VoiceActivityDetector.rmsEnergy(frame), 0.01)
    }

    @Test
    fun `custom threshold is respected`() {
        val frame = ShortArray(480) { 600 }
        assertTrue(VoiceActivityDetector.isSpeech(frame, threshold = 500.0))
        assertFalse(VoiceActivityDetector.isSpeech(frame, threshold = 700.0))
    }
}
