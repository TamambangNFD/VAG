package com.visionaid.vision.currency

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ImageQualityValidatorTest {

    @Test
    fun `high contrast image passes quality check`() {
        val grayValues = intArrayOf(10, 250, 20, 240, 5, 255) // wide range
        assertTrue(ImageQualityValidator.assessQuality(grayValues))
    }

    @Test
    fun `low contrast (blurry-blank-dark) image fails quality check`() {
        val grayValues = intArrayOf(100, 105, 102, 98, 101, 103) // narrow range
        assertFalse(ImageQualityValidator.assessQuality(grayValues))
    }

    @Test
    fun `empty input fails quality check rather than crashing`() {
        assertFalse(ImageQualityValidator.assessQuality(IntArray(0)))
    }

    @Test
    fun `contrast exactly at the threshold passes`() {
        val grayValues = intArrayOf(100, 100 + ImageQualityValidator.MIN_ACCEPTABLE_CONTRAST_RANGE)
        assertTrue(ImageQualityValidator.assessQuality(grayValues))
    }
}
