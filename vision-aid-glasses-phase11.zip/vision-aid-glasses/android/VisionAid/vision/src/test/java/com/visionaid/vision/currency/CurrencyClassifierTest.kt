package com.visionaid.vision.currency

import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.currency.CurrencyCode
import com.visionaid.ai.currency.Denomination
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CurrencyClassifierTest {

    private fun denom(value: Int) = Denomination(CurrencyCode.XAF, value, isCoin = false)

    @Test
    fun `matches the closest denomination above threshold`() {
        val query = floatArrayOf(1f, 0f, 0f)
        val references = mapOf(
            denom(500) to listOf(floatArrayOf(0f, 1f, 0f)),       // similarity 0
            denom(1000) to listOf(floatArrayOf(0.99f, 0.01f, 0f)) // similarity ~1
        )
        val result = CurrencyClassifier.classify(query, references)
        assertEquals(denom(1000), result?.denomination)
    }

    @Test
    fun `returns null when nothing clears the threshold`() {
        val query = floatArrayOf(1f, 0f, 0f)
        val references = mapOf(denom(500) to listOf(floatArrayOf(0f, 1f, 0f))) // orthogonal
        assertNull(CurrencyClassifier.classify(query, references))
    }

    @Test
    fun `returns null on empty reference set`() {
        assertNull(CurrencyClassifier.classify(floatArrayOf(1f, 0f), emptyMap()))
    }

    @Test
    fun `uses the best of multiple reference photos per denomination`() {
        val query = floatArrayOf(1f, 0f)
        val references = mapOf(
            denom(1000) to listOf(
                floatArrayOf(0f, 1f),   // similarity 0 — a bad reference photo
                floatArrayOf(1f, 0f)    // similarity 1 — a good one
            )
        )
        val result = CurrencyClassifier.classify(query, references)
        assertEquals(denom(1000), result?.denomination)
        assertEquals(1.0f, result!!.similarity, 0.001f)
    }

    @Test
    fun `confidence scales with similarity strength`() {
        val query = floatArrayOf(1f, 0f)
        val highResult = CurrencyClassifier.classify(query, mapOf(denom(1000) to listOf(floatArrayOf(1f, 0f))))
        assertEquals(ConfidenceLevel.HIGH, highResult?.confidence)
    }

    @Test
    fun `threshold is a real, sensible value`() {
        assertEquals(0.80f, CurrencyClassifier.RECOGNITION_THRESHOLD)
        assert(CurrencyClassifier.RECOGNITION_THRESHOLD in 0f..1f)
    }
}
