package com.visionaid.vision.currency

import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.currency.Denomination
import com.visionaid.vision.face.EmbeddingSimilarity

/**
 * Nearest-neighbor denomination matching over reference embeddings. Pure
 * logic (reuses [EmbeddingSimilarity]'s cosine-similarity math from Phase
 * 7 rather than duplicating it), fully unit-testable with synthetic
 * vectors.
 *
 * A query is matched against EVERY reference embedding for EVERY
 * denomination (not just a per-denomination centroid) — this is more
 * robust to lighting/angle variation across the few reference photos per
 * denomination than averaging them into one centroid first would be.
 */
object CurrencyClassifier {

    /** Below this cosine similarity, report unknown rather than a low-confidence guess. */
    const val RECOGNITION_THRESHOLD = 0.80f

    fun classify(
        queryEmbedding: FloatArray,
        referenceEmbeddings: Map<Denomination, List<FloatArray>>
    ): ClassificationResult? {
        var bestDenomination: Denomination? = null
        var bestSimilarity = -1f

        for ((denomination, references) in referenceEmbeddings) {
            for (reference in references) {
                val similarity = EmbeddingSimilarity.cosineSimilarity(queryEmbedding, reference)
                if (similarity > bestSimilarity) {
                    bestSimilarity = similarity
                    bestDenomination = denomination
                }
            }
        }

        if (bestDenomination == null || bestSimilarity < RECOGNITION_THRESHOLD) return null

        val confidence = when {
            bestSimilarity >= 0.93f -> ConfidenceLevel.HIGH
            bestSimilarity >= 0.86f -> ConfidenceLevel.MEDIUM
            else -> ConfidenceLevel.LOW
        }

        return ClassificationResult(bestDenomination, bestSimilarity, confidence)
    }

    data class ClassificationResult(
        val denomination: Denomination,
        val similarity: Float,
        val confidence: ConfidenceLevel
    )
}
