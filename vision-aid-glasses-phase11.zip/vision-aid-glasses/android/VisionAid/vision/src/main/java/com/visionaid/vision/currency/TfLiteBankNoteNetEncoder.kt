package com.visionaid.vision.currency

import android.content.Context
import com.visionaid.core.logging.VisionAidLogger
import com.visionaid.vision.detection.FramePreprocessor
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/**
 * Real [CurrencyEncoderModel] wrapping a TFLite conversion of Microsoft's
 * BankNote-Net encoder. See MODEL_REGISTRY.md for the conversion steps
 * (the upstream model ships as Keras `.h5`; TFLite conversion is a one-time
 * offline step, not something this Android app performs itself).
 *
 * Input: 224x224 RGB image (per the upstream model's documented input
 * shape). Output: a 256-dimensional embedding (per BankNote-Net's
 * documented output — see the "Data Structure" section of its README).
 */
class TfLiteBankNoteNetEncoder(private val context: Context) : CurrencyEncoderModel {

    private var interpreter: Interpreter? = null
    private var loadAttempted = false

    override fun isAvailable(): Boolean {
        ensureLoaded()
        return interpreter != null
    }

    private fun ensureLoaded() {
        if (loadAttempted) return
        loadAttempted = true
        try {
            val modelBuffer = loadModelFile()
            interpreter = Interpreter(modelBuffer)
            VisionAidLogger.i(TAG, "BankNote-Net encoder loaded from $MODEL_ASSET_PATH")
        } catch (e: Exception) {
            VisionAidLogger.w(
                TAG,
                "BankNote-Net encoder (.tflite) not found/loadable at $MODEL_ASSET_PATH — " +
                    "currency recognition unavailable until it's supplied. See MODEL_REGISTRY.md."
            )
        }
    }

    private fun loadModelFile(): ByteBuffer {
        val assetFileDescriptor = context.assets.openFd(MODEL_ASSET_PATH)
        val inputStream = assetFileDescriptor.createInputStream()
        val fileChannel = inputStream.channel
        return fileChannel.map(
            FileChannel.MapMode.READ_ONLY,
            assetFileDescriptor.startOffset,
            assetFileDescriptor.declaredLength
        )
    }

    override fun generateEmbedding(imageData: ByteArray): FloatArray? {
        val activeInterpreter = interpreter ?: return null
        val bitmap = FramePreprocessor.decodeToBitmap(imageData) ?: return null
        val scaled = android.graphics.Bitmap.createScaledBitmap(bitmap, INPUT_SIZE, INPUT_SIZE, true)

        val inputBuffer = ByteBuffer.allocateDirect(4 * INPUT_SIZE * INPUT_SIZE * 3)
            .order(ByteOrder.nativeOrder())
        val pixels = IntArray(INPUT_SIZE * INPUT_SIZE)
        scaled.getPixels(pixels, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE)
        for (pixel in pixels) {
            // Normalized to [0,1] per typical MobileNetV2 preprocessing;
            // must match whatever normalization the .tflite conversion
            // step baked in — documented in MODEL_REGISTRY.md.
            inputBuffer.putFloat(((pixel shr 16) and 0xFF) / 255f)
            inputBuffer.putFloat(((pixel shr 8) and 0xFF) / 255f)
            inputBuffer.putFloat((pixel and 0xFF) / 255f)
        }

        val output = Array(1) { FloatArray(EMBEDDING_SIZE) }
        return try {
            activeInterpreter.run(inputBuffer, output)
            output[0]
        } catch (e: Exception) {
            VisionAidLogger.e(TAG, "BankNote-Net encoder inference failed", e)
            null
        }
    }

    companion object {
        private const val TAG = "TfLiteBankNoteNetEncoder"
        const val MODEL_ASSET_PATH = "banknote_net_encoder.tflite"
        const val INPUT_SIZE = 224
        const val EMBEDDING_SIZE = 256
    }
}
