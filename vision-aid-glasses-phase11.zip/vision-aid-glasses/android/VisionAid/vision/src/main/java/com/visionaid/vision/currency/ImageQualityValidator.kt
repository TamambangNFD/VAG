package com.visionaid.vision.currency

import android.graphics.Bitmap
import android.graphics.Color

/**
 * Basic image-quality gate, per the roadmap's explicit "image-quality
 * validation" requirement for currency recognition — an out-of-focus,
 * too-dark, or blank frame should be rejected before attempting
 * classification, rather than fed to the encoder and potentially producing
 * a low-confidence but technically-above-threshold false match.
 *
 * HONEST LIMITATION: this is a simple contrast-range heuristic (a very
 * low-contrast image is likely blurry, too dark, or blank), NOT a real
 * blur-detection algorithm (e.g. variance-of-Laplacian, which needs
 * convolution and is more naturally an OpenCV operation). Same class of
 * documented trade-off as Phase 8's document-edge-detection limitation.
 */
object ImageQualityValidator {

    /** Grayscale value range (max-min) below this is treated as too low-contrast to trust. */
    const val MIN_ACCEPTABLE_CONTRAST_RANGE = 30

    /** Pure function: assess quality from precomputed grayscale pixel values, for testability. */
    fun assessQuality(grayValues: IntArray): Boolean {
        if (grayValues.isEmpty()) return false
        val min = grayValues.min()
        val max = grayValues.max()
        return (max - min) >= MIN_ACCEPTABLE_CONTRAST_RANGE
    }

    fun assessQuality(bitmap: Bitmap): Boolean {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val grayValues = IntArray(pixels.size) { i ->
            val p = pixels[i]
            (Color.red(p) * 0.299 + Color.green(p) * 0.587 + Color.blue(p) * 0.114).toInt()
        }
        return assessQuality(grayValues)
    }
}
