package com.visionaid.vision.currency

/**
 * Converts a cropped banknote/coin image into a numeric embedding for
 * denomination matching. Analogous to Phase 7's `FaceEmbeddingModel`
 * pattern, but with a materially different provenance outcome: see
 * MODEL_REGISTRY.md's "Currency Recognition" entry for the full story.
 *
 * The real implementation ([TfLiteBankNoteNetEncoder]) wraps a TFLite
 * conversion of Microsoft's BankNote-Net encoder — an openly licensed
 * (CDLA-Permissive-2.0 / MIT), well-documented model built specifically for
 * assistive currency recognition (it powers Microsoft's Seeing AI app).
 * Unlike Phase 7's face-embedding search, this is NOT a deferred gap: a
 * clean, purpose-built, properly licensed encoder exists and is used here.
 *
 * What IS still required from the product owner: BankNote-Net's base
 * dataset does not include Central African CFA franc (XAF) — its own
 * documented usage pattern is few-shot transfer to new currencies via a
 * small number of real reference images per denomination (the README's own
 * Swedish Krona example uses exactly this approach). See
 * MODEL_REGISTRY.md for exactly what must be collected and how.
 */
interface CurrencyEncoderModel {
    fun isAvailable(): Boolean
    fun generateEmbedding(imageData: ByteArray): FloatArray?
}
