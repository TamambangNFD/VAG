package com.visionaid.vision.currency

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolError
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.currency.CurrencyCode
import com.visionaid.ai.currency.CurrencyOutput
import com.visionaid.ai.currency.CurrencyRecognitionTool
import com.visionaid.vision.detection.FramePreprocessor

/**
 * Real implementation of Phase 2's [CurrencyRecognitionTool], built on
 * Microsoft's BankNote-Net encoder (see MODEL_REGISTRY.md) plus a small
 * set of product-owner-collected reference images for XAF, since
 * BankNote-Net's base 17 currencies don't include it.
 *
 * Behavior when the encoder or reference data isn't supplied yet:
 * correctly reports `UNAVAILABLE_MODEL_NOT_LOADED` / fails with
 * `ModelNotLoaded`, same honesty pattern as every other model-dependent
 * tool in this project.
 */
class RealCurrencyRecognitionTool(
    private val encoder: CurrencyEncoderModel,
    private val referenceStore: ReferenceEmbeddingStore
) : CurrencyRecognitionTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    override fun availability(): ToolAvailability {
        if (!encoder.isAvailable() || !referenceStore.isAvailable()) {
            return ToolAvailability.UNAVAILABLE_MODEL_NOT_LOADED
        }
        return ToolAvailability.AVAILABLE
    }

    override suspend fun recognizeCurrency(frame: FrameContext): ToolResult<CurrencyOutput> {
        if (!encoder.isAvailable() || !referenceStore.isAvailable()) {
            return ToolResult.Failure(ToolError.ModelNotLoaded, frame.captureTimestampMillis)
        }

        val bitmap = FramePreprocessor.decodeToBitmap(frame.imageData)
            ?: return ToolResult.Failure(ToolError.InvalidInput("Could not decode frame as an image"), frame.captureTimestampMillis)

        val qualitySufficient = ImageQualityValidator.assessQuality(bitmap)
        if (!qualitySufficient) {
            return ToolResult.Success(
                data = CurrencyOutput(denomination = null, currency = CurrencyCode.XAF, imageQualitySufficient = false),
                confidence = Confidence.unknown(),
                timestampMillis = frame.captureTimestampMillis
            )
        }

        val embedding = encoder.generateEmbedding(frame.imageData)
            ?: return ToolResult.Failure(ToolError.InternalError("Failed to generate currency embedding"), frame.captureTimestampMillis)

        val match = CurrencyClassifier.classify(embedding, referenceStore.getReferenceEmbeddings())

        return ToolResult.Success(
            data = CurrencyOutput(
                denomination = match?.denomination,
                currency = CurrencyCode.XAF,
                imageQualitySufficient = true
            ),
            confidence = if (match != null) Confidence.of(match.confidence, match.similarity) else Confidence.unknown(),
            timestampMillis = frame.captureTimestampMillis
        )
    }
}
