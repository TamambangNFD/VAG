package com.visionaid.vision.currency

import android.content.Context
import com.visionaid.ai.currency.CurrencyCode
import com.visionaid.ai.currency.Denomination
import com.visionaid.core.logging.VisionAidLogger
import org.json.JSONObject

/**
 * Loads per-denomination reference embeddings from a bundled asset file —
 * the "few-shot training set" that BankNote-Net's own documented usage
 * pattern calls for when extending to a currency it wasn't originally
 * trained on (like XAF). See MODEL_REGISTRY.md for exactly how these
 * images/embeddings must be collected (real photographs with usage rights
 * — explicitly NOT stock photography, which is not licensed for this use).
 *
 * This is NOT personal/biometric data — it's a small set of reference
 * embeddings for fixed, public currency designs, collected once by the
 * product owner/development team, not per end-user. No consent-capture
 * mechanism is needed here the way Phase 7's face enrollment required one.
 *
 * File format: a JSON object mapping "<isoCode>:<value>:<isCoin>" to a list
 * of reference embedding arrays (multiple photos per denomination improve
 * matching robustness against lighting/angle variation).
 */
class ReferenceEmbeddingStore(private val context: Context) {

    private var cache: Map<String, List<FloatArray>>? = null

    fun isAvailable(): Boolean = loadIfNeeded().isNotEmpty()

    fun getReferenceEmbeddings(): Map<Denomination, List<FloatArray>> =
        loadIfNeeded().entries.mapNotNull { (key, embeddings) ->
            parseKey(key)?.let { it to embeddings }
        }.toMap()

    private fun loadIfNeeded(): Map<String, List<FloatArray>> {
        cache?.let { return it }
        val loaded = try {
            context.assets.open(ASSET_PATH).use { input ->
                val json = JSONObject(input.bufferedReader().readText())
                val result = mutableMapOf<String, List<FloatArray>>()
                json.keys().forEach { key ->
                    val embeddingsJson = json.getJSONArray(key)
                    val embeddings = (0 until embeddingsJson.length()).map { i ->
                        val vec = embeddingsJson.getJSONArray(i)
                        FloatArray(vec.length()) { vec.getDouble(it).toFloat() }
                    }
                    result[key] = embeddings
                }
                result
            }
        } catch (e: Exception) {
            VisionAidLogger.w(
                TAG,
                "Reference embeddings asset not found/loadable at $ASSET_PATH — currency " +
                    "recognition unavailable until reference data is supplied. See MODEL_REGISTRY.md."
            )
            emptyMap()
        }
        cache = loaded
        return loaded
    }

    private fun parseKey(key: String): Denomination? {
        val parts = key.split(":")
        if (parts.size != 3) return null
        val value = parts[1].toIntOrNull() ?: return null
        val isCoin = parts[2].toBooleanStrictOrNull() ?: return null
        return Denomination(CurrencyCode(parts[0]), value, isCoin)
    }

    companion object {
        private const val TAG = "ReferenceEmbeddingStore"
        const val ASSET_PATH = "currency_reference_embeddings.json"
    }
}
