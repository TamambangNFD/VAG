# Vision Aid Glasses — Latest Handoff

## Last completed phase
Phase 11 — Offline Speech Recognition

## The headline decision this phase
**whisper.cpp (MIT) + OpenAI's Whisper model weights (MIT)** — both cleanly
licensed, well-documented, from reputable sources. This is NOT the same
kind of gap as Phase 7's face recognition: transcription is about *content*
(what was said), not *identity* (who said it), so there's no equivalent
individual-consent concern to a biometric identification model trained on
scraped photos of real people. Chosen over Android's built-in
`SpeechRecognizer` specifically to avoid a Google Play Services dependency
— same reasoning as Phase 8's Tesseract-over-ML-Kit decision.

## What was built
- `VoiceActivityDetector` (`audio/asr/`): pure, energy-based (RMS) speech
  detection — documented as a simple heuristic, not a neural VAD.
- `UtteranceSegmenter`: pure, stateful utterance-boundary detection —
  buffers speech frames, finalizes an utterance after configurable trailing
  silence. Fully unit-tested (6 cases) without needing a real microphone.
- `MicrophoneAudioSource`: real `AudioRecord` wiring (16kHz mono PCM16,
  whisper.cpp's expected format), feeding frames to the segmenter.
- `WhisperCppEngine`: JNI bridge to whisper.cpp. **The Kotlin/JNI side is
  real, complete code** (`external fun` declarations, `System.loadLibrary`,
  model-file loading). The native C++ side (whisper.cpp source integration,
  CMake/NDK build, JNI glue implementation) is a documented, not-yet-done
  build-tooling task — see "Known issues" below and `MODEL_REGISTRY.md` for
  the exact steps.
- `RealSpeechRecognitionTool`: implements Phase 2's `SpeechRecognitionTool`
  contract exactly — no interface change was needed this phase.
- `MODEL_REGISTRY.md` extended with the full engine/model decision and the
  native-build integration steps.
- 12 new unit tests total (`VoiceActivityDetectorTest`: 6,
  `UtteranceSegmenterTest`: 6).

## Decisions made this phase
- **Engine: whisper.cpp**, not Android's built-in `SpeechRecognizer` — same
  GMS-avoidance reasoning as Phase 8.
- **16kHz mono PCM16** as the audio interchange format between microphone
  capture and the ASR engine — whisper.cpp's native expected format, no
  unnecessary conversion.
- **Energy-based VAD** — simple, dependency-free, documented limitation
  (will treat any loud non-speech sound as "speech"; whisper.cpp itself
  handles non-speech audio gracefully by producing empty/low-quality output,
  which `RealSpeechRecognitionTool` treats as a valid "nothing understood"
  result).
- **No command routing/agent logic built** — correctly deferred to Phase 13,
  per the roadmap's explicit instruction for this phase.

## Interfaces exposed (for next phases to depend on)
- `RealSpeechRecognitionTool` implements `ai.speech.SpeechRecognitionTool` —
  Phase 13's Agent consumes this (or the Phase 2 mock) without any contract
  change needed.
- `MicrophoneAudioSource`/`UtteranceSegmenter` together form a reusable
  "camera-frame-source equivalent" for audio — any future phase needing
  captured utterances can reuse this rather than rebuilding mic handling.

## Known issues / limitations
- **The native C++ side of whisper.cpp integration does not exist yet.**
  This is a genuine build-tooling task (clone whisper.cpp as a source
  dependency, write JNI glue, configure CMake/NDK in Gradle) that needs a
  real NDK toolchain to author and verify correctly — deliberately not
  attempted as unverified C++ in this sandbox. Exact steps are in
  `MODEL_REGISTRY.md`. Until this is done, `WhisperCppEngine.isAvailable()`
  correctly reports false.
- **No ggml model file is bundled** — same pattern as every other model in
  this project (download per `MODEL_REGISTRY.md`, place at the documented
  asset path).
- **Energy-based VAD is a simple heuristic** — documented, not hidden.
- **Build/test execution not verified in this sandbox**, same limitation as
  every prior phase. `VoiceActivityDetectorTest`/`UtteranceSegmenterTest`
  are pure JVM; `MicrophoneAudioSource`/`WhisperCppEngine`/
  `RealSpeechRecognitionTool` need Android runtime (and, for
  `WhisperCppEngine`, the native library once built) — not unit-testable
  in plain JVM.

## What the next phase needs to know
- Phase 12 (Offline Text-to-Speech) is independent of speech recognition —
  no blocking dependency, though together they'll form the voice-interaction
  loop the Agent (Phase 13) orchestrates.
- Whoever completes the whisper.cpp native build should test with both
  English and French audio before considering this phase's model fully
  working — the Kotlin side already threads locale through correctly, but
  that's unverified without a real native build.

## Git checkpoint
Tag: phase-11-complete
Commit message: `Phase 11: offline speech recognition (whisper.cpp JNI bridge + VAD pipeline)`
Commit hash: <create when you commit this to your actual repository>

## Verification status
See VERIFICATION.md — Phase 11: PASSED WITH NOTES. Not safety-critical, no
sign-off gate.
