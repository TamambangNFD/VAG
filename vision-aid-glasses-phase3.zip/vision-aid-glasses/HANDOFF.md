# Vision Aid Glasses — Latest Handoff

## Last completed phase
Phase 3 — Object Detection

## Working-agreement change effective this phase
Starting this phase, Tammy delegated technical/model/license decisions to
Claude going forward: build per the roadmap documents, document the
rationale, and don't pause to ask which option she wants. This applies to
all future phases, not just Phase 3. The one unaffected exception: safety-
critical phase sign-off (Phases 5, 16, 17, 18, 31) remains Tammy's alone —
that's a hard guardrail, not a workflow preference, and is unchanged.

## What was built
- `LiteRtObjectDetectionTool` (`vision/detection/`): real implementation of
  Phase 2's `ObjectDetectionTool` interface using LiteRT (TensorFlow Lite)
  with the TFLite Task Library's `ObjectDetector` API.
- `CocoLabelMap`: maps the model's COCO class indices to the roadmap's
  `ObjectLabel` enum, with an explicit, tested guarantee that it never
  fabricates a mapping to DOOR/STAIRS/POLE/ROAD/SIDEWALK/WALL — see "Known
  limitation" below.
- `BoxDecoder`: pure, unit-testable postprocessing (confidence thresholding,
  degenerate-box rejection, result capping) kept separate from the
  Interpreter so it's testable without a real model file.
- `FramePreprocessor`: decodes raw frame bytes to an Android `Bitmap`.
- `CameraFrameSource` (`vision/camera/`): CameraX-based `ImageAnalysis`
  pipeline that produces `FrameContext` instances at a throttled 5fps
  default, converting YUV_420_888 camera output to JPEG.
- `MODEL_REGISTRY.md`: full model provenance, license, size, and a detailed
  "known class-coverage gap" section.
- 7 new unit tests (`CocoLabelMapTest`, `BoxDecoderTest`) covering the
  testable pure-logic pieces.
- Updated `vision/build.gradle.kts`: added `ai` module dependency, LiteRT
  (`tensorflow-lite`, `-support`, `-metadata`), and CameraX dependencies.

## Decisions made this phase (made autonomously per the new working agreement)
- **Model: SSD MobileNetV2 FPN-Lite 320x320, COCO-pretrained, quantized.**
- **Runtime: LiteRT (TensorFlow Lite)**, not ONNX Runtime — chosen for
  tighter first-party Android tooling (TFLite Task Library) and a smaller
  footprint for a single SSD-style model.
- **License: Apache 2.0.** YOLOv8/Ultralytics was explicitly considered and
  rejected because it's AGPL-3.0-licensed, which carries commercial-use
  obligations inappropriate to take on unilaterally on Tammy's behalf.
- **JPEG as the camera-to-preprocessing interchange format** for Phase 3
  simplicity; flagged in code comments as a candidate for a raw-plane
  optimization in the Phase 25/26 performance pass.
- **5fps default frame throttle** in `CameraFrameSource` — a conservative
  placeholder; Phase 25 (Power Optimization) will make this adaptive.

## Interfaces exposed (for next phases to depend on)
- `LiteRtObjectDetectionTool` implements `ai.detection.ObjectDetectionTool`
  — Phase 4 (Object Tracking) consumes its `DetectedObject` output directly,
  same contract as the Phase 2 mock.
- `CameraFrameSource.start(lifecycleOwner, locale, onFrame)` — any future
  phase needing camera frames (OCR, currency, face recognition) can reuse
  this rather than building a second CameraX pipeline.

## Known issues / limitations
- **Class-coverage gap (important, carries forward):** this model can never
  detect DOOR, STAIRS, POLE, ROAD, SIDEWALK, or WALL — COCO has no matching
  categories. This is enforced by a test, not just documented. Phases 16
  (Obstacle Avoidance) and 17 (Traffic Safety) will need to explicitly work
  around this or trigger closing it first (custom model, segmentation, etc.
  — options listed in MODEL_REGISTRY.md).
- **The actual `.tflite` model binary is not in this repository.** Tammy
  needs to obtain it (source and exact steps in MODEL_REGISTRY.md) and place
  it at `vision/src/main/assets/ssd_mobilenet_v2_fpnlite_320.tflite` before
  `LiteRtObjectDetectionTool` can report `AVAILABLE` instead of
  `UNAVAILABLE_MODEL_NOT_LOADED`.
- **Build/test execution not verified in this sandbox**, same limitation as
  Phases 1-2 (no Android SDK / Maven network access here). All new Kotlin
  was hand-reviewed; real inference obviously cannot be tested here without
  the model file and a device.
- No accuracy/latency numbers exist yet — MODEL_REGISTRY.md explicitly warns
  against trusting vendor-published benchmarks as this product's confirmed
  numbers until real on-device testing happens.
- No UI/MainActivity wiring yet — the detection pipeline exists and is
  testable in isolation, but isn't yet invoked from the app. This mirrors
  Phase 2, where tools existed without being wired into the app shell; full
  wiring is expected once the Agent (Phase 13) exists to orchestrate calls.

## What the next phase needs to know
- Phase 4 (Object Tracking) builds on `LiteRtObjectDetectionTool`'s real
  `DetectedObject` output (or the Phase 2 mock, interchangeably — that's the
  point of the interface). No changes to Phase 2/3 contracts should be
  needed.
- Once you've obtained and placed the model file and confirmed the build,
  let me know — I'll fold the confirmation into VERIFICATION.md the same way
  as Phases 1-2, then move to Phase 4 without further prompting per the new
  working agreement.

## Git checkpoint
Tag: phase-3-complete
Commit message: `Phase 3: offline object detection with LiteRT (SSD MobileNetV2 FPN-Lite)`
Commit hash: <create when you commit this to your actual repository>

## Verification status
See VERIFICATION.md — Phase 3: PASSED WITH NOTES (source complete and
internally consistent; actual Gradle build/test run and model-file placement
still need your confirmation).
