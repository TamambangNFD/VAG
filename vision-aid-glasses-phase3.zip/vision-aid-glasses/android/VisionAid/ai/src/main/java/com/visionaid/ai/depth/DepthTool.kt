package com.visionaid.ai.depth

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * SAFETY-CRITICAL (roadmap Section 0.4). Estimates distance to detected
 * objects.
 *
 * Input contract: a [FrameContext] and the object IDs to estimate distance
 * for (obtained from ObjectDetectionTool).
 * Output contract: [DepthOutput] mapping each requested object ID to a
 * [DistanceBand] — never a raw numeric distance at this phase. Precise
 * numeric distance requires calibration validated in Phase 5 and must not
 * be claimed before then.
 *
 * This tool must NEVER be replaced by a general-purpose LLM/VLM as the sole
 * decision-maker, and must always prefer [DistanceBand.UNKNOWN] over a
 * confident-but-wrong estimate.
 *
 * Offline capability: OFFLINE_ONLY.
 */
interface DepthTool {

    val operationMode: OperationMode

    fun availability(): ToolAvailability

    suspend fun estimateDistance(
        frame: FrameContext,
        objectIds: List<String>
    ): ToolResult<DepthOutput>
}

data class DepthOutput(
    val distances: Map<String, DistanceBand>
)

enum class DistanceBand {
    NEAR, MEDIUM, FAR,
    /** Insufficient evidence to classify. Must be preferred over guessing. */
    UNKNOWN
}
