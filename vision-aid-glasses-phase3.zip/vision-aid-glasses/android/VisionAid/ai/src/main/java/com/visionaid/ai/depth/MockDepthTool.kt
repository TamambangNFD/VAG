package com.visionaid.ai.depth

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Deterministic mock. Always reports UNKNOWN for every object, by design —
 * this is a safety-critical tool and the safe default for an unimplemented
 * mock is UNKNOWN, never a fabricated NEAR/MEDIUM/FAR value. Phase 5
 * replaces this with real stereo/monocular depth estimation.
 */
class MockDepthTool : DepthTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun estimateDistance(
        frame: FrameContext,
        objectIds: List<String>
    ): ToolResult<DepthOutput> {
        val distances = objectIds.associateWith { DistanceBand.UNKNOWN }
        return ToolResult.Success(
            data = DepthOutput(distances = distances),
            confidence = Confidence.unknown(),
            timestampMillis = frame.captureTimestampMillis
        )
    }
}
