package com.visionaid.ai.depth

import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.ToolResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Safety-critical test: explicitly asserts the mock NEVER returns a
 * confident distance band, since it has no real depth logic behind it.
 */
class MockDepthToolTest {

    private val tool = MockDepthTool()
    private fun frame() = FrameContext(frameId = 1L, imageData = ByteArray(0), captureTimestampMillis = 1000L)

    @Test
    fun `always returns UNKNOWN for every requested object`() = runBlocking {
        val result = tool.estimateDistance(frame(), listOf("obj-1", "obj-2")) as ToolResult.Success
        result.data.distances.values.forEach {
            assertEquals(DistanceBand.UNKNOWN, it)
        }
    }

    @Test
    fun `confidence is UNKNOWN, never a fabricated confident value`() = runBlocking {
        val result = tool.estimateDistance(frame(), listOf("obj-1")) as ToolResult.Success
        assertEquals(ConfidenceLevel.UNKNOWN, result.confidence.level)
    }

    @Test
    fun `distances map contains an entry for every requested objectId`() = runBlocking {
        val ids = listOf("obj-1", "obj-2", "obj-3")
        val result = tool.estimateDistance(frame(), ids) as ToolResult.Success
        assertTrue(result.data.distances.keys.containsAll(ids))
    }
}
