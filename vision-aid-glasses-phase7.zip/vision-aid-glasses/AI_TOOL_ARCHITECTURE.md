# Vision Aid Glasses — AI Tool Architecture (AI_TOOL_ARCHITECTURE.md)

**Phase:** 2 — AI Tool Architecture
**Module:** `android/VisionAid/ai/`

## Purpose

This phase defines a stable, swappable interface for every AI capability the
product needs, so a real model (Phase 3 onward) can be dropped in — or later
replaced — without touching any calling code. No real model is integrated in
this phase; every tool below ships only with a deterministic mock.

## Shared Contracts (`ai/common/`)

Every tool interface is built from the same small set of shared types, so
callers (the future Agent, Situation Engine, and WorldModel) can reason about
any tool the same way:

| Type | Purpose |
|---|---|
| `ToolResult<T>` | Universal envelope: `Success(data, confidence, timestampMillis, metadata)` or `Failure(error, timestampMillis)`. |
| `Confidence` / `ConfidenceLevel` | `UNKNOWN / LOW / MEDIUM / HIGH`, plus an optional raw `score`. `UNKNOWN` is a first-class, expected outcome — not an error. |
| `ToolError` | Sealed class for genuine failures (`ModelNotLoaded`, `HardwareUnavailable`, `Timeout`, `InvalidInput`, `InternalError`). Never used for "nothing found" or "low confidence" — those are successful results. |
| `ToolAvailability` | Whether the tool can run at all right now (`AVAILABLE`, `UNAVAILABLE_HARDWARE_MISSING`, `UNAVAILABLE_MODEL_NOT_LOADED`, `UNAVAILABLE_PERMISSION_DENIED`, `DISABLED_BY_USER`, `ERROR`). Distinct from a per-request `ToolError`. |
| `OperationMode` | `OFFLINE_ONLY / OFFLINE_WITH_ONLINE_ENHANCEMENT / ONLINE_ONLY`. Every tool declares this so the future Network Capability Manager (Phase 22) and Agent (Phase 13) know what still works offline. |
| `FrameContext` | Shared input envelope for frame-based tools: `frameId`, opaque `imageData`, `captureTimestampMillis`, and an explicit `LocaleTag` (never hard-coded, per Section 0.5). |

## Tool Interfaces

| Tool | Input | Output | Offline mode | Notes |
|---|---|---|---|---|
| `ObjectDetectionTool` | `FrameContext` | `DetectionOutput` (list of `DetectedObject` with label/box/confidence) | OFFLINE_ONLY | Phase 3 replaces mock with a real on-device model. |
| `ObjectTrackingTool` | detections + timestamp | `TrackingOutput` (stable `trackId`s, movement direction) | OFFLINE_ONLY | Owns its own track-history state; Phase 4 replaces with ByteTrack or similar. |
| `DepthTool` | `FrameContext` + object IDs | `DepthOutput` (near/medium/far/**UNKNOWN** per object) | OFFLINE_ONLY | **Safety-critical.** Mock always returns UNKNOWN by design — see below. |
| `FaceRecognitionTool` | `FrameContext` (+ name for enroll) | `RecognitionOutput` / `EnrollmentOutput` | OFFLINE_ONLY | Unknown faces reported as `personId = null`, never guessed. Consent capture happens in the caller before `enroll()`. |
| `OCRTool` | `FrameContext` | `OcrOutput` (text blocks, per-block confidence) | OFFLINE_ONLY | Locale-aware (French/English) via `FrameContext.locale`. |
| `CurrencyRecognitionTool` | `FrameContext` | `CurrencyOutput` (denomination or null, `imageQualitySufficient`) | OFFLINE_ONLY | XAF only for now; designed for more currencies later without interface changes. |
| `NavigationTool` | lat/lng + destination query | `RouteOutput` (turn-by-turn steps) | OFFLINE_WITH_ONLINE_ENHANCEMENT | Only navigation tool not driven by a camera frame. |
| `DocumentTool` | `FrameContext` (load) / no input (navigate) | `DocumentOutput` / `Paragraph` | OFFLINE_ONLY | Stateful: `loadDocument` → `readNext`/`readPrevious`/`readAll`. |
| `SafetyTool` | tracked objects + distance bands | `SafetyOutput` (`SAFE_CANDIDATE/CAUTION/DANGER/STOP/UNKNOWN` + reason) | OFFLINE_ONLY | **Safety-critical.** Mock always returns `UNKNOWN` — see below. |
| `SpeechRecognitionTool` | raw audio bytes + `LocaleTag` | `SpeechRecognitionOutput` (transcript) | OFFLINE_ONLY | Phase 11 replaces mock with a real ASR engine (e.g. whisper.cpp). |
| `TextToSpeechTool` | text + locale + `SpeechPriority` | `ToolResult<Unit>` | OFFLINE_ONLY | Priority ordering `NORMAL < IMPORTANT < WARNING < CRITICAL < EMERGENCY`; mock records a spoken-history queue for testing. |

## Safety-Critical Design Choice (Section 0.4 of the roadmap)

`DepthTool` and `SafetyTool` are the two safety-critical interfaces defined
in this phase (full implementations arrive at Phases 5 and 16/17
respectively). Their **mock implementations deliberately always return
`UNKNOWN`** rather than any plausible-looking value. This is not an
oversight — a mock with no real model behind it that returned, say,
`DistanceBand.MEDIUM` or `SafetyState.SAFE_CANDIDATE` would be exactly the
"confident-but-wrong" failure mode the roadmap prohibits. Every downstream
consumer built against these mocks during Phases 3–15 will therefore be
forced to handle the `UNKNOWN` case correctly from day one, rather than
discovering a gap when the real safety pipeline lands.

## Why Interfaces Live in the `ai` Module

Per `ARCHITECTURE.md`, the `ai` module was reserved in Phase 1 specifically
to hold these tool contracts. Concrete implementations will move into their
natural home module as each phase builds them (e.g. `ObjectDetectionTool`'s
real implementation lands in `vision` at Phase 3, `CurrencyRecognitionTool`'s
in `currency` at Phase 10) — those modules already depend on `ai` (or will be
updated to) so they can implement its interfaces without `ai` ever depending
back on them.

## What This Phase Does NOT Include

- No real models — every implementation is a deterministic mock.
- No dependency injection wiring into `MainActivity` — that's an application-
  layer decision for a later phase once real tools exist to inject.
- No persistence — `FaceRecognitionTool`'s mock enrollment is in-memory only;
  real encrypted storage arrives in Phase 7/21.

---

## Phase 4 Update — Real ObjectTrackingTool Implementation

`MockObjectTrackingTool` (Phase 2) is superseded for production use by
`IouObjectTrackingTool` (`vision/tracking/`), a greedy IoU-based tracker —
the roadmap's "ByteTrack or another suitable lightweight tracker" choice,
picked here as "another suitable lightweight tracker" appropriate for
on-device mobile resource constraints. The mock remains in the `ai` module
for tests that don't need real tracking behavior.

**How it works:** each frame's detections are matched against the previous
frame's active tracks by same-label bounding-box IoU (greedy, threshold
0.3). Matched tracks update in place; unmatched tracks tolerate up to 5
missed frames (brief occlusion) before being dropped; unmatched detections
start new tracks. Movement direction combines horizontal center-point drift
(LEFT_TO_RIGHT/RIGHT_TO_LEFT) with bounding-box area change as an
APPROACHING/RECEDING heuristic.

**Known limitations (documented, not hidden):**
- No motion prediction — fast displacement between frames can exceed the IoU
  threshold and cause an ID switch. A Kalman-filter-based tracker would
  handle this better; not attempted in Phase 4.
- Greedy (not globally optimal) matching can occasionally swap IDs when two
  same-label objects overlap heavily and cross paths.
- APPROACHING/RECEDING from box-area change is a heuristic, not real depth.
  Phase 5 (Depth) and Phase 6 (World Model) supersede this with actual
  distance data — no safety-critical logic may treat this heuristic as
  depth-equivalent.

---

## Phase 5 Update — Real DepthTool Implementation (SAFETY-CRITICAL)

**Interface change:** `DepthTool.estimateDistance()` originally (Phase 2)
took `objectIds: List<String>`. This was insufficient for any real
implementation — distance estimation needs each object's bounding box and
label, not just its ID. Changed to take `detectedObjects: List<DetectedObject>`
instead. `MockDepthTool` and its test were updated to match in this same
phase; no other code depended on the old signature.

`MockDepthTool` (Phase 2) is superseded for production use by `RealDepthTool`
(`vision/depth/`), which routes through a `CameraHardwareProfile` hardware
capability abstraction:

- **Stereo declared but not implemented:** falls back to `UNKNOWN` for every
  object, loudly logged — no stereo hardware/calibration data exists yet to
  build or validate a real stereo pipeline against.
- **Monocular (the current default, since hardware is TBD):** uses
  `MonocularSizeBasedDepthEstimator`, a pure pinhole-camera "known object
  size" heuristic. Confidence is **permanently capped at LOW** — this
  technique is unvalidated against real-world measurements.

Full calibration requirements, accuracy limitations, and failure conditions
are documented in `CALIBRATION.md` at the repo root — required reading
before this subsystem is used for anything beyond development testing.

**This phase cannot be marked complete in `PROGRESS.md`/`VERIFICATION.md`
without explicit human sign-off**, per Section 0.4 and Section 40 of the
roadmap — this is the one place the general delegation of technical
decisions does not apply.

---

## Phase 6 Update — Spatial World Model

New component in `ai/worldmodel/` (not one of Phase 2's 11 tools — the
roadmap introduces it fresh in Phase 6): `WorldModel` interface +
`LocalWorldModel`, its only implementation. Pure Kotlin, no Android
dependency, fully deterministic — per the phase's explicit "prioritize
deterministic, explainable data structures over complex AI" requirement.

**What it does:** combines each frame's `TrackedObject`s (Phase 4) and
`DistanceBand`s (Phase 5) into `WorldObject` records — one per tracked
object, carrying a coarse `HorizontalPosition` (LEFT/CENTER/RIGHT, from
bounding-box center-x thirds) and a **weakest-link confidence** (the lowest
of the caller-supplied detection/tracking/depth confidence levels).

**Queries supported:** `nearestObstacle()`, `objectsInPath()`,
`objectsByPosition()`, `movingObjects()`, `objectsWithinDistance()`,
`allObjects()`.

**Deliberate conservative design carried over from Phase 5:** an object at
`DistanceBand.UNKNOWN` can never be `nearestObstacle()` and is excluded from
`objectsWithinDistance()` entirely — an unknown distance is not comparable
to a known one, so it's excluded rather than treated as "far" or "near" by
default.

**What this phase does NOT do:** no natural-language generation (Phase 13's
Agent), no safety decisions (Phases 16-17) — this is purely "what do we
currently believe is out there," queryable in a few structured ways.

---

## Phase 7 Update — Real FaceRecognitionTool Implementation

**Interface change:** `FaceRecognitionTool.enroll()` now takes a structural
`consentConfirmed: Boolean` parameter — every implementation must reject
enrollment when false. `MockFaceRecognitionTool` and its test were updated
to match.

`MockFaceRecognitionTool` (Phase 2) is superseded for production use by
`RealFaceRecognitionTool` (`vision/face/`), which orchestrates:
- `LiteRtFaceDetector` — real, working face **detection** (bounding boxes
  only), Apache 2.0 licensed model.
- `FaceEmbeddingModel` — **deliberately unimplemented**. Available
  pretrained face-*identification* models have documented training-data
  consent problems (see `MODEL_REGISTRY.md`). `NoFaceEmbeddingModelAvailable`
  is the only implementation, and it's correct, not a placeholder to be
  quietly swapped later without review.
- `EmbeddingSimilarity` — pure cosine-similarity matching logic, fully
  unit-tested with synthetic vectors, ready for whenever a compliant
  embedding model exists.
- `EncryptedFaceProfileStore` — AES-256 encrypted local storage via Jetpack
  Security, per `PRIVACY.md`.

**Current behavior:** `availability()` reports `UNAVAILABLE_MODEL_NOT_LOADED`
until a real embedding model is wired in. Face detection alone works;
recognition/enrollment correctly fail rather than fabricate a result.

Full privacy handling (consent, storage, user control, the embedding-model
gap) is documented in `PRIVACY.md`.
