# Vision Aid Glasses — Latest Handoff

## Last completed phase
Phase 7 — Face Detection and Recognition

## The headline decision this phase
**No face-recognition/identity model is integrated, and that's deliberate,
not incomplete work.** Every commonly available pretrained face-embedding
model was evaluated and rejected because its training data has documented
consent problems (MS-Celeb-1M was retracted by Microsoft in 2019 for
exactly this reason; VGGFace2/CASIA-WebFace have similar scraped-without-
consent origins). The roadmap explicitly requires clean, documented
provenance and licensing before using any model — I'm holding to that even
under the general delegation of technical choices, because this is a
compliance/ethics gate the roadmap sets, not a style preference. Full
reasoning is in `MODEL_REGISTRY.md`.

## What was built
- **Interface change:** `FaceRecognitionTool.enroll()` now takes a
  structural `consentConfirmed: Boolean` — enforced in code (every
  implementation rejects enrollment when false), not just promised in a
  comment as the Phase 2 version had it. `MockFaceRecognitionTool` and its
  test updated to match.
- `LiteRtFaceDetector` (`vision/face/`): real, working face **detection**
  (bounding boxes only, no identity) using an Apache-2.0-licensed
  metadata-packaged TFLite model, same loading pattern as Phase 3's object
  detector.
- `FaceEmbeddingModel` interface + `NoFaceEmbeddingModelAvailable`: the
  identity step, deliberately unimplemented — see above.
- `EmbeddingSimilarity`: pure cosine-similarity matching logic (threshold
  0.75, confidence scaling above that), fully unit-tested with synthetic
  vectors so it's ready the moment a compliant embedding model exists.
- `EncryptedFaceProfileStore` (`vision/face/`): AES-256-GCM encrypted local
  storage (Jetpack Security, Android Keystore-backed), storing only the
  embedding + name — never the original photo.
- `RealFaceRecognitionTool`: orchestrates all of the above. Correctly
  reports `UNAVAILABLE_MODEL_NOT_LOADED` and fails recognition/enrollment
  rather than fabricating a result, since no embedding model exists yet.
- `PRIVACY.md` (new, first entry in the repo): consent flow, storage
  details, user-control commands (enroll/rename/remove/disable), and the
  embedding-model gap.
- `MODEL_REGISTRY.md` extended with both the face-detector entry (Apache
  2.0, implemented) and a detailed "why no recognition model" section.
- 13 new/updated unit tests: `MockFaceRecognitionToolTest` (updated, 6
  cases), `EmbeddingSimilarityTest` (10 cases), `NoFaceEmbeddingModelAvailableTest`
  (2 cases).

## Decisions made this phase
- **Face detection uses a real, licensed model (Apache 2.0)**; face
  *recognition* does not, for the reasons above. Detection alone ("a face
  is here") carries much lower provenance risk than identification ("whose
  face"), so treating them differently is principled, not inconsistent.
- **Structural consent enforcement** in the interface itself, not just
  documentation — a caller cannot accidentally bypass consent capture the
  way a comment-only promise could be missed.
- **Never store the original face photo** — only the derived embedding
  (once one exists) plus the display name.
- **RECOGNITION_THRESHOLD = 0.75** (cosine similarity) as a placeholder
  value — will need real validation once an actual embedding model and
  real enrolled faces exist to test against.

## Interfaces exposed (for next phases to depend on)
- `RealFaceRecognitionTool` implements `ai.face.FaceRecognitionTool` — same
  contract as the updated Phase 2 mock (now with consent parameter).
- `FaceEmbeddingModel` is the extension point for whenever a compliant
  model is found/built/licensed — implement this interface, wire it into
  `RealFaceRecognitionTool`'s constructor in place of
  `NoFaceEmbeddingModelAvailable`, and update `MODEL_REGISTRY.md`.

## Known issues / limitations
- **Recognition/enrollment do not work end-to-end yet** — by design, until
  the embedding-model gap closes. This should be treated as expected
  behavior, not a bug report, until MODEL_REGISTRY.md's gap is resolved.
- **Build/test execution not verified in this sandbox**, same limitation as
  every prior phase. The pure-logic tests (`EmbeddingSimilarityTest`,
  `NoFaceEmbeddingModelAvailableTest`, updated `MockFaceRecognitionToolTest`)
  are plain JVM; `RealFaceRecognitionTool`, `LiteRtFaceDetector`, and
  `EncryptedFaceProfileStore` need Android runtime (TFLite, Keystore,
  BitmapFactory) and would need instrumented tests on a device — not
  written yet, same situation as Phase 3's camera/TFLite code.
- The face-detector model file itself also needs to be supplied (same
  pattern as Phase 3) — not included in the repo.
- `RECOGNITION_THRESHOLD` is unvalidated — needs real-world tuning once a
  real embedding model exists.

## What the next phase needs to know
- Phase 8 (OCR and Document Reading) is independent of face recognition —
  no blocking dependency.
- Whoever eventually resolves the embedding-model gap should update
  `MODEL_REGISTRY.md`'s "Face Recognition / Identity Embedding" section
  formally, not just write code — the product owner should explicitly
  review that decision given its legal/ethical weight, per that section's
  closing note.

## Git checkpoint
Tag: phase-7-complete
Commit message: `Phase 7: face detection (real) and recognition (architecture only, no identity model — see MODEL_REGISTRY.md)`
Commit hash: <create when you commit this to your actual repository>

## Verification status
See VERIFICATION.md — Phase 7: PASSED WITH NOTES. Not on the safety-critical
list (Section 0.4: only 5, 16, 17, 18, 31), so no sign-off gate — but given
the biometric/consent subject matter, you may still want to read PRIVACY.md
and MODEL_REGISTRY.md's gap section yourself rather than only skimming this
summary.
