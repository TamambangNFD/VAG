# Vision Aid Glasses — Latest Handoff

## Last completed phase
Phase 12 — Offline Text-to-Speech

## What was built
- **Interface additions:** `TextToSpeechTool` gained `setVoice(voiceId: String?)`
  and `setOutputRoute(route: AudioOutputRoute)`/`getCurrentOutputRoute()` —
  the Phase 2 version didn't cover voice selection or output routing, both
  explicit Phase 12 requirements. `MockTextToSpeechTool` and its test
  updated to match; no existing method signatures changed.
- `AndroidTextToSpeechEngine` (`audio/tts/`): wraps Android's framework
  `TextToSpeech` API. **Enforces offline-only voices** — checks each
  candidate voice's network-synthesis flags and refuses to speak via a
  network-requiring voice rather than silently falling back to one.
- `AudioOutputRouter`: real `PHONE_SPEAKER`/`BLUETOOTH` routing via
  `AudioManager`. `GLASSES` route is declared but not implemented (no
  glasses audio hardware integration exists yet — Phase 19/20).
- `PriorityQueueManager`: pure, fully unit-tested (9 cases) priority queue
  — directly satisfies the roadmap's explicit "create tests for queueing
  and emergency interruption" requirement. EMERGENCY items always dequeue
  first and clear lower-priority queued chatter; same-priority items stay
  FIFO.
- `RealTextToSpeechTool`: orchestrates the above, implementing the full
  `TextToSpeechTool` contract including emergency interruption (stop
  current playback, drop lower-priority queue items, speak EMERGENCY next).
- `MODEL_REGISTRY.md` extended with the engine decision and a documented
  upgrade path to Piper/sherpa-onnx for later "deeper offline control."

## Decisions made this phase
- **Engine: Android's framework `TextToSpeech` API**, per the roadmap's own
  "Android TTS for initial prototype" suggestion. Unlike Phase 8/11's engine
  choices, this carries no Google Play Services dependency concern — it's a
  public AOSP API, not a GMS service.
- **Offline voices enforced structurally**, not just preferred — `speak()`
  fails explicitly if only a network-requiring voice exists for the
  requested locale, rather than silently using one.
- **EMERGENCY clears lower-priority queue items but preserves other
  EMERGENCY/high-priority items** — deciding whether an interrupted item is
  ever resumed is left to Phase 18, consistent with the Phase 2 interface's
  own original documentation.
- **Piper/sherpa-onnx upgrade path documented, not built** — the roadmap
  itself frames this as the post-prototype "deeper control" option.

## Interfaces exposed (for next phases to depend on)
- `RealTextToSpeechTool` implements `ai.tts.TextToSpeechTool` — Phase 13's
  Agent and Phase 18's Emergency Event Manager both consume this.
- `PriorityQueueManager` is reusable if any future phase needs similar
  priority-ordered processing outside of TTS specifically.

## Known issues / limitations
- **No glasses audio routing** — expected until Phase 19/20.
- **Voice quality depends on whatever TTS engine is installed** on the
  device — a real limitation of the framework-API approach, which is
  exactly why Piper is documented as a future upgrade rather than dismissed.
- **Build/test execution not verified in this sandbox**, same limitation as
  every prior phase. `PriorityQueueManagerTest` is pure JVM;
  `AndroidTextToSpeechEngine`/`AudioOutputRouter`/`RealTextToSpeechTool`
  need Android runtime and would need instrumented tests — not written yet.
- No measurement yet of actual end-to-end interruption latency (how
  quickly `engine.stop()` actually silences in-progress audio on a real
  device) — would need a device to measure.

## What the next phase needs to know
- **Phase 13 (Vision Aid Agent) is the big integration phase** — it wires
  every tool built so far (detection, tracking, depth, world model, face,
  OCR/documents, magnification, currency, speech recognition, TTS) together
  for the first time, routing natural-language commands to the right tool.
  Before starting it, worth confirming with you: should Phase 13 wire in
  the *real* implementations built across Phases 3-12, or the Phase 2
  mocks, given several real implementations still have open dependencies
  (model files, native builds, reference data) not yet supplied? My
  inclination is to wire in the real implementations throughout (since
  that's the actual point of having built them, and every real tool
  degrades gracefully to UNAVAILABLE/ModelNotLoaded rather than crashing
  when its dependency is missing) — flagging this rather than just
  assuming, since it's a meaningful integration-point decision.

## Git checkpoint
Tag: phase-12-complete
Commit message: `Phase 12: offline text-to-speech (Android TTS, priority queue, emergency interruption)`
Commit hash: <create when you commit this to your actual repository>

## Verification status
See VERIFICATION.md — Phase 12: PASSED WITH NOTES. Not safety-critical, no
sign-off gate.
