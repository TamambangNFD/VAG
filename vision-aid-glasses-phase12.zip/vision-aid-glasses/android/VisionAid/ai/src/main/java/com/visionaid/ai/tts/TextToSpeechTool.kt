package com.visionaid.ai.tts

import com.visionaid.ai.common.LocaleTag
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Offline text-to-speech with priority-based queueing and emergency
 * interruption, per roadmap Phases 12 and 18.
 *
 * Input contract: text, locale, and a [SpeechPriority]. Higher-priority
 * items (EMERGENCY) interrupt whatever is currently speaking; the
 * interrupted item may be resumed later at the caller's discretion (Phase 18
 * decides that policy — this interface just exposes the primitive).
 * Output contract: [ToolResult<Unit>] indicating whether the item was
 * successfully queued/spoken.
 *
 * PHASE 12 ADDITIONS: [setVoice] and [setOutputRoute]/[getCurrentOutputRoute]
 * were added — the Phase 2 version covered volume/rate but not voice
 * selection or output routing, both explicit Phase 12 requirements
 * ("configurable voice"; "output must be routable to phone speaker /
 * Bluetooth / glasses audio").
 *
 * Offline capability: OFFLINE_ONLY.
 */
interface TextToSpeechTool {

    val operationMode: OperationMode

    fun availability(): ToolAvailability

    suspend fun speak(
        text: String,
        locale: LocaleTag,
        priority: SpeechPriority
    ): ToolResult<Unit>

    /** Stops all current and queued speech immediately (e.g. user says "stop"). */
    fun stopAll()

    fun setVolume(volume: Float)

    fun setSpeechRate(rate: Float)

    /** Null selects the engine's default voice for the current locale. */
    fun setVoice(voiceId: String?)

    /** Returns true if the route was actually applied, false if unsupported/unavailable right now. */
    fun setOutputRoute(route: AudioOutputRoute): Boolean

    fun getCurrentOutputRoute(): AudioOutputRoute
}

/**
 * Mirrors the roadmap's Phase 14/18 priority levels. EMERGENCY must always
 * preempt lower-priority speech — this is enforced by implementations, not
 * by this interface, but every implementation must honor the ordering
 * NORMAL < IMPORTANT < WARNING < CRITICAL < EMERGENCY.
 */
enum class SpeechPriority {
    NORMAL, IMPORTANT, WARNING, CRITICAL, EMERGENCY
}

/**
 * Where synthesized audio is sent. [GLASSES] exists as a declared target
 * for future hardware (Phase 19/20) but has no real implementation yet —
 * see `audio/tts/AudioOutputRouter` KDoc for why, same honest-fallback
 * pattern as Phase 9's `DisplayTarget`.
 */
enum class AudioOutputRoute { PHONE_SPEAKER, BLUETOOTH, GLASSES }
