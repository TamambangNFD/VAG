package com.visionaid.audio.tts

import com.visionaid.ai.common.LocaleTag
import com.visionaid.ai.tts.SpeechPriority
import java.util.concurrent.atomic.AtomicLong

/**
 * Pure, Android-independent priority queue for pending speech items. Kept
 * separate from [AndroidTextToSpeechEngine] (which needs a real device) so
 * the queueing and emergency-interruption behavior the roadmap explicitly
 * asks for tests of can be fully unit-tested without any audio engine.
 *
 * Ordering: higher [SpeechPriority] (by enum ordinal — EMERGENCY highest)
 * is always dequeued before lower priority, regardless of enqueue order.
 * Within the same priority, items are FIFO (insertion order preserved via
 * a monotonic sequence number).
 */
class PriorityQueueManager {

    data class SpeechItem(
        val text: String,
        val locale: LocaleTag,
        val priority: SpeechPriority,
        val sequenceNumber: Long
    )

    private val sequenceCounter = AtomicLong(0)
    private val items = mutableListOf<SpeechItem>()

    /**
     * Adds an item to the queue. Returns the item actually enqueued (so
     * callers can log/reference its sequence number).
     */
    fun enqueue(text: String, locale: LocaleTag, priority: SpeechPriority): SpeechItem {
        val item = SpeechItem(text, locale, priority, sequenceCounter.incrementAndGet())
        items.add(item)
        return item
    }

    /** Removes and returns the highest-priority, earliest-enqueued item, or null if empty. */
    fun dequeueNext(): SpeechItem? {
        if (items.isEmpty()) return null
        val next = items.maxWithOrNull(
            compareBy<SpeechItem> { it.priority.ordinal }.thenBy { -it.sequenceNumber }
        )
        items.remove(next)
        return next
    }

    fun peekNext(): SpeechItem? =
        items.maxWithOrNull(compareBy<SpeechItem> { it.priority.ordinal }.thenBy { -it.sequenceNumber })

    /**
     * Removes every queued item at or below [priority] (strictly lower, by
     * default) — used when an EMERGENCY item arrives and lower-priority
     * queued chatter should be dropped rather than spoken after it. The
     * EMERGENCY item itself (and anything at or above the given priority)
     * is preserved.
     */
    fun clearBelowPriority(priority: SpeechPriority) {
        items.removeAll { it.priority.ordinal < priority.ordinal }
    }

    fun clear() {
        items.clear()
    }

    fun isEmpty(): Boolean = items.isEmpty()

    fun size(): Int = items.size
}
