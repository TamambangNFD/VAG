package com.visionaid.audio.tts

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import com.visionaid.ai.tts.AudioOutputRoute
import com.visionaid.core.logging.VisionAidLogger

/**
 * Routes TTS audio output using Android's `AudioManager`. Handles the two
 * routes achievable with standard Android APIs today; [AudioOutputRoute.GLASSES]
 * is a declared future target with NO real implementation — same honest-
 * fallback pattern as Phase 9's `DisplayHardwareProfile`/`DisplayTarget`.
 * There is no glasses audio SDK integration anywhere in this project yet
 * (that's Phase 19/20's job); routing audio TO glasses requires hardware
 * that hasn't been selected.
 */
class AudioOutputRouter(private val context: Context) {

    private val audioManager: AudioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    private var currentRoute = AudioOutputRoute.PHONE_SPEAKER

    /** Returns true if the route was actually applied, false if unsupported/unavailable right now. */
    fun setRoute(route: AudioOutputRoute): Boolean {
        return when (route) {
            AudioOutputRoute.PHONE_SPEAKER -> {
                audioManager.isSpeakerphoneOn = true
                currentRoute = route
                true
            }
            AudioOutputRoute.BLUETOOTH -> {
                if (!isBluetoothAudioAvailable()) {
                    VisionAidLogger.w(TAG, "No connected Bluetooth audio device — cannot route to Bluetooth")
                    return false
                }
                audioManager.isSpeakerphoneOn = false
                currentRoute = route
                true
            }
            AudioOutputRoute.GLASSES -> {
                VisionAidLogger.w(
                    TAG,
                    "GLASSES output route requested but no glasses audio integration exists yet " +
                        "(Phase 19/20 pending) — route not applied."
                )
                false
            }
        }
    }

    fun getCurrentRoute(): AudioOutputRoute = currentRoute

    private fun isBluetoothAudioAvailable(): Boolean {
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        return devices.any {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
        }
    }

    companion object {
        private const val TAG = "AudioOutputRouter"
    }
}
