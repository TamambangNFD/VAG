package com.visionaid.audio.tts

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.LocaleTag
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolError
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.tts.AudioOutputRoute
import com.visionaid.ai.tts.SpeechPriority
import com.visionaid.ai.tts.TextToSpeechTool
import com.visionaid.core.logging.VisionAidLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Real implementation of Phase 12's [TextToSpeechTool], combining
 * [AndroidTextToSpeechEngine], [PriorityQueueManager], and
 * [AudioOutputRouter].
 *
 * EMERGENCY INTERRUPTION: a [SpeechPriority.EMERGENCY] item immediately
 * stops whatever is currently playing ([AndroidTextToSpeechEngine.stop])
 * and clears any lower-priority queued items ([PriorityQueueManager.clearBelowPriority]),
 * then is spoken next. Items at EMERGENCY priority queued behind each other
 * are preserved and spoken in order — only strictly-lower-priority chatter
 * is dropped. Per the Phase 2 interface's own documentation, deciding
 * whether an interrupted lower-priority item is ever resumed is Phase 18's
 * job, not this tool's — this tool only guarantees EMERGENCY speaks next.
 */
class RealTextToSpeechTool(
    private val engine: AndroidTextToSpeechEngine,
    private val router: AudioOutputRouter,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) : TextToSpeechTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    private val queue = PriorityQueueManager()
    private val queueMutex = Mutex()
    private var volume = 1.0f
    private var speechRate = 1.0f
    private var voiceId: String? = null
    private var processingJob: Job? = null
    private var currentlySpeaking = false

    init {
        engine.setUtteranceDoneListener { onUtteranceFinished() }
    }

    override fun availability(): ToolAvailability =
        if (engine.isReady()) ToolAvailability.AVAILABLE else ToolAvailability.UNAVAILABLE_MODEL_NOT_LOADED

    override suspend fun speak(text: String, locale: LocaleTag, priority: SpeechPriority): ToolResult<Unit> {
        if (!engine.isReady()) {
            return ToolResult.Failure(ToolError.ModelNotLoaded, System.currentTimeMillis())
        }
        if (text.isBlank()) {
            return ToolResult.Failure(ToolError.NoInputProvided, System.currentTimeMillis())
        }
        if (!engine.isLanguageOfflineAvailable(locale)) {
            return ToolResult.Failure(
                ToolError.InvalidInput("No offline voice installed for locale $locale"),
                System.currentTimeMillis()
            )
        }

        queueMutex.withLock {
            if (priority == SpeechPriority.EMERGENCY) {
                VisionAidLogger.i(TAG, "EMERGENCY speech — interrupting current playback and clearing lower-priority queue")
                engine.stop()
                currentlySpeaking = false
                queue.clearBelowPriority(SpeechPriority.EMERGENCY)
            }
            queue.enqueue(text, locale, priority)
        }

        processQueueIfIdle()

        return ToolResult.Success(Unit, Confidence.of(ConfidenceLevel.HIGH), System.currentTimeMillis())
    }

    private fun processQueueIfIdle() {
        if (currentlySpeaking) return
        processingJob = scope.launch {
            val next = queueMutex.withLock {
                if (currentlySpeaking) return@withLock null
                val item = queue.dequeueNext()
                if (item != null) currentlySpeaking = true
                item
            } ?: return@launch

            val utteranceId = engine.speak(next.text, next.locale, volume, speechRate, voiceId)
            if (utteranceId == null) {
                VisionAidLogger.e(TAG, "Failed to start speaking queued item")
                currentlySpeaking = false
                processQueueIfIdle()
            }
        }
    }

    private fun onUtteranceFinished() {
        currentlySpeaking = false
        processQueueIfIdle()
    }

    override fun stopAll() {
        engine.stop()
        currentlySpeaking = false
        queue.clear()
    }

    override fun setVolume(volume: Float) {
        this.volume = volume.coerceIn(0f, 1f)
    }

    override fun setSpeechRate(rate: Float) {
        this.speechRate = rate.coerceIn(0.5f, 2.0f)
    }

    override fun setVoice(voiceId: String?) {
        this.voiceId = voiceId
    }

    override fun setOutputRoute(route: AudioOutputRoute): Boolean = router.setRoute(route)

    override fun getCurrentOutputRoute(): AudioOutputRoute = router.getCurrentRoute()

    companion object {
        private const val TAG = "RealTextToSpeechTool"
    }
}
