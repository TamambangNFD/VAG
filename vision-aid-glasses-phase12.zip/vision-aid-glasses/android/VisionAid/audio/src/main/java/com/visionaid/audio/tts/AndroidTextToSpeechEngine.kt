package com.visionaid.audio.tts

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.visionaid.ai.common.LocaleTag
import com.visionaid.core.logging.VisionAidLogger
import java.util.Locale
import java.util.UUID

/**
 * Wraps Android's built-in `android.speech.tts.TextToSpeech` — chosen per
 * the roadmap's own suggestion ("Android TTS for initial prototype") and,
 * unlike Phase 8/11's OCR/ASR engine choices, this carries no Google Play
 * Services dependency concern: `TextToSpeech` is a public AOSP framework
 * API with a pluggable engine backend, not a GMS-specific service. See
 * MODEL_REGISTRY.md for the full writeup and the documented upgrade path
 * to a bundled neural engine (Piper/sherpa-onnx) for guaranteed
 * voice-quality consistency across devices.
 *
 * IMPORTANT: only OFFLINE-capable voices are used. Android's TTS framework
 * marks some voices as requiring network synthesis — this class explicitly
 * excludes those (see [isOfflineVoice]) rather than silently falling back
 * to a network voice, which would violate this project's offline-first
 * requirement.
 */
class AndroidTextToSpeechEngine(context: Context) {

    private var tts: TextToSpeech? = null
    private var initialized = false
    private val appContext = context.applicationContext

    private var onUtteranceDone: ((String) -> Unit)? = null

    init {
        tts = TextToSpeech(appContext) { status ->
            initialized = status == TextToSpeech.SUCCESS
            if (!initialized) {
                VisionAidLogger.e(TAG, "TextToSpeech engine failed to initialize (status=$status)")
            } else {
                VisionAidLogger.i(TAG, "TextToSpeech engine initialized")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        utteranceId?.let { onUtteranceDone?.invoke(it) }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {}
                })
            }
        }
    }

    fun isReady(): Boolean = initialized

    fun setUtteranceDoneListener(listener: (String) -> Unit) {
        onUtteranceDone = listener
    }

    fun isLanguageOfflineAvailable(locale: LocaleTag): Boolean {
        val engine = tts ?: return false
        val javaLocale = toJavaLocale(locale)
        val voices = try {
            engine.voices
        } catch (e: Exception) {
            null
        } ?: return false

        return voices.any { it.locale == javaLocale && isOfflineVoice(it) }
    }

    /** A voice is offline-capable if it does NOT declare the network-synthesis feature. */
    private fun isOfflineVoice(voice: Voice): Boolean =
        !voice.features.contains(TextToSpeech.Engine.KEY_FEATURE_NETWORK_SYNTHESIS) &&
            !voice.isNetworkConnectionRequired

    fun speak(text: String, locale: LocaleTag, volume: Float, rate: Float, voiceId: String?): String? {
        val engine = tts ?: return null
        if (!initialized) return null

        if (!isLanguageOfflineAvailable(locale)) {
            VisionAidLogger.w(TAG, "No offline voice available for locale $locale — refusing to use a network voice")
            return null
        }

        engine.language = toJavaLocale(locale)
        engine.setSpeechRate(rate)

        if (voiceId != null) {
            val match = engine.voices?.firstOrNull { it.name == voiceId }
            if (match != null) engine.voice = match
        }

        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceIn(0f, 1f))
        }
        val utteranceId = UUID.randomUUID().toString()
        val result = engine.speak(text, TextToSpeech.QUEUE_ADD, params, utteranceId)
        return if (result == TextToSpeech.SUCCESS) utteranceId else null
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.shutdown()
        tts = null
        initialized = false
    }

    private fun toJavaLocale(locale: LocaleTag): Locale = when (locale) {
        LocaleTag.ENGLISH -> Locale.ENGLISH
        LocaleTag.FRENCH -> Locale.FRENCH
    }

    companion object {
        private const val TAG = "AndroidTextToSpeechEngine"
    }
}
