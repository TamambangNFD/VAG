package com.visionaid.audio.tts

import com.visionaid.ai.common.LocaleTag
import com.visionaid.ai.tts.SpeechPriority
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Covers the roadmap's explicit Phase 12 requirement: "Create tests for
 * queueing and emergency interruption."
 */
class PriorityQueueManagerTest {

    @Test
    fun `same-priority items are dequeued in FIFO order`() {
        val queue = PriorityQueueManager()
        queue.enqueue("first", LocaleTag.ENGLISH, SpeechPriority.NORMAL)
        queue.enqueue("second", LocaleTag.ENGLISH, SpeechPriority.NORMAL)
        queue.enqueue("third", LocaleTag.ENGLISH, SpeechPriority.NORMAL)

        assertEquals("first", queue.dequeueNext()?.text)
        assertEquals("second", queue.dequeueNext()?.text)
        assertEquals("third", queue.dequeueNext()?.text)
    }

    @Test
    fun `higher priority item jumps ahead of lower priority items already queued`() {
        val queue = PriorityQueueManager()
        queue.enqueue("background chatter", LocaleTag.ENGLISH, SpeechPriority.NORMAL)
        queue.enqueue("obstacle warning", LocaleTag.ENGLISH, SpeechPriority.WARNING)

        assertEquals("obstacle warning", queue.dequeueNext()?.text)
        assertEquals("background chatter", queue.dequeueNext()?.text)
    }

    @Test
    fun `EMERGENCY item is always dequeued first regardless of queue order`() {
        val queue = PriorityQueueManager()
        queue.enqueue("normal item 1", LocaleTag.ENGLISH, SpeechPriority.NORMAL)
        queue.enqueue("important item", LocaleTag.ENGLISH, SpeechPriority.IMPORTANT)
        queue.enqueue("critical item", LocaleTag.ENGLISH, SpeechPriority.CRITICAL)
        queue.enqueue("STOP vehicle approaching", LocaleTag.ENGLISH, SpeechPriority.EMERGENCY)
        queue.enqueue("normal item 2", LocaleTag.ENGLISH, SpeechPriority.NORMAL)

        assertEquals("STOP vehicle approaching", queue.dequeueNext()?.text)
    }

    @Test
    fun `clearBelowPriority drops lower-priority items but keeps EMERGENCY and above`() {
        val queue = PriorityQueueManager()
        queue.enqueue("chatter 1", LocaleTag.ENGLISH, SpeechPriority.NORMAL)
        queue.enqueue("chatter 2", LocaleTag.ENGLISH, SpeechPriority.IMPORTANT)
        queue.enqueue("emergency 1", LocaleTag.ENGLISH, SpeechPriority.EMERGENCY)

        queue.clearBelowPriority(SpeechPriority.EMERGENCY)

        assertEquals(1, queue.size())
        assertEquals("emergency 1", queue.dequeueNext()?.text)
    }

    @Test
    fun `two EMERGENCY items preserve relative FIFO order between themselves`() {
        val queue = PriorityQueueManager()
        queue.enqueue("emergency A", LocaleTag.ENGLISH, SpeechPriority.EMERGENCY)
        queue.enqueue("emergency B", LocaleTag.ENGLISH, SpeechPriority.EMERGENCY)

        assertEquals("emergency A", queue.dequeueNext()?.text)
        assertEquals("emergency B", queue.dequeueNext()?.text)
    }

    @Test
    fun `dequeue on empty queue returns null`() {
        assertNull(PriorityQueueManager().dequeueNext())
    }

    @Test
    fun `peekNext does not remove the item`() {
        val queue = PriorityQueueManager()
        queue.enqueue("only item", LocaleTag.ENGLISH, SpeechPriority.NORMAL)

        assertEquals("only item", queue.peekNext()?.text)
        assertEquals(1, queue.size())
    }

    @Test
    fun `clear empties the queue entirely`() {
        val queue = PriorityQueueManager()
        queue.enqueue("a", LocaleTag.ENGLISH, SpeechPriority.NORMAL)
        queue.enqueue("b", LocaleTag.ENGLISH, SpeechPriority.CRITICAL)
        queue.clear()
        assertTrue(queue.isEmpty())
    }

    @Test
    fun `priority ordering follows NORMAL less than IMPORTANT less than WARNING less than CRITICAL less than EMERGENCY`() {
        val queue = PriorityQueueManager()
        // Enqueue in reverse-priority order; dequeue should come out highest-first.
        listOf(
            SpeechPriority.NORMAL, SpeechPriority.IMPORTANT, SpeechPriority.WARNING,
            SpeechPriority.CRITICAL, SpeechPriority.EMERGENCY
        ).reversed().forEach { queue.enqueue(it.name, LocaleTag.ENGLISH, it) }

        val order = generateSequence { queue.dequeueNext() }.map { it.priority }.toList()
        assertEquals(
            listOf(
                SpeechPriority.EMERGENCY, SpeechPriority.CRITICAL, SpeechPriority.WARNING,
                SpeechPriority.IMPORTANT, SpeechPriority.NORMAL
            ),
            order
        )
    }
}
