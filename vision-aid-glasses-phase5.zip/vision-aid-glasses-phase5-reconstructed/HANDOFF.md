# Vision Aid Glasses — Latest Handoff

## Last completed phase
Phase 5 — Depth and Distance (**SAFETY-CRITICAL — signed off by Tammy, 2026-09-20**)

*(Note: this file was originally written with sign-off still pending. Tammy
subsequently reviewed CALIBRATION.md and the depth code and signed off —
see VERIFICATION.md and PROGRESS.md, both updated to reflect that. This
HANDOFF.md's body text below is otherwise unchanged from what was written
at the time the phase was built.)*

## What was built
- **Interface fix:** `ai.depth.DepthTool.estimateDistance()` was changed
  from taking `objectIds: List<String>` to `detectedObjects: List<DetectedObject>`
  — the Phase 2 signature couldn't actually support real distance estimation
  since it didn't carry bounding boxes. `MockDepthTool` and its test were
  updated to match; nothing else depended on the old signature.
- `CameraHardwareProfile`/`DepthCapability` (`vision/depth/`): the hardware
  capability abstraction the roadmap explicitly requires ("do not assume the
  selected glasses provide two synchronized cameras"). Defaults to `UNKNOWN`
  capability since glasses hardware is still TBD.
- `CalibrationConfig`: calibration data shape (normalized focal length,
  per-class reference heights, reliable-box-height bounds). Ships with
  placeholder population-average reference heights for PERSON, BICYCLE,
  MOTORCYCLE, CHAIR, TABLE only — classes with too much size variance
  (CAR, VEHICLE, BAG, BOTTLE, OTHER) are deliberately omitted so they
  always report UNKNOWN rather than a meaningless guess.
- `MonocularSizeBasedDepthEstimator`: pure, Android-independent pinhole-
  camera size-based distance heuristic, with conservative UNKNOWN fallback
  for: no calibration, no reference size for the label, box too small, box
  too large/clipped, and — importantly — any estimate within ±15% of the
  NEAR/MEDIUM or MEDIUM/FAR boundary.
- `RealDepthTool`: wires the above together. Stereo capability declared but
  unimplemented falls back to UNKNOWN (loudly logged) rather than
  fabricating a stereo pipeline. Monocular path confidence is **permanently
  capped at LOW**, even for a clean-looking estimate.
- `CALIBRATION.md`: full calibration requirements, accuracy limitations, and
  failure-condition table, as explicitly required by the phase spec.
- 18 new unit tests across 3 files (`MockDepthToolTest` updated: 3 cases,
  `MonocularSizeBasedDepthEstimatorTest`: 10 cases, `RealDepthToolTest`:
  4 cases) — every "should be UNKNOWN" case is a deliberate safety assertion.

## Decisions made this phase
- **Monocular size-based heuristic chosen as the only implemented path**,
  since stereo hardware doesn't exist/isn't chosen yet. This is explicitly
  the roadmap's suggested fallback ("optional monocular depth model" /
  "hardware capability abstraction").
- **Confidence permanently capped at LOW for the monocular path** — not a
  per-estimate judgment, a blanket policy, because the technique itself is
  unvalidated against real-world measurements. Raising this cap requires
  real field validation (Phase 29/31), not a code change alone.
- **±15% boundary margin around NEAR/MEDIUM and MEDIUM/FAR thresholds**,
  mapped to UNKNOWN rather than committed — directly implements "prefer
  UNKNOWN over false precision" at exactly the point where a wrong call is
  most consequential.
- **No reference height for classes with high size variance** (CAR, VEHICLE,
  BAG, BOTTLE, OTHER) — rather than use a population average that could be
  badly wrong for these classes.

## False-negative / false-positive analysis (required for this safety-critical phase)
- **False negative risk** (failing to flag a genuinely NEAR object): reduced
  by the boundary margin — an object whose true distance is right around
  1.5m will report UNKNOWN rather than being confidently mis-banded as
  MEDIUM. However, a genuine false negative is still possible if the
  object's real-world size deviates sharply from the assumed reference
  (e.g. a crouching or unusually short person could appear farther than
  they are). This is a known, documented limitation of monocular size-based
  estimation with no complete fix short of real depth sensing (stereo/ToF).
- **False positive risk** (reporting NEAR when the object is not): same
  boundary-margin mitigation applies symmetrically. The larger residual risk
  is an unusually large person/object (e.g. someone carrying a large bag
  merged into one detection) appearing closer than reality.
- **Net design posture:** confidence is capped at LOW specifically so that
  no downstream consumer (Phase 16 Obstacle Avoidance, Phase 17 Traffic
  Safety) can mistake this heuristic for a validated measurement. Those
  phases must treat LOW-confidence depth as, at most, a weak supporting
  signal — never a sole basis for a safety decision.

## Interfaces exposed (for next phases to depend on)
- `RealDepthTool` implements `ai.depth.DepthTool` — same contract as the
  updated Phase 2 mock. Phase 6 (World Model) can consume either.
- `CameraHardwareProfile`/`CalibrationConfig` are the shape any future real
  stereo implementation (post Phase 19) should also produce/consume, rather
  than inventing a parallel hardware-description mechanism.

## Known issues / limitations
- **No real hardware, no real calibration exist.** Every number this code
  produces today is illustrative only. See CALIBRATION.md in full.
- **Stereo path is entirely unimplemented** — intentionally, since there's
  no real stereo hardware/data to build or validate against yet.
- **Build/test execution not verified in this sandbox**, same limitation as
  every prior phase. The new tests are pure JVM (no Android dependency) —
  same situation as Phase 4's tracking tests.
- Phase 3's model file and Phase 3/4 build confirmations are still open from
  before — not resolved by this phase.

## What the next phase needs to know
- Phase 6 (Spatial World Model) reads this HANDOFF.md and confirms Phase 5's
  sign-off before proceeding, per the roadmap's Definition of Ready
  protocol — that sign-off has now happened (see note at top of this file).
- Whoever reviews this should specifically check: does `RealDepthTool` ever
  report a confidence above LOW for the monocular path? Does it ever skip
  the boundary-margin UNKNOWN check? Does the stereo path ever produce a
  non-UNKNOWN result? These three properties are the safety-critical
  guarantees this phase is supposed to provide.

## Git checkpoint
Tag: phase-5-complete
Commit message: `Phase 5: depth and distance estimation (safety-critical, hardware-abstracted, monocular heuristic)`

## Verification status
See VERIFICATION.md — Phase 5: PASSED, signed off by Tammy on 2026-09-20.
