plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.visionaid.vision"
    compileSdk = 34

    defaultConfig {
        minSdk = 26
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // Model files are large binary assets provided by the product owner
    // (roadmap: "Me: download or provide model files") — never compressed
    // out or committed as a placeholder, and never fabricated by this build.
    androidResources {
        noCompress += listOf("tflite")
    }
}

dependencies {
    implementation(project(":core"))
    implementation(project(":ai"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.1")

    // LiteRT (TensorFlow Lite) — Apache 2.0. Chosen over ONNX Runtime for
    // Phase 3 because of tighter first-party Android tooling and smaller
    // runtime footprint for a single SSD-style detection model. See
    // MODEL_REGISTRY.md for the full rationale.
    implementation("org.tensorflow:tensorflow-lite:2.16.1")
    implementation("org.tensorflow:tensorflow-lite-support:0.4.4")
    implementation("org.tensorflow:tensorflow-lite-metadata:0.4.4")

    // CameraX — for the camera frame -> preprocessing pipeline.
    val cameraxVersion = "1.3.4"
    implementation("androidx.camera:camera-core:$cameraxVersion")
    implementation("androidx.camera:camera-camera2:$cameraxVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraxVersion")


    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
}
