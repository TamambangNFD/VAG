# Vision Aid Glasses — Latest Handoff

## Last completed phase
Phase 8 — OCR and Document Reading

## What was built
- `RealOCRTool` (`vision/ocr/`): real implementation of Phase 2's `OCRTool`,
  using Tesseract (via Tesseract4Android). Locale from `FrameContext.locale`
  passed straight through — never hard-coded.
- `RealDocumentTool` (`vision/document/`): real implementation of Phase 2's
  `DocumentTool`, running the full pipeline the roadmap specifies: document
  detection → perspective correction → image enhancement → OCR → text
  ordering → paragraph extraction. Stateful `readNext`/`readPrevious`/
  `readAll` navigation over the resulting paragraphs, same contract as the
  Phase 2 mock.
- `TesseractOcrEngine`: wraps Tesseract4Android; handles the required
  one-time copy of `.traineddata` files from APK assets to app-private
  storage (Tesseract can't read them directly from assets); reports
  unavailability cleanly when language data isn't supplied.
- `TextOrderer`/`ParagraphGrouper`: pure, fully unit-tested logic (11 test
  cases total) — top-to-bottom/left-to-right reading-order sorting and
  vertical-gap-based paragraph grouping.
- `SimpleDocumentDetector`/`DocumentCorners`/`PerspectiveCorrector`/
  `ImageEnhancer`: document-crop pipeline. Perspective correction and
  enhancement are real, working implementations; document *edge detection*
  is a documented heuristic limitation (see below).
- `MODEL_REGISTRY.md` extended with the OCR engine decision and the
  document-detection limitation.
- 12 new unit tests total (`TextOrdererTest`: 5, `ParagraphGrouperTest`: 5,
  `DocumentCornersTest`: 1 — plus the OCR/document pipeline classes
  requiring Android runtime, not unit-testable in plain JVM).

## Decisions made this phase
- **OCR engine: Tesseract (Apache 2.0), not Google ML Kit.** ML Kit is free
  and likely more accurate, but depends on Google Play Services — not
  guaranteed present on every device in the target market (Cameroon).
  Tesseract has zero such dependency and is fully offline. Documented in
  `MODEL_REGISTRY.md`, revisitable if field testing shows accuracy is
  insufficient and Play Services access is confirmed reliable.
- **Document edge/corner detection is NOT really implemented.**
  `SimpleDocumentDetector` assumes the document fills the frame. Real
  corner detection against a cluttered background typically needs a full CV
  library (OpenCV), which was judged out of proportion for this phase.
  Perspective correction itself is real and works via Android's native
  `Matrix.setPolyToPoly` — only the corner-*finding* step is a placeholder.
  This is the same kind of documented trade-off as Phase 4's greedy tracker
  or Phase 5's monocular depth heuristic.
- **Image enhancement is a simple global contrast stretch**, not adaptive
  thresholding or shadow removal — a reasonable first cut, not a complete
  document-scanning quality pipeline.

## Interfaces exposed (for next phases to depend on)
- `RealOCRTool`/`RealDocumentTool` implement the exact Phase 2 interfaces —
  Phase 13 (Agent) can wire either the mocks or these real implementations
  in without any contract changes.
- `TextOrderer`/`ParagraphGrouper` are reusable pure utilities if any future
  phase needs reading-order or paragraph-grouping logic elsewhere.

## Known issues / limitations
- **Document edge detection is a heuristic, not real CV** (see above) — the
  single most important limitation to carry forward. If real-world testing
  (Phase 29) shows users struggle to frame documents without page-boundary
  guidance, this is the component to revisit.
- **Language data files (`eng.traineddata`, `fra.traineddata`) are not in
  the repo** — same pattern as Phase 3/7's model files. Must be downloaded
  and placed per `MODEL_REGISTRY.md` before OCR will report `AVAILABLE`.
- **Build/test execution not verified in this sandbox**, same limitation as
  every prior phase. The pure-logic tests (`TextOrdererTest`,
  `ParagraphGrouperTest`, `DocumentCornersTest`) are plain JVM;
  `RealOCRTool`/`RealDocumentTool`/`TesseractOcrEngine`/`PerspectiveCorrector`/
  `ImageEnhancer` need Android runtime (Bitmap, Canvas, Matrix, Tesseract's
  native library) and would need instrumented tests — not written yet, same
  situation as Phase 3's camera/TFLite code and Phase 7's face detection.
- No "performance tests using sample documents" were written, since no
  sample documents or a running Tesseract instance exist in this sandbox to
  test against — flagged as a deviation from the phase spec's literal
  wording, similar to Phase 5's stereo-image-test deviation.

## What the next phase needs to know
- Phase 9 (Low Vision Magnification) is independent of OCR/document
  reading, though it may eventually share the camera frame source
  (`vision/camera/CameraFrameSource`) — no blocking dependency.
- Whoever eventually adds real document-edge detection should replace
  `SimpleDocumentDetector` behind the existing `DocumentDetector` interface
  — no changes needed to `RealDocumentTool` or anything downstream.

## Git checkpoint
Tag: phase-8-complete
Commit message: `Phase 8: offline OCR and document reading (Tesseract, full pipeline)`
Commit hash: <create when you commit this to your actual repository>

## Verification status
See VERIFICATION.md — Phase 8: PASSED WITH NOTES. Not safety-critical, no
sign-off gate.
