# Vision Aid Glasses — Latest Handoff

## Last completed phase
Phase 4 — Object Tracking

## What was built
- `IouObjectTrackingTool` (`vision/tracking/`): real implementation of
  Phase 2's `ObjectTrackingTool` interface, replacing `MockObjectTrackingTool`
  for production use. Uses greedy IoU-based association across frames.
- `IouCalculator`: pure geometry (IoU, box area, box center) used by both
  the matcher and the movement-estimation heuristic.
- `GreedyTrackMatcher`: pure, testable same-label greedy matching between
  the previous frame's tracks and the current frame's detections.
- 15 new unit tests across 3 files: `IouCalculatorTest` (3 cases),
  `GreedyTrackMatcherTest` (4 cases), and — per the phase spec's explicit
  requirement — `IouObjectTrackingToolTest` (8 cases), which exercises
  **recorded, hand-authored detection sequences**: a person walking left-to-right keeping a stable ID,
  frame-count incrementing correctly, brief occlusion NOT creating a new ID,
  prolonged occlusion correctly creating a new ID on reappearance, a second
  object entering the frame with a fresh ID and UNKNOWN movement, duplicate-
  ID prevention, `reset()` clearing state, and the area-growth
  APPROACHING heuristic.
- Extended `AI_TOOL_ARCHITECTURE.md` with a "Phase 4 Update" section
  documenting the real implementation and its limitations.

## Decisions made this phase (made autonomously per the working agreement from Phase 3)
- **Tracking algorithm: greedy IoU-based matching**, not a full ByteTrack/
  Kalman-filter tracker. Chosen as the roadmap's "another suitable
  lightweight tracker" option — appropriate for mobile CPU constraints and
  avoids pulling in a heavier tracking library/dependency for a first cut.
- **Missed-frame tolerance: 5 frames** before a track is dropped (tunable
  constructor parameter) — balances not losing an ID during brief occlusion
  against not accumulating stale tracks forever.
- **IoU match threshold: 0.3**, same-label only — same rationale, tunable.
- **APPROACHING/RECEDING inferred from bounding-box area change**, not real
  depth (none exists until Phase 5). This is explicitly flagged in code
  comments and here as a heuristic that must NOT be treated as
  depth-equivalent by any future safety-critical consumer (Phases 16-17).

## Interfaces exposed (for next phases to depend on)
- `IouObjectTrackingTool` implements `ai.tracking.ObjectTrackingTool` — same
  contract as the Phase 2 mock, so Phase 5 (Depth) and Phase 6 (World Model)
  can consume either interchangeably.
- `IouCalculator`/`GreedyTrackMatcher` are available if a future phase needs
  IoU geometry or greedy matching for something else (e.g. a different
  association problem), rather than reimplementing it.

## Known issues / limitations
- **No motion prediction.** A fast-moving object that displaces more than
  roughly its own box size between frames can drop below the IoU threshold
  and get a new track ID. True ByteTrack/SORT-style Kalman filtering would
  fix this; deliberately not attempted in Phase 4 to keep this phase's scope
  to "a suitable lightweight tracker," not a state-of-the-art one.
- **Greedy matching is not globally optimal.** Two same-label objects that
  overlap heavily and cross paths can occasionally have their IDs swapped.
  A Hungarian-algorithm assignment would fix this at extra computational
  cost; left as a documented upgrade path.
- **APPROACHING/RECEDING is a heuristic, not real depth** (see above) — this
  is the most important limitation to carry forward into Phases 5-6.
- **Build/test execution not verified in this sandbox**, same limitation as
  every prior phase. All new Kotlin was hand-reviewed for correctness; the
  15 new tests are pure JVM (no Android framework dependency), so once you
  can run `./gradlew test`, they should be able to run without a device or
  emulator, unlike the vision module's Phase 3 camera/TFLite code.
- Phase 3's outstanding items (model file placement, on-device build
  confirmation) are still open — not resolved by this phase.

## What the next phase needs to know
- Phase 5 (Depth and Distance) is **safety-critical** — it must default to
  UNKNOWN/conservative output, and no safety-critical phase (5, 16, 17, 18,
  31) may be marked complete without your explicit sign-off in
  VERIFICATION.md, regardless of the general delegation of technical
  choices to Claude. This is unchanged from the roadmap's Section 0.4.
- Phase 5 will need to decide whether the target glasses expose stereo
  cameras (unknown — hardware still TBD per PRODUCT_SPEC.md) or whether to
  build the monocular-depth fallback path first. Given hardware is still
  undecided, the monocular path is the more useful investment right now —
  I'll proceed on that basis unless you tell me otherwise.
- `IouObjectTrackingTool.update()`'s `TrackedObject.movement` field will
  need to be reconciled with real depth data in Phase 5/6 — the current
  APPROACHING/RECEDING heuristic should probably be deprecated or clearly
  subordinated to real distance once that data exists.

## Git checkpoint
Tag: phase-4-complete
Commit message: `Phase 4: multi-object tracking with greedy IoU association`
Commit hash: <create when you commit this to your actual repository>

## Verification status
See VERIFICATION.md — Phase 4: PASSED WITH NOTES (source complete, tests are
pure-JVM and don't require a device; Gradle build/test run still needs your
confirmation, same as every prior phase).
