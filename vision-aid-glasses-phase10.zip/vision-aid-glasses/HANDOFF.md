# Vision Aid Glasses — Latest Handoff

## Last completed phase
Phase 10 — Currency Recognition

## The headline decision this phase
**Found a clean, properly licensed, purpose-built model this time** — unlike
Phase 7's face-recognition gap. Microsoft's BankNote-Net encoder was built
specifically for assistive currency recognition (it powers Seeing AI),
licensed CDLA-Permissive-2.0 (dataset) / MIT (code), with a citable paper.
It doesn't cover Central African CFA franc (XAF) out of the box, but its own
documented design anticipates exactly this: few-shot transfer to a new
currency via the pretrained encoder plus a handful of real reference images
per denomination. Full reasoning in `MODEL_REGISTRY.md`.

## What was built
- **Interface change:** `CurrencyCode` was a closed `enum class` with only
  `XAF`. Changed to an open value type (`data class CurrencyCode(val
  isoCode: String)`, `CurrencyCode.XAF` preserved as a companion constant)
  so a future currency never requires editing this shared interface —
  existing call sites unchanged.
- `TfLiteBankNoteNetEncoder` (`vision/currency/`): wraps a TFLite conversion
  of BankNote-Net's encoder (224x224 input, 256-dim embedding output).
- `ReferenceEmbeddingStore`: loads product-owner-collected reference
  embeddings for XAF denominations from a bundled JSON asset.
- `CurrencyClassifier`: pure nearest-neighbor matching — **reuses Phase 7's
  `EmbeddingSimilarity.cosineSimilarity` rather than duplicating the math**.
  Matches against every reference embedding per denomination (not a single
  averaged centroid), for robustness to lighting/angle variation.
- `ImageQualityValidator`: simple grayscale contrast-range heuristic
  satisfying the roadmap's explicit image-quality-validation requirement
  (documented as not a real blur-detection algorithm).
- `RealCurrencyRecognitionTool`: orchestrates the above — quality check →
  embedding → nearest-neighbor match → threshold (0.80 cosine similarity) →
  denomination or null, never a guessed low-confidence result.
- `datasets/DATASET_PROVENANCE.md` (new file): tracks the XAF reference-
  image collection requirement, explicitly prohibiting stock photography as
  a source (its standard licenses don't cover ML feature-extraction use).
- `MODEL_REGISTRY.md` extended with the full encoder decision, XAF-gap
  explanation, and exactly what the product owner needs to collect.
- 10 new unit tests (`CurrencyClassifierTest`: 6, `ImageQualityValidatorTest`: 4).

## Decisions made this phase
- **Encoder: Microsoft BankNote-Net** (CDLA-Permissive-2.0/MIT) — clean
  provenance, purpose-built for this exact use case.
- **Recognition threshold: 0.80 cosine similarity** — placeholder pending
  real reference photos to validate against.
- **Nearest-neighbor over per-denomination centroid averaging** — keeps
  each reference photo's distinct lighting/angle information rather than
  blurring it into one average vector.
- **Reference embeddings, not raw images, stored on-device** — smaller
  footprint, and (as BankNote-Net's own license notes) embeddings shouldn't
  be used to reconstruct source images anyway.

## Interfaces exposed (for next phases to depend on)
- `RealCurrencyRecognitionTool` implements `ai.currency.CurrencyRecognitionTool`
  — same contract as the Phase 2 mock (now with the open `CurrencyCode` type).
- `CurrencyClassifier`'s pattern (pure nearest-neighbor over an
  `EmbeddingSimilarity`-based similarity function) is reusable if any future
  phase needs similar few-shot classification.

## Known issues / limitations
- **Two things must still be supplied before this works end-to-end:**
  1. The BankNote-Net encoder converted to `.tflite` (Keras→TFLite
     conversion is a one-time offline step, not performed in this repo).
  2. Real XAF reference photos (NOT stock photography) run through that
     encoder to populate `currency_reference_embeddings.json`.
  Both tracked in `MODEL_REGISTRY.md` and `datasets/DATASET_PROVENANCE.md`.
- **Image-quality validation is a simple heuristic**, not real blur
  detection — same class of trade-off as Phase 8's document-edge limitation.
- **Recognition threshold (0.80) is unvalidated** — needs real-world tuning
  once reference photos and test notes exist.
- **Build/test execution not verified in this sandbox**, same limitation as
  every prior phase. The 10 new tests are pure JVM;
  `RealCurrencyRecognitionTool`/`TfLiteBankNoteNetEncoder`/
  `ReferenceEmbeddingStore` need Android runtime and would need instrumented
  tests — not written yet.
- No counterfeit detection — correctly out of scope per the phase spec.
- **This sandbox's working directory was reset mid-phase and restored from
  the last delivered zip (Phase 9)** — Phase 10's files were then rebuilt
  from scratch matching exactly what was already reported before the reset.
  Worth a slightly closer look than usual when you review this phase's zip,
  though the content should be identical to what was already described.

## What the next phase needs to know
- Phase 11 (Offline Speech Recognition) is independent of currency
  recognition — no blocking dependency.
- Whoever collects the XAF reference photos should fill in
  `datasets/DATASET_PROVENANCE.md`'s collection-method details at that time
  — it's deliberately left as a tracked placeholder, not filled with
  invented details.

## Git checkpoint
Tag: phase-10-complete
Commit message: `Phase 10: currency recognition (BankNote-Net encoder + XAF few-shot classifier)`
Commit hash: <create when you commit this to your actual repository>

## Verification status
See VERIFICATION.md — Phase 10: PASSED WITH NOTES. Not safety-critical, no
sign-off gate.
