package com.visionaid.ai.face

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Local, offline face detection/enrollment/recognition.
 *
 * Input contract: a [FrameContext] for [recognize]; a [FrameContext] plus a
 * person name for [enroll].
 * Output contract: [RecognitionOutput] — zero or more [RecognizedFace]
 * results. A face below the confidence threshold is reported as
 * [RecognizedFace.personId] == null with confidence LOW/UNKNOWN, never as a
 * guessed identity (roadmap Phase 7: "never claim identity when confidence
 * is below the configured threshold").
 *
 * Privacy: enrollment requires explicit user consent, captured by the
 * caller (Phase 7's UI layer) before invoking [enroll]. This interface does
 * not enforce consent capture itself, but no implementation may call
 * [enroll] without it having already happened.
 *
 * Offline capability: OFFLINE_ONLY. Face data is never uploaded.
 */
interface FaceRecognitionTool {

    val operationMode: OperationMode

    fun availability(): ToolAvailability

    suspend fun recognize(frame: FrameContext): ToolResult<RecognitionOutput>

    suspend fun enroll(frame: FrameContext, personName: String): ToolResult<EnrollmentOutput>

    suspend fun rename(personId: String, newName: String): ToolResult<Unit>

    suspend fun remove(personId: String): ToolResult<Unit>

    fun setEnabled(enabled: Boolean)
}

data class RecognitionOutput(
    val faces: List<RecognizedFace>
)

data class RecognizedFace(
    /** Null when confidence is below the recognition threshold — an unknown face. */
    val personId: String?,
    val personName: String?,
    val boundingBoxLeft: Float,
    val boundingBoxTop: Float,
    val boundingBoxRight: Float,
    val boundingBoxBottom: Float
)

data class EnrollmentOutput(
    val personId: String,
    val personName: String
)
