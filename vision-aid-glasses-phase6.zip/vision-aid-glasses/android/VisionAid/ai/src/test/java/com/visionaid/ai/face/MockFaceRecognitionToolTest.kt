package com.visionaid.ai.face

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MockFaceRecognitionToolTest {

    private fun frame() = FrameContext(frameId = 1L, imageData = ByteArray(0), captureTimestampMillis = 1000L)

    @Test
    fun `recognize on empty enrollment returns unknown face, not a guessed identity`() = runBlocking {
        val tool = MockFaceRecognitionTool()
        val result = tool.recognize(frame()) as ToolResult.Success
        assertNull(result.data.faces.first().personId)
    }

    @Test
    fun `enroll then recognize-adjacent rename updates stored name`() = runBlocking {
        val tool = MockFaceRecognitionTool()
        val enrolled = (tool.enroll(frame(), "David") as ToolResult.Success).data
        val renameResult = tool.rename(enrolled.personId, "Dave")
        assertEquals(true, renameResult is ToolResult.Success)
    }

    @Test
    fun `disabling the tool changes availability`() {
        val tool = MockFaceRecognitionTool()
        tool.setEnabled(false)
        assertEquals(ToolAvailability.DISABLED_BY_USER, tool.availability())
    }

    @Test
    fun `rename of unknown personId fails`() = runBlocking {
        val tool = MockFaceRecognitionTool()
        val result = tool.rename("nonexistent-id", "New Name")
        assertEquals(true, result is ToolResult.Failure)
    }
}
