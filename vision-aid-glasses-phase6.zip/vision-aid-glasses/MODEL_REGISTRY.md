# Vision Aid Glasses — Model Registry

Tracks every AI model used in the product: name, version, size, license,
runtime, accuracy/latency, and rollback plan. Updated every phase that
integrates or changes a model (Phases 3, 7, 10, 23, 26 per the roadmap).

---

## Object Detection — SSD MobileNetV2 FPN-Lite 320×320 (Phase 3)

| Field | Value |
|---|---|
| Model name | SSD MobileNetV2 FPN-Lite 320x320 (COCO-pretrained, quantized) |
| Source | TensorFlow Lite Object Detection model zoo / TensorFlow Model Garden |
| Version | TFLite metadata-packaged release, INT8 quantized |
| Runtime | LiteRT (TensorFlow Lite) via `org.tensorflow:tensorflow-lite` 2.16.1 + `tensorflow-lite-support`/`tensorflow-lite-metadata` 0.4.4, using the TFLite Task Library's `ObjectDetector` API |
| License | **Apache License 2.0** |
| Approx. model size | ~4-7 MB (quantized) — exact size depends on which published checkpoint is downloaded; confirm against the actual file once obtained |
| Accuracy / latency | Not yet measured on-device — vendor-published COCO mAP figures exist but have not been independently verified against this project's target phone. **Do not treat vendor benchmarks as this product's confirmed accuracy** until Phase 3 field testing (and later Phase 29) produces real numbers. |
| Rollback plan | None needed yet — this is the first model in this slot. If a future update regresses accuracy, revert to this same model/version by re-downloading it at this documented source and reverting `LiteRtObjectDetectionTool`'s `MODEL_ASSET_PATH` file to this version. |

### Why this model and license, not YOLO

YOLOv8 (Ultralytics) was considered and rejected for this slot because it is
distributed under **AGPL-3.0**, which carries commercial-use and
source-disclosure obligations unless a separate commercial license is
purchased from Ultralytics. Since Vision Aid Glasses' commercial-use
implications are not yet decided (see PRODUCT_SPEC.md non-goals/roadmap
Phase 34+), an Apache-2.0-licensed model avoids that risk entirely with no
downside for an initial SSD-class detector. This decision should be
revisited if a future phase has a specific accuracy requirement only YOLO
can meet — at that point, budget for an Ultralytics commercial license or
find another permissively licensed YOLO-family checkpoint.

### Known class-coverage gap — READ BEFORE RELYING ON THIS MODEL

COCO's category set does **not** include several object classes the
roadmap's Phase 0 target list asks for. This model can **never** produce:

- `DOOR`
- `STAIRS`
- `POLE`
- `ROAD`
- `SIDEWALK`
- `WALL`

This is enforced in code, not just documented: see
`CocoLabelMap.UNSUPPORTED_ROADMAP_LABELS` and its accompanying test in the
`vision` module, which fails if any COCO index is ever accidentally mapped
to one of these labels. Closing this gap requires one of:

1. A custom-trained/fine-tuned detection model (needs a licensed, provenance-
   documented dataset — see `datasets/DATASET_PROVENANCE.md` requirement).
2. A different technique entirely for some classes — e.g. semantic
   segmentation for ROAD/SIDEWALK, a dedicated stair-detection model.
3. Accepting the gap for V1 and revisiting at Phase 27 (Hardware Gap
   Analysis) or a dedicated future phase.

This gap does not block Phase 3 (which only requires *a* working detector),
but it must be carried forward honestly into every later phase that assumes
door/stair/pole/road/sidewalk/wall detection exists (notably Phase 16
Obstacle Avoidance and Phase 17 Traffic Safety) — those phases must either
work around this gap explicitly or trigger closing it first.

### How to obtain the model file

The actual `.tflite` binary is **not included in this repository** (it's a
multi-megabyte binary asset, and per the roadmap, model file provisioning is
the product owner's task). To use this implementation:

1. Obtain an SSD MobileNetV2 FPN-Lite 320x320 TFLite model with metadata
   (the TFLite Task Library requires the metadata-packaged variant, not a
   bare graph) from the official TensorFlow Lite / TensorFlow Model Garden
   distribution channels.
2. Verify its license file states Apache 2.0 (it should, as part of the
   TensorFlow project) before shipping it in the app.
3. Place it at: `android/VisionAid/vision/src/main/assets/ssd_mobilenet_v2_fpnlite_320.tflite`
   (this exact filename is referenced by
   `LiteRtObjectDetectionTool.MODEL_ASSET_PATH`).
4. Rebuild. `LiteRtObjectDetectionTool.availability()` will report
   `UNAVAILABLE_MODEL_NOT_LOADED` until the file is present and loads
   successfully — this was verified in the code path (see
   `HANDOFF.md`/`VERIFICATION.md`) but the actual load has not been tested
   against a real file in this sandbox.
