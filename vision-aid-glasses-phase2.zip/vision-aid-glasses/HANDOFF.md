# Vision Aid Glasses — Latest Handoff

## Last completed phase
Phase 2 — AI Tool Architecture

## What was built
- All 11 tool interfaces required by the phase spec, in `android/VisionAid/ai/`:
  `ObjectDetectionTool`, `ObjectTrackingTool`, `DepthTool`, `FaceRecognitionTool`,
  `OCRTool`, `CurrencyRecognitionTool`, `NavigationTool`, `DocumentTool`,
  `SafetyTool`, `SpeechRecognitionTool`, `TextToSpeechTool`.
- Shared contracts in `ai/common/`: `ToolResult<T>`, `Confidence`/`ConfidenceLevel`,
  `ToolError`, `ToolAvailability`, `OperationMode`, `FrameContext`, `LocaleTag`.
  Every tool interface is built from these, so callers handle any tool the
  same way.
- A deterministic mock implementation for every tool (`Mock*Tool`), so the
  complete data flow can be exercised without any real model.
- 13 unit test files (28 main source files total across interfaces + mocks).
- `AI_TOOL_ARCHITECTURE.md` documenting every interface's input/output
  contract, confidence representation, and offline/online mode.
- Added `kotlinx-coroutines-core`/`-test` dependencies to the `ai` module
  (tool methods are `suspend fun`s, anticipating real async inference work).

## Decisions made this phase
- **Depth and Safety mocks always return `UNKNOWN`** rather than any
  plausible-looking value — a deliberate choice so every downstream consumer
  built during Phases 3-15 is forced to handle the uncertain case correctly
  from day one, consistent with Section 0.4 of the roadmap.
- Confidence is represented as a 4-level enum (`UNKNOWN/LOW/MEDIUM/HIGH`)
  plus an optional raw float score, rather than a raw float alone — callers
  branch on the discrete level, not the score.
- `ToolError` (genuine failures) is kept strictly separate from "successful
  but low-confidence/empty" results — no tool throws or returns `Failure`
  for "nothing found."
- `FrameContext.imageData` is an opaque `ByteArray` for now; the real pixel
  format is deferred to Phase 3 once a specific model/runtime is chosen.
- Tool methods are Kotlin `suspend fun`s in anticipation of real on-device
  inference; mocks return immediately since they do no real work.

## Interfaces exposed (for next phases to depend on)
- All 11 tool interfaces above, each with the input/output contract
  documented in `AI_TOOL_ARCHITECTURE.md`. Phase 3 implements
  `ObjectDetectionTool` for real; Phases 4-12 do the same for the rest in
  roadmap order.
- `ai/common/*` — the shared envelope types every future phase's real
  implementation must use (don't invent a parallel result/error type).

## Known issues / limitations
- **Build/test execution not verified in this sandbox** — same limitation as
  Phase 1 (no Android SDK / no Maven network access here). All 28 main +
  13 test Kotlin files were hand-reviewed for syntax and import correctness,
  but `./gradlew build` and `./gradlew test` for the `ai` module specifically
  have not been run. Please confirm before Phase 3 begins.
- No dependency injection wiring exists yet — nothing in `app`/`MainActivity`
  references these tools. That's intentionally out of scope until a real
  tool exists to wire in.
- `FaceRecognitionTool`'s mock enrollment state is in-memory only and resets
  on process death — expected until Phase 7/21 add real persistence.

## What the next phase needs to know
- Phase 3 (Object Detection) replaces `MockObjectDetectionTool` with a real
  on-device model. Per the roadmap, before selecting a model: check its
  license, confirm commercial-use implications, confirm Android deployment
  support, and prefer one that runs efficiently on-device (LiteRT or ONNX
  Runtime). This requires your input on model/license choice — Claude will
  not pick one unilaterally per the roadmap's Phase 3 "Who does what" split.
  You'll also need to provide or download the actual model file.
- The real implementation should live in the `vision` module (which already
  depends on `core`; it will need a dependency on `ai` added to implement
  `ObjectDetectionTool`).
- `MODEL_REGISTRY.md` needs to be created in Phase 3 per the roadmap — it
  doesn't exist yet.

## Git checkpoint
Tag: phase-2-complete
Commit message: `Phase 2: AI tool architecture (11 interfaces + mocks + tests)`
Commit hash: <create when you commit this to your actual repository>

## Verification status
See VERIFICATION.md — Phase 2: PASSED WITH NOTES (source complete and
internally consistent; actual Gradle build/test run still needs your
confirmation, same as Phase 1's original caveat).
