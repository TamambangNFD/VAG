package com.visionaid.vision

import org.junit.Assert.assertEquals
import org.junit.Test

class VisionModulePlaceholderTest {
    @Test
    fun `module name is correct`() {
        assertEquals("vision", VisionModulePlaceholder.MODULE_NAME)
    }
}
