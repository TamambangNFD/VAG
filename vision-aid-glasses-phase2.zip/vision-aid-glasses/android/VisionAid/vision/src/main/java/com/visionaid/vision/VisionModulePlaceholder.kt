package com.visionaid.vision

/**
 * Placeholder establishing the "vision" module boundary in Phase 1.
 *
 * Purpose: Camera capture, frame preprocessing, and computer-vision pipelines (Phases 3-6, 9). Depends on core.
 *
 * INTENTIONALLY EMPTY OF LOGIC. This module exists so that:
 *  1. Its Gradle dependency boundary is fixed early (other modules depend on
 *     this modules public API surface, not its internals).
 *  2. Later phases add real classes here without needing to restructure the
 *     project or touch unrelated modules.
 *
 * Do not add AI models, camera code, or business logic here during Phase 1 --
 * that is explicitly out of scope per the Phase 1 spec in
 * Vision_Aid_Glasses_Master_Roadmap.md.
 */
object VisionModulePlaceholder {
    const val MODULE_NAME = "vision"
}
