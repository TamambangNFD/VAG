package com.visionaid.navigation

import org.junit.Assert.assertEquals
import org.junit.Test

class NavigationModulePlaceholderTest {
    @Test
    fun `module name is correct`() {
        assertEquals("navigation", NavigationModulePlaceholder.MODULE_NAME)
    }
}
