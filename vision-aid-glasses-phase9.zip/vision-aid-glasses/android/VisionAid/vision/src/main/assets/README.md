Place the SSD MobileNetV2 FPN-Lite 320x320 TFLite model file here as:

    ssd_mobilenet_v2_fpnlite_320.tflite

See /MODEL_REGISTRY.md at the repo root for provenance, license, and
download instructions. This file is intentionally not committed to the
repository (multi-megabyte binary asset) — the product owner supplies it
per the roadmap's Phase 3 division of responsibility.
