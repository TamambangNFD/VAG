package com.visionaid.vision.document

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import com.visionaid.core.logging.VisionAidLogger

/**
 * Warps a detected document quadrilateral into a flat, rectangular crop
 * using Android's built-in `Matrix.setPolyToPoly` (a real 4-point
 * perspective-style mapping available natively in the Android SDK — no
 * OpenCV or other native CV library required for this specific operation).
 *
 * When [DocumentCorners] is [DocumentCorners.fullFrame] (the current
 * [SimpleDocumentDetector] default), this degrades to a no-op resize,
 * which is the correct, honest behavior given that detector's limitation.
 */
object PerspectiveCorrector {

    fun correct(bitmap: Bitmap, corners: DocumentCorners, outputWidth: Int, outputHeight: Int): Bitmap {
        val src = floatArrayOf(
            corners.topLeftX * bitmap.width, corners.topLeftY * bitmap.height,
            corners.topRightX * bitmap.width, corners.topRightY * bitmap.height,
            corners.bottomRightX * bitmap.width, corners.bottomRightY * bitmap.height,
            corners.bottomLeftX * bitmap.width, corners.bottomLeftY * bitmap.height
        )
        val dst = floatArrayOf(
            0f, 0f,
            outputWidth.toFloat(), 0f,
            outputWidth.toFloat(), outputHeight.toFloat(),
            0f, outputHeight.toFloat()
        )

        val matrix = Matrix()
        val success = matrix.setPolyToPoly(src, 0, dst, 0, 4)
        if (!success) {
            VisionAidLogger.w(TAG, "Perspective matrix computation failed — falling back to simple scale")
            return Bitmap.createScaledBitmap(bitmap, outputWidth, outputHeight, true)
        }

        val output = Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        canvas.drawBitmap(bitmap, matrix, null)
        return output
    }

    private const val TAG = "PerspectiveCorrector"
}
