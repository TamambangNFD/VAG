package com.visionaid.vision.detection

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.visionaid.core.logging.VisionAidLogger

/**
 * Converts the opaque [com.visionaid.ai.common.FrameContext.imageData] byte
 * array (JPEG-encoded, per [com.visionaid.vision.camera.CameraFrameSource])
 * into an Android [Bitmap] ready for the TFLite `ImageProcessor` pipeline.
 *
 * Kept as a small, isolated object (rather than inlined in the detection
 * tool) so it can be swapped later if a future phase changes the frame
 * encoding (e.g. to raw YUV for lower latency) without touching detection
 * logic.
 */
object FramePreprocessor {

    private const val TAG = "FramePreprocessor"

    fun decodeToBitmap(imageData: ByteArray): Bitmap? {
        if (imageData.isEmpty()) {
            VisionAidLogger.w(TAG, "Received empty image data — cannot decode frame.")
            return null
        }
        return try {
            BitmapFactory.decodeByteArray(imageData, 0, imageData.size)
        } catch (e: Exception) {
            VisionAidLogger.e(TAG, "Failed to decode frame as bitmap", e)
            null
        }
    }
}
