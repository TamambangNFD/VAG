package com.visionaid.vision.depth

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.depth.DepthOutput
import com.visionaid.ai.depth.DepthTool
import com.visionaid.ai.depth.DistanceBand
import com.visionaid.ai.detection.DetectedObject
import com.visionaid.core.logging.VisionAidLogger

/**
 * SAFETY-CRITICAL (roadmap Section 0.4). Real implementation of Phase 2's
 * [DepthTool], routed through the [CameraHardwareProfile] abstraction so no
 * assumption is made about which glasses hardware will eventually be
 * selected (Phase 19).
 *
 * Current behavior (Phase 5, hardware still TBD):
 * - [com.visionaid.vision.depth.DepthCapability.STEREO_CALIBRATED]: stereo
 *   block-matching is NOT implemented in this phase (no real stereo
 *   hardware/calibration data exists to build or test it against yet) —
 *   this path deliberately falls back to UNKNOWN for every object rather
 *   than fabricating a stereo pipeline that has never been validated. This
 *   is intentional, logged loudly, and must be revisited once glasses
 *   hardware exposing genuine synchronized stereo cameras is confirmed.
 * - [com.visionaid.vision.depth.DepthCapability.MONOCULAR_ONLY] or
 *   [com.visionaid.vision.depth.DepthCapability.UNKNOWN]: routes through
 *   [MonocularSizeBasedDepthEstimator]. Confidence is capped at LOW even
 *   when a band is confidently assigned — this heuristic has not been
 *   field-validated (that's Phase 29/31's job), so it must never report
 *   MEDIUM or HIGH confidence regardless of how "clean" a given estimate
 *   looks.
 *
 * This class must never be replaced by a general-purpose LLM/VLM, per
 * Section 0.4 — it is a fully deterministic, explainable pipeline.
 */
class RealDepthTool(
    private val hardwareProfile: CameraHardwareProfile
) : DepthTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun estimateDistance(
        frame: FrameContext,
        detectedObjects: List<DetectedObject>
    ): ToolResult<DepthOutput> {
        val (distances, confidenceLevel, method) = when (hardwareProfile.depthCapability) {
            DepthCapability.STEREO_CALIBRATED -> {
                VisionAidLogger.w(
                    TAG,
                    "Stereo depth capability declared on this device, but stereo estimation is " +
                        "not implemented in Phase 5 (no real stereo hardware/calibration data exists " +
                        "to build or validate it against yet). Falling back to UNKNOWN for all objects " +
                        "rather than fabricating an unvalidated stereo pipeline."
                )
                Triple(
                    detectedObjects.associate { it.objectId to DistanceBand.UNKNOWN },
                    ConfidenceLevel.UNKNOWN,
                    "stereo_not_yet_implemented"
                )
            }
            else -> {
                val estimates = MonocularSizeBasedDepthEstimator.estimate(detectedObjects, hardwareProfile.calibration)
                val bands = estimates.mapValues { it.value.band }
                val anyKnown = estimates.values.any { it.band != DistanceBand.UNKNOWN }
                // Deliberately capped at LOW, never MEDIUM/HIGH: this heuristic
                // is unvalidated against real-world measurements. See class KDoc.
                val confidence = if (anyKnown) ConfidenceLevel.LOW else ConfidenceLevel.UNKNOWN
                Triple(bands, confidence, "monocular_size_heuristic")
            }
        }

        return ToolResult.Success(
            data = DepthOutput(distances = distances),
            confidence = Confidence.of(confidenceLevel),
            timestampMillis = frame.captureTimestampMillis,
            metadata = mapOf("estimationMethod" to method)
        )
    }

    companion object {
        private const val TAG = "RealDepthTool"
    }
}
