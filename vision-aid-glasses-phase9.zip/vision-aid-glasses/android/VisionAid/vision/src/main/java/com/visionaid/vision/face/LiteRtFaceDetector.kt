package com.visionaid.vision.face

import android.content.Context
import com.visionaid.core.logging.VisionAidLogger
import com.visionaid.vision.detection.FramePreprocessor
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import org.tensorflow.lite.task.vision.detector.ObjectDetector

/**
 * Real face DETECTION (bounding boxes only — no identity). Uses a
 * metadata-packaged single-class face-detector TFLite model (e.g. a
 * BlazeFace short-range export) via the same TFLite Task Library
 * `ObjectDetector` API used for Phase 3's object detector — see
 * MODEL_REGISTRY.md for the specific model/license this expects.
 *
 * This class is intentionally separate from face RECOGNITION/identification
 * ([FaceEmbeddingModel], which has NO real implementation yet — see that
 * interface's KDoc and MODEL_REGISTRY.md for why). Detecting "a face exists
 * here" carries much lower privacy/provenance risk than generating an
 * identity embedding, and a properly licensed detector model is reasonably
 * available (Apache 2.0 MediaPipe-family exports) even though a properly
 * licensed and consent-clean embedding model is not, at the time of
 * writing.
 */
class LiteRtFaceDetector(private val context: Context) {

    private var detector: ObjectDetector? = null
    private var loadAttempted = false

    fun isAvailable(): Boolean {
        ensureLoaded()
        return detector != null
    }

    private fun ensureLoaded() {
        if (loadAttempted) return
        loadAttempted = true
        try {
            val options = ObjectDetector.ObjectDetectorOptions.builder()
                .setMaxResults(MAX_FACES)
                .setScoreThreshold(MIN_DETECTION_CONFIDENCE)
                .build()
            detector = ObjectDetector.createFromFileAndOptions(context, MODEL_ASSET_PATH, options)
            VisionAidLogger.i(TAG, "Face detector model loaded from $MODEL_ASSET_PATH")
        } catch (e: Exception) {
            VisionAidLogger.e(TAG, "Failed to load face detector model from $MODEL_ASSET_PATH", e)
        }
    }

    fun detectFaces(imageData: ByteArray): List<FaceDetectionResult> {
        ensureLoaded()
        val activeDetector = detector ?: return emptyList()
        val bitmap = FramePreprocessor.decodeToBitmap(imageData) ?: return emptyList()

        return try {
            val tensorImage = ImageProcessor.Builder()
                .add(ResizeOp(MODEL_INPUT_SIZE, MODEL_INPUT_SIZE, ResizeOp.ResizeMethod.BILINEAR))
                .build()
                .process(TensorImage.fromBitmap(bitmap))

            activeDetector.detect(tensorImage).mapNotNull { detection ->
                val category = detection.categories.firstOrNull() ?: return@mapNotNull null
                val box = detection.boundingBox
                FaceDetectionResult(
                    boundingBox = com.visionaid.ai.detection.BoundingBox(
                        left = (box.left / bitmap.width).coerceIn(0f, 1f),
                        top = (box.top / bitmap.height).coerceIn(0f, 1f),
                        right = (box.right / bitmap.width).coerceIn(0f, 1f),
                        bottom = (box.bottom / bitmap.height).coerceIn(0f, 1f)
                    ),
                    confidenceScore = category.score
                )
            }
        } catch (e: Exception) {
            VisionAidLogger.e(TAG, "Face detection inference failed", e)
            emptyList()
        }
    }

    companion object {
        private const val TAG = "LiteRtFaceDetector"
        const val MODEL_ASSET_PATH = "face_detector_short_range.tflite"
        const val MODEL_INPUT_SIZE = 128
        const val MAX_FACES = 10
        const val MIN_DETECTION_CONFIDENCE = 0.5f
    }
}
