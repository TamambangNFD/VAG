package com.visionaid.vision.magnification

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import com.visionaid.ai.detection.BoundingBox
import kotlin.math.max
import kotlin.math.min

/**
 * Real Android image manipulation for magnification: crop -> scale up ->
 * brightness/contrast adjustment -> optional text-focused high-contrast
 * grayscale. Pure pixel operations, no ML model involved.
 *
 * IMPORTANT: this enlarges and enhances existing pixel data. It cannot
 * recover detail the camera sensor did not capture — see
 * `ai.magnification.MagnificationTool`'s KDoc. Do not present this as
 * "sharpening" or detail recovery in any user-facing text.
 */
object MagnificationImageProcessor {

    fun process(
        source: Bitmap,
        cropRect: BoundingBox,
        outputWidth: Int,
        outputHeight: Int,
        brightnessDelta: Float,
        contrastDelta: Float,
        textFocusedMode: Boolean
    ): Bitmap {
        val pixelRect = Rect(
            (cropRect.left * source.width).toInt(),
            (cropRect.top * source.height).toInt(),
            (cropRect.right * source.width).toInt().coerceAtMost(source.width),
            (cropRect.bottom * source.height).toInt().coerceAtMost(source.height)
        )
        val cropWidth = (pixelRect.right - pixelRect.left).coerceAtLeast(1)
        val cropHeight = (pixelRect.bottom - pixelRect.top).coerceAtLeast(1)

        val cropped = Bitmap.createBitmap(source, pixelRect.left, pixelRect.top, cropWidth, cropHeight)
        val scaled = Bitmap.createScaledBitmap(cropped, outputWidth, outputHeight, true)

        return applyBrightnessContrast(scaled, brightnessDelta, contrastDelta, textFocusedMode)
    }

    private fun applyBrightnessContrast(
        bitmap: Bitmap,
        brightnessDelta: Float,
        contrastDelta: Float,
        textFocusedMode: Boolean
    ): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        // brightnessDelta in [-1,1] -> pixel offset in [-255,255].
        val brightnessOffset = (brightnessDelta * 255).toInt()
        // contrastDelta in [-1,1] -> contrast factor in [0.2, 2.0] roughly.
        val contrastFactor = 1f + contrastDelta

        for (i in pixels.indices) {
            val p = pixels[i]
            var r = Color.red(p)
            var g = Color.green(p)
            var b = Color.blue(p)

            if (textFocusedMode) {
                // High-contrast grayscale — favors legibility of text over
                // color fidelity, per the roadmap's "text-focused mode".
                val gray = (r * 0.299 + g * 0.587 + b * 0.114).toInt()
                r = gray; g = gray; b = gray
            }

            r = adjust(r, brightnessOffset, contrastFactor)
            g = adjust(g, brightnessOffset, contrastFactor)
            b = adjust(b, brightnessOffset, contrastFactor)

            pixels[i] = Color.rgb(r, g, b)
        }

        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        output.setPixels(pixels, 0, width, 0, 0, width, height)
        return output
    }

    private fun adjust(channel: Int, brightnessOffset: Int, contrastFactor: Float): Int {
        val contrasted = ((channel - 128) * contrastFactor + 128).toInt()
        return (contrasted + brightnessOffset).coerceIn(0, 255)
    }
}
