package com.visionaid.vision.ocr

/** One OCR-recognized line of text, before reading-order sorting or paragraph grouping. */
data class RawTextLine(
    val text: String,
    val confidenceScore: Float,
    /** Normalized (0.0-1.0) position, in frame coordinates. */
    val top: Float,
    val left: Float,
    val bottom: Float
)
