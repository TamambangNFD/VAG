package com.visionaid.vision.depth

import com.visionaid.ai.detection.ObjectLabel

/**
 * Calibration data required for monocular size-based distance estimation.
 * MUST be produced by an actual calibration procedure against the real
 * target camera once hardware is selected (Phase 19) — the default
 * reference heights below are rough population averages, not measurements,
 * and must not be trusted for precise output (see
 * [MonocularSizeBasedDepthEstimator] KDoc for why confidence is capped
 * accordingly).
 *
 * @param normalizedFocalLength the camera's focal length expressed in
 *   "image-height units" (focal length in pixels / image height in pixels),
 *   so the estimator works on normalized bounding boxes without needing the
 *   frame's absolute pixel resolution at estimation time. Obtained via a
 *   standard camera calibration procedure (e.g. checkerboard calibration)
 *   on the actual target device — NOT a value to guess or hard-code from a
 *   spec sheet.
 * @param referenceHeightsMeters rough average real-world heights per object
 *   class, used as the "known size" in the pinhole-camera distance formula.
 *   Population variance (e.g. a child vs. an adult for PERSON) is a known,
 *   inherent source of error in this technique — see KDoc below.
 */
data class CalibrationConfig(
    val normalizedFocalLength: Float,
    val referenceHeightsMeters: Map<ObjectLabel, Float> = DEFAULT_REFERENCE_HEIGHTS,
    /** Bounding boxes shorter than this fraction of frame height are too small/distant to trust. */
    val minReliableBoxHeight: Float = 0.02f,
    /** Bounding boxes taller than this fraction of frame height are likely clipped/too close to trust. */
    val maxReliableBoxHeight: Float = 0.95f
) {
    companion object {
        /**
         * Rough population-average heights in meters. NOT calibrated
         * measurements — placeholders until real-world validation (roadmap
         * Phase 29/31). Classes with no reasonable single "typical height"
         * (e.g. BAG, BOTTLE vary too widely) are deliberately omitted, so
         * they fall back to UNKNOWN rather than using a meaningless average.
         */
        val DEFAULT_REFERENCE_HEIGHTS: Map<ObjectLabel, Float> = mapOf(
            ObjectLabel.PERSON to 1.7f,
            ObjectLabel.BICYCLE to 1.1f,
            ObjectLabel.MOTORCYCLE to 1.3f,
            ObjectLabel.CHAIR to 0.9f,
            ObjectLabel.TABLE to 0.75f
            // CAR/VEHICLE omitted: height varies too widely (sedan vs SUV vs
            // truck) for a single reference value to be meaningful; BAG/
            // BOTTLE/OTHER omitted for the same reason. All fall back to
            // UNKNOWN via MonocularSizeBasedDepthEstimator.
        )
    }
}
