package com.visionaid.vision.face

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolError
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.face.EnrollmentOutput
import com.visionaid.ai.face.FaceRecognitionTool
import com.visionaid.ai.face.RecognitionOutput
import com.visionaid.ai.face.RecognizedFace
import com.visionaid.core.logging.VisionAidLogger

/**
 * Real implementation of Phase 2's [FaceRecognitionTool], orchestrating
 * [LiteRtFaceDetector] (real, working), [FaceEmbeddingModel] (deliberately
 * unimplemented — see that interface's KDoc), [EmbeddingSimilarity], and
 * [EncryptedFaceProfileStore].
 *
 * Because no embedding model is currently wired in
 * ([NoFaceEmbeddingModelAvailable] is the default), [availability] reports
 * [ToolAvailability.UNAVAILABLE_MODEL_NOT_LOADED] and both [recognize] and
 * [enroll] fail with [ToolError.ModelNotLoaded] rather than fabricating a
 * result. Face detection alone still works and could be surfaced separately
 * by a future phase (e.g. "a face is visible" without identity) if useful,
 * but that is not part of this interface's contract.
 */
class RealFaceRecognitionTool(
    private val faceDetector: LiteRtFaceDetector,
    private val embeddingModel: FaceEmbeddingModel,
    private val profileStore: EncryptedFaceProfileStore
) : FaceRecognitionTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    private var enabled = true

    override fun availability(): ToolAvailability {
        if (!enabled) return ToolAvailability.DISABLED_BY_USER
        if (!embeddingModel.isAvailable()) return ToolAvailability.UNAVAILABLE_MODEL_NOT_LOADED
        return ToolAvailability.AVAILABLE
    }

    override suspend fun recognize(frame: FrameContext): ToolResult<RecognitionOutput> {
        if (!enabled) {
            return ToolResult.Failure(ToolError.InvalidInput("Face recognition is disabled by user"), frame.captureTimestampMillis)
        }
        if (!embeddingModel.isAvailable()) {
            return ToolResult.Failure(ToolError.ModelNotLoaded, frame.captureTimestampMillis)
        }

        val detectedFaces = faceDetector.detectFaces(frame.imageData)
        val storedProfiles = profileStore.getAllProfiles().mapValues { it.value.embedding }

        val recognizedFaces = detectedFaces.map { face ->
            val embedding = embeddingModel.generateEmbedding(frame.imageData, face.boundingBox)
            val match = embedding?.let { EmbeddingSimilarity.findBestMatch(it, storedProfiles) }
            RecognizedFace(
                personId = match?.personId,
                personName = match?.personId?.let { profileStore.getAllProfiles()[it]?.name },
                boundingBoxLeft = face.boundingBox.left,
                boundingBoxTop = face.boundingBox.top,
                boundingBoxRight = face.boundingBox.right,
                boundingBoxBottom = face.boundingBox.bottom
            )
        }

        val overallConfidence = if (recognizedFaces.any { it.personId != null }) {
            ConfidenceLevel.MEDIUM
        } else {
            ConfidenceLevel.LOW
        }

        return ToolResult.Success(
            data = RecognitionOutput(faces = recognizedFaces),
            confidence = Confidence.of(overallConfidence),
            timestampMillis = frame.captureTimestampMillis
        )
    }

    override suspend fun enroll(
        frame: FrameContext,
        personName: String,
        consentConfirmed: Boolean
    ): ToolResult<EnrollmentOutput> {
        if (!consentConfirmed) {
            return ToolResult.Failure(
                ToolError.InvalidInput("Cannot enroll a face without explicit user consent"),
                frame.captureTimestampMillis
            )
        }
        if (!embeddingModel.isAvailable()) {
            VisionAidLogger.w(TAG, "Enrollment attempted with no embedding model available")
            return ToolResult.Failure(ToolError.ModelNotLoaded, frame.captureTimestampMillis)
        }

        val detectedFaces = faceDetector.detectFaces(frame.imageData)
        val primaryFace = detectedFaces.firstOrNull()
            ?: return ToolResult.Failure(ToolError.InvalidInput("No face detected in frame"), frame.captureTimestampMillis)

        val embedding = embeddingModel.generateEmbedding(frame.imageData, primaryFace.boundingBox)
            ?: return ToolResult.Failure(ToolError.InternalError("Failed to generate face embedding"), frame.captureTimestampMillis)

        val personId = profileStore.saveProfile(personName, embedding)
        return ToolResult.Success(
            data = EnrollmentOutput(personId = personId, personName = personName),
            confidence = Confidence.of(ConfidenceLevel.HIGH),
            timestampMillis = frame.captureTimestampMillis
        )
    }

    override suspend fun rename(personId: String, newName: String): ToolResult<Unit> {
        val renamed = profileStore.renameProfile(personId, newName)
        return if (renamed) {
            ToolResult.Success(Unit, Confidence.of(ConfidenceLevel.HIGH), System.currentTimeMillis())
        } else {
            ToolResult.Failure(ToolError.InvalidInput("Unknown personId: $personId"), System.currentTimeMillis())
        }
    }

    override suspend fun remove(personId: String): ToolResult<Unit> {
        profileStore.removeProfile(personId)
        return ToolResult.Success(Unit, Confidence.of(ConfidenceLevel.HIGH), System.currentTimeMillis())
    }

    override fun setEnabled(enabled: Boolean) {
        this.enabled = enabled
    }

    companion object {
        private const val TAG = "RealFaceRecognitionTool"
    }
}
