package com.visionaid.vision.document

/** Four normalized (0.0-1.0) corner points of a detected document, in order: top-left, top-right, bottom-right, bottom-left. */
data class DocumentCorners(
    val topLeftX: Float, val topLeftY: Float,
    val topRightX: Float, val topRightY: Float,
    val bottomRightX: Float, val bottomRightY: Float,
    val bottomLeftX: Float, val bottomLeftY: Float
) {
    companion object {
        /** The whole frame, used as a fallback when no document edges could be confidently found. */
        fun fullFrame() = DocumentCorners(0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f)
    }
}
