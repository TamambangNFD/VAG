package com.visionaid.vision.detection

import com.visionaid.ai.detection.ObjectLabel

/**
 * Maps the SSD MobileNetV2 FPN-Lite model's COCO output indices to the
 * roadmap's [ObjectLabel] enum (see MODEL_REGISTRY.md for the model itself).
 *
 * IMPORTANT — read before touching this file: COCO's 90 categories do not
 * include several classes the roadmap's Phase 0 list asks for: STAIRS,
 * POLE, ROAD, SIDEWALK, and WALL have no corresponding COCO class and are
 * therefore NEVER produced by this model. Do not add fabricated mappings
 * for them here — an incorrect mapping (e.g. treating "bench" detections as
 * "stairs") would silently violate the roadmap's "never invent hardware/
 * model capabilities" rule and could actively mislead a blind user. This
 * gap is tracked in MODEL_REGISTRY.md and HARDWARE_GAP_ANALYSIS.md (Phase 27)
 * as a known limitation requiring either a custom-trained/fine-tuned model
 * or a different technique (e.g. semantic segmentation for road/sidewalk,
 * a dedicated stair-detection model) in a later phase.
 *
 * Any COCO class not explicitly listed below maps to [ObjectLabel.OTHER]
 * rather than being silently dropped, so the detection is still surfaced
 * (with a generic label) instead of disappearing.
 */
object CocoLabelMap {

    // Standard 90-class COCO label list, index-aligned to the model's output,
    // as published with the SSD MobileNetV2 FPN-Lite TFLite model metadata.
    private val cocoIndexToName = mapOf(
        0 to "person", 1 to "bicycle", 2 to "car", 3 to "motorcycle",
        5 to "bus", 6 to "train", 7 to "truck",
        24 to "backpack", 26 to "handbag",
        39 to "bottle",
        56 to "chair", 60 to "dining table"
        // Remaining COCO indices exist in the full model but are not needed
        // for the roadmap's initial object list; they still resolve to
        // ObjectLabel.OTHER via the fallback below rather than being ignored.
    )

    private val nameToObjectLabel = mapOf(
        "person" to ObjectLabel.PERSON,
        "car" to ObjectLabel.CAR,
        "motorcycle" to ObjectLabel.MOTORCYCLE,
        "bicycle" to ObjectLabel.BICYCLE,
        "chair" to ObjectLabel.CHAIR,
        "dining table" to ObjectLabel.TABLE,
        "bottle" to ObjectLabel.BOTTLE,
        "backpack" to ObjectLabel.BAG,
        "handbag" to ObjectLabel.BAG,
        "bus" to ObjectLabel.VEHICLE,
        "train" to ObjectLabel.VEHICLE,
        "truck" to ObjectLabel.VEHICLE
        // DOOR, STAIRS, POLE, ROAD, SIDEWALK, WALL: intentionally absent.
        // See class KDoc above.
    )

    /** Returns the mapped [ObjectLabel] for a raw COCO class index, or OTHER if unmapped/unknown. */
    fun toObjectLabel(cocoIndex: Int): ObjectLabel {
        val name = cocoIndexToName[cocoIndex] ?: return ObjectLabel.OTHER
        return nameToObjectLabel[name] ?: ObjectLabel.OTHER
    }

    /** Roadmap labels this model can never produce, regardless of confidence threshold. */
    val UNSUPPORTED_ROADMAP_LABELS = setOf(
        ObjectLabel.DOOR, ObjectLabel.STAIRS, ObjectLabel.POLE,
        ObjectLabel.ROAD, ObjectLabel.SIDEWALK, ObjectLabel.WALL
    )
}
