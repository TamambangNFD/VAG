package com.visionaid.vision.tracking

import com.visionaid.ai.detection.BoundingBox

/**
 * Pure geometry used by [GreedyTrackMatcher] to associate detections across
 * frames. Kept dependency-free (no Android, no Interpreter) so it's fully
 * unit-testable.
 */
object IouCalculator {

    /** Intersection-over-union of two normalized bounding boxes, in 0.0..1.0. */
    fun iou(a: BoundingBox, b: BoundingBox): Float {
        val intersectionLeft = maxOf(a.left, b.left)
        val intersectionTop = maxOf(a.top, b.top)
        val intersectionRight = minOf(a.right, b.right)
        val intersectionBottom = minOf(a.bottom, b.bottom)

        val intersectionWidth = (intersectionRight - intersectionLeft).coerceAtLeast(0f)
        val intersectionHeight = (intersectionBottom - intersectionTop).coerceAtLeast(0f)
        val intersectionArea = intersectionWidth * intersectionHeight

        val areaA = (a.right - a.left) * (a.bottom - a.top)
        val areaB = (b.right - b.left) * (b.bottom - b.top)
        val unionArea = areaA + areaB - intersectionArea

        return if (unionArea <= 0f) 0f else intersectionArea / unionArea
    }

    fun area(box: BoundingBox): Float = (box.right - box.left) * (box.bottom - box.top)

    fun centerX(box: BoundingBox): Float = (box.left + box.right) / 2f
    fun centerY(box: BoundingBox): Float = (box.top + box.bottom) / 2f
}
