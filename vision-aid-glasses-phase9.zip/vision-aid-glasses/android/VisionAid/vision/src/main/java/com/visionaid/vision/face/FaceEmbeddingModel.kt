package com.visionaid.vision.face

import com.visionaid.ai.detection.BoundingBox

/**
 * Converts a detected face into a numeric embedding vector for identity
 * comparison. This is the actual "recognition" step — detection alone
 * (see [LiteRtFaceDetector]) only says "a face is here," not "whose."
 *
 * ============================================================
 * NO IMPLEMENTATION OF THIS INTERFACE EXISTS YET. THIS IS DELIBERATE.
 * ============================================================
 * The roadmap requires: "any pretrained model used must have documented
 * training-data provenance and a license that permits this use. Do not use
 * any model or dataset without clear licensing." The commonly available
 * pretrained face-embedding models (FaceNet, MobileFaceNet, ArcFace, and
 * most derivatives) are trained on datasets with serious, documented
 * consent problems:
 * - MS-Celeb-1M: retracted by Microsoft in 2019 specifically over
 *   biometric-privacy/consent violations — the people in it never agreed
 *   to be included.
 * - VGGFace2 / CASIA-WebFace: built by scraping images of public figures
 *   without individual consent; widely used academically but not clearly
 *   licensed for identifying real people in a commercial product.
 *
 * Shipping a model trained on any of these would put this product in the
 * exact position the roadmap explicitly prohibits: using a model without
 * clear, consent-respecting provenance and licensing for biometric
 * identification of real people. Rather than pick one anyway, this
 * interface exists so the rest of the enrollment/recognition pipeline
 * (consent capture, encrypted storage, matching logic, commands) can be
 * built and tested now, with the actual identity model deliberately left
 * unimplemented until one of the following is true:
 * 1. A model with fully documented, consent-clean training data and a
 *    license permitting this product's use becomes available, or
 * 2. A custom model is trained on a dataset collected specifically for
 *    this product with proper informed consent (see
 *    datasets/DATASET_PROVENANCE.md requirement in the roadmap), or
 * 3. A commercially licensed on-device face-recognition SDK is purchased,
 *    with its own vendor license explicitly covering this use case.
 *
 * See MODEL_REGISTRY.md for this decision recorded formally, and
 * PRIVACY.md for how the rest of the pipeline behaves in the meantime
 * (always UNAVAILABLE_MODEL_NOT_LOADED — never a fabricated identity).
 */
interface FaceEmbeddingModel {
    fun isAvailable(): Boolean
    fun generateEmbedding(imageData: ByteArray, faceBox: BoundingBox): FloatArray?
}

/**
 * The only implementation that exists right now: always unavailable. This
 * is not a bug or a forgotten TODO — it is the correct, safe behavior until
 * one of the three conditions in [FaceEmbeddingModel]'s KDoc is met.
 */
class NoFaceEmbeddingModelAvailable : FaceEmbeddingModel {
    override fun isAvailable(): Boolean = false
    override fun generateEmbedding(imageData: ByteArray, faceBox: BoundingBox): FloatArray? = null
}
