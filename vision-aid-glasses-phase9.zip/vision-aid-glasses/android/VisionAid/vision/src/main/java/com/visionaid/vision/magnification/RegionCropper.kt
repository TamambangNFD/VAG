package com.visionaid.vision.magnification

import com.visionaid.ai.detection.BoundingBox
import com.visionaid.ai.magnification.ZoomLevel

/**
 * Pure, Android-independent math: computes the normalized crop rectangle
 * for a given zoom level and optional region of interest. Kept separate
 * from any Bitmap manipulation so it's fully unit-testable.
 *
 * The crop is always clamped to stay within the frame [0,1] bounds — a
 * region of interest near an edge shifts the crop rather than overflowing,
 * so the output is always a valid, full-size crop at the requested zoom
 * factor rather than a partially out-of-frame or asymmetric one.
 */
object RegionCropper {

    fun computeCropRect(zoomLevel: ZoomLevel, regionOfInterest: BoundingBox?): BoundingBox {
        val cropSize = 1f / zoomLevel.factor

        val (centerX, centerY) = if (regionOfInterest != null) {
            (regionOfInterest.left + regionOfInterest.right) / 2f to
                (regionOfInterest.top + regionOfInterest.bottom) / 2f
        } else {
            0.5f to 0.5f
        }

        var left = centerX - cropSize / 2f
        var top = centerY - cropSize / 2f

        // Clamp so the crop stays fully within [0,1] — shift rather than truncate.
        left = left.coerceIn(0f, 1f - cropSize)
        top = top.coerceIn(0f, 1f - cropSize)

        return BoundingBox(left = left, top = top, right = left + cropSize, bottom = top + cropSize)
    }
}
