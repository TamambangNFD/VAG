package com.visionaid.vision.ocr

import android.content.Context
import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI
import com.visionaid.ai.common.LocaleTag
import com.visionaid.core.logging.VisionAidLogger
import java.io.File

/**
 * Wraps Tesseract4Android (`cz.adaptech.tesseract4android`, Apache 2.0) for
 * real, fully offline OCR. See MODEL_REGISTRY.md for the license/dependency
 * decision and where the `.traineddata` language files must be placed.
 *
 * Tesseract expects `.traineddata` files under `<filesDir>/tessdata/`, NOT
 * in the APK assets directly usable in place — they must be copied out of
 * assets to app-private storage on first run. This class handles that
 * copy, so callers just ask for a language and get an initialized engine
 * or a clear failure.
 */
class TesseractOcrEngine(private val context: Context) {

    private val tessDataDir: File by lazy { File(context.filesDir, "tessdata") }
    private var initializedLanguage: String? = null
    private var tessApi: TessBaseAPI? = null

    fun isLanguageAvailable(locale: LocaleTag): Boolean {
        val langCode = tesseractLangCode(locale)
        return File(tessDataDir, "$langCode.traineddata").exists()
    }

    /**
     * Copies bundled `.traineddata` files from assets into app-private
     * storage if not already present. Call once at startup (idempotent).
     * Returns false if the expected asset file for [locale] isn't bundled —
     * this is expected until the product owner supplies the language data
     * files, per MODEL_REGISTRY.md.
     */
    fun ensureLanguageInstalled(locale: LocaleTag): Boolean {
        val langCode = tesseractLangCode(locale)
        val destFile = File(tessDataDir, "$langCode.traineddata")
        if (destFile.exists()) return true

        return try {
            tessDataDir.mkdirs()
            context.assets.open("tessdata/$langCode.traineddata").use { input ->
                destFile.outputStream().use { output -> input.copyTo(output) }
            }
            VisionAidLogger.i(TAG, "Installed Tesseract language data for $langCode")
            true
        } catch (e: Exception) {
            VisionAidLogger.w(TAG, "Tesseract language data for $langCode not bundled in assets/tessdata/ — OCR unavailable for this language until it's supplied. See MODEL_REGISTRY.md.")
            false
        }
    }

    fun recognize(bitmap: Bitmap, locale: LocaleTag): List<RawTextLine>? {
        val langCode = tesseractLangCode(locale)
        if (!ensureLanguageInstalled(locale)) return null

        val api = getOrCreateApi(langCode) ?: return null
        return try {
            api.setImage(bitmap)
            val lines = mutableListOf<RawTextLine>()
            val iterator = api.resultIterator
            iterator?.let {
                do {
                    val text = it.getUTF8Text(TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE) ?: continue
                    if (text.isBlank()) continue
                    val confidence = it.confidence(TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE) / 100f
                    val rect = it.getBoundingRect(TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE)
                    lines.add(
                        RawTextLine(
                            text = text.trim(),
                            confidenceScore = confidence,
                            top = rect.top.toFloat() / bitmap.height,
                            left = rect.left.toFloat() / bitmap.width,
                            bottom = rect.bottom.toFloat() / bitmap.height
                        )
                    )
                } while (it.next(TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE))
            }
            api.clear()
            lines
        } catch (e: Exception) {
            VisionAidLogger.e(TAG, "Tesseract recognition failed", e)
            null
        }
    }

    private fun getOrCreateApi(langCode: String): TessBaseAPI? {
        if (initializedLanguage == langCode && tessApi != null) return tessApi

        tessApi?.recycle()
        val api = TessBaseAPI()
        val initialized = api.init(context.filesDir.absolutePath, langCode)
        if (!initialized) {
            VisionAidLogger.e(TAG, "Failed to initialize Tesseract for language $langCode")
            return null
        }
        tessApi = api
        initializedLanguage = langCode
        return api
    }

    private fun tesseractLangCode(locale: LocaleTag): String = when (locale) {
        LocaleTag.ENGLISH -> "eng"
        LocaleTag.FRENCH -> "fra"
    }

    fun close() {
        tessApi?.recycle()
        tessApi = null
        initializedLanguage = null
    }

    companion object {
        private const val TAG = "TesseractOcrEngine"
    }
}
