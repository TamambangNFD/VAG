package com.visionaid.vision.face

import com.visionaid.ai.detection.BoundingBox

/** A single detected face location, with no identity information attached. */
data class FaceDetectionResult(
    val boundingBox: BoundingBox,
    val confidenceScore: Float
)
