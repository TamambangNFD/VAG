package com.visionaid.vision.magnification

/**
 * Hardware capability abstraction for magnified-image output, mirroring
 * the pattern established in Phase 5 (`CameraHardwareProfile`). Glasses
 * hardware is still TBD (`PRODUCT_SPEC.md` Section 9), so this defaults to
 * [DisplayCapability.UNKNOWN], and [com.visionaid.vision.magnification.RealMagnificationTool]
 * treats anything other than a confirmed, implemented glasses display path
 * as phone-test-mode — see that class's KDoc.
 */
data class DisplayHardwareProfile(
    val displayCapability: DisplayCapability = DisplayCapability.UNKNOWN
)

enum class DisplayCapability {
    /** Glasses expose a display API AND this app has real code to render to it. Not true yet — see RealMagnificationTool. */
    GLASSES_DISPLAY_IMPLEMENTED,
    /** No glasses display, or one exists but isn't wired up yet. */
    PHONE_TEST_MODE_ONLY,
    UNKNOWN
}
