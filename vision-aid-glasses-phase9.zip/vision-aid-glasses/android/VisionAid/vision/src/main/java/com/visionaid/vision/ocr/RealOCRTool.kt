package com.visionaid.vision.ocr

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolError
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.ocr.OCRTool
import com.visionaid.ai.ocr.OcrOutput
import com.visionaid.ai.ocr.TextBlock
import com.visionaid.vision.detection.FramePreprocessor

/**
 * Real implementation of Phase 2's [OCRTool] using [TesseractOcrEngine].
 * Locale is read from [FrameContext.locale] and passed straight through to
 * Tesseract — never hard-coded, per Section 0.5.
 */
class RealOCRTool(private val engine: TesseractOcrEngine) : OCRTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    override fun availability(): ToolAvailability =
        ToolAvailability.AVAILABLE // language availability is checked per-request; see recognizeText

    override suspend fun recognizeText(frame: FrameContext): ToolResult<OcrOutput> {
        if (!engine.isLanguageAvailable(frame.locale) && !engine.ensureLanguageInstalled(frame.locale)) {
            return ToolResult.Failure(ToolError.ModelNotLoaded, frame.captureTimestampMillis)
        }

        val bitmap = FramePreprocessor.decodeToBitmap(frame.imageData)
            ?: return ToolResult.Failure(ToolError.InvalidInput("Could not decode frame as an image"), frame.captureTimestampMillis)

        val rawLines = engine.recognize(bitmap, frame.locale)
            ?: return ToolResult.Failure(ToolError.InternalError("Tesseract recognition failed"), frame.captureTimestampMillis)

        val orderedLines = TextOrderer.order(rawLines)
        val textBlocks = orderedLines.mapIndexed { index, line ->
            TextBlock(text = line.text, confidenceScore = line.confidenceScore, readingOrderIndex = index)
        }

        val overallConfidence = if (textBlocks.isEmpty()) {
            ConfidenceLevel.UNKNOWN
        } else {
            val avg = textBlocks.map { it.confidenceScore }.average().toFloat()
            when {
                avg >= 0.8f -> ConfidenceLevel.HIGH
                avg >= 0.5f -> ConfidenceLevel.MEDIUM
                else -> ConfidenceLevel.LOW
            }
        }

        return ToolResult.Success(
            data = OcrOutput(textBlocks = textBlocks),
            confidence = Confidence.of(overallConfidence),
            timestampMillis = frame.captureTimestampMillis
        )
    }
}
