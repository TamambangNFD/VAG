package com.visionaid.vision.face

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.visionaid.core.logging.VisionAidLogger
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Local, encrypted-at-rest storage for enrolled face profiles, per the
 * roadmap's explicit Phase 7 requirement ("local encrypted face-profile
 * storage") and Section 0.3-adjacent privacy principles. Uses Jetpack
 * Security's `EncryptedSharedPreferences` (AES-256-GCM, Android Keystore-
 * backed master key) — no custom crypto, no plaintext fallback.
 *
 * Stores, per person: a generated [personId], the display name, and the
 * face embedding (as JSON, since no external serialization library is
 * needed for a flat float array — `org.json` ships with Android). Never
 * stores the original face image, only the derived embedding.
 *
 * Nothing here ever leaves the device — no network code exists in this
 * class or anywhere it's called from.
 */
class EncryptedFaceProfileStore(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        PREFS_FILE_NAME,
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveProfile(personName: String, embedding: FloatArray): String {
        val personId = UUID.randomUUID().toString()
        writeProfile(personId, personName, embedding)
        VisionAidLogger.i(TAG, "Saved new face profile (id redacted from log)")
        return personId
    }

    fun renameProfile(personId: String, newName: String): Boolean {
        val existing = readProfile(personId) ?: return false
        writeProfile(personId, newName, existing.embedding)
        return true
    }

    fun removeProfile(personId: String): Boolean {
        if (!prefs.contains(personId)) return false
        prefs.edit().remove(personId).apply()
        VisionAidLogger.i(TAG, "Removed face profile (id redacted from log)")
        return true
    }

    fun getAllProfiles(): Map<String, StoredProfile> =
        prefs.all.keys.mapNotNull { personId -> readProfile(personId)?.let { personId to it } }.toMap()

    fun clearAll() {
        prefs.edit().clear().apply()
    }

    private fun writeProfile(personId: String, personName: String, embedding: FloatArray) {
        val json = JSONObject().apply {
            put("name", personName)
            put("embedding", JSONArray(embedding.map { it.toDouble() }))
        }
        prefs.edit().putString(personId, json.toString()).apply()
    }

    private fun readProfile(personId: String): StoredProfile? {
        val raw = prefs.getString(personId, null) ?: return null
        return try {
            val json = JSONObject(raw)
            val name = json.getString("name")
            val embeddingJson = json.getJSONArray("embedding")
            val embedding = FloatArray(embeddingJson.length()) { embeddingJson.getDouble(it).toFloat() }
            StoredProfile(name, embedding)
        } catch (e: Exception) {
            VisionAidLogger.e(TAG, "Failed to parse stored face profile", e)
            null
        }
    }

    data class StoredProfile(val name: String, val embedding: FloatArray)

    companion object {
        private const val TAG = "EncryptedFaceProfileStore"
        private const val PREFS_FILE_NAME = "visionaid_face_profiles_encrypted"
    }
}
