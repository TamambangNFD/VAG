package com.visionaid.vision.detection

import android.content.Context
import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolError
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.detection.DetectedObject
import com.visionaid.ai.detection.DetectionOutput
import com.visionaid.ai.detection.ObjectDetectionTool
import com.visionaid.core.logging.VisionAidLogger
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import org.tensorflow.lite.task.vision.detector.ObjectDetector

/**
 * Real, on-device implementation of [ObjectDetectionTool] using LiteRT
 * (TensorFlow Lite) with the SSD MobileNetV2 FPN-Lite 320x320 model.
 * See MODEL_REGISTRY.md for model provenance, license, and known class
 * coverage gaps (this model can never report STAIRS/POLE/ROAD/SIDEWALK/WALL
 * — see [com.visionaid.vision.detection.CocoLabelMap]).
 *
 * Per the roadmap, the actual `.tflite` model binary is NOT included in
 * this repository — the product owner downloads/provides it (see
 * MODEL_REGISTRY.md "How to obtain the model file") and places it at
 * [MODEL_ASSET_PATH] in the app's assets before this tool can load
 * successfully. If the file is missing, [availability] correctly reports
 * UNAVAILABLE_MODEL_NOT_LOADED rather than crashing — this is deliberate,
 * not a bug: Phase 3 must not claim the model is present when it isn't.
 */
class LiteRtObjectDetectionTool(private val context: Context) : ObjectDetectionTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    private var detector: ObjectDetector? = null
    private var loadAttempted = false
    private var loadError: String? = null

    override fun availability(): ToolAvailability {
        ensureModelLoaded()
        return when {
            detector != null -> ToolAvailability.AVAILABLE
            else -> ToolAvailability.UNAVAILABLE_MODEL_NOT_LOADED
        }
    }

    private fun ensureModelLoaded() {
        if (loadAttempted) return
        loadAttempted = true
        try {
            val options = ObjectDetector.ObjectDetectorOptions.builder()
                .setMaxResults(BoxDecoder.MAX_RESULTS)
                .setScoreThreshold(BoxDecoder.DEFAULT_MIN_CONFIDENCE)
                .build()
            detector = ObjectDetector.createFromFileAndOptions(context, MODEL_ASSET_PATH, options)
            VisionAidLogger.i(TAG, "Object detection model loaded successfully from $MODEL_ASSET_PATH")
        } catch (e: Exception) {
            // Deliberately broad catch: any failure to load (file missing,
            // corrupt model, unsupported op) must degrade to
            // UNAVAILABLE_MODEL_NOT_LOADED, never crash the app or silently
            // fall back to fabricated detections.
            loadError = e.message
            VisionAidLogger.e(TAG, "Failed to load object detection model from $MODEL_ASSET_PATH", e)
        }
    }

    override suspend fun detect(frame: FrameContext): ToolResult<DetectionOutput> {
        ensureModelLoaded()
        val activeDetector = detector
            ?: return ToolResult.Failure(
                ToolError.ModelNotLoaded,
                timestampMillis = frame.captureTimestampMillis
            )

        return try {
            val startTime = System.nanoTime()
            val bitmap = FramePreprocessor.decodeToBitmap(frame.imageData)
                ?: return ToolResult.Failure(
                    ToolError.InvalidInput("Could not decode frame $frame.frameId as an image"),
                    frame.captureTimestampMillis
                )

            val tensorImage = ImageProcessor.Builder()
                .add(ResizeOp(MODEL_INPUT_SIZE, MODEL_INPUT_SIZE, ResizeOp.ResizeMethod.BILINEAR))
                .build()
                .process(TensorImage.fromBitmap(bitmap))

            val rawResults = activeDetector.detect(tensorImage)
            val latencyMs = (System.nanoTime() - startTime) / 1_000_000
            VisionAidLogger.d(TAG, "Inference latency: ${latencyMs}ms for frame ${frame.frameId}")

            val objects = rawResults.mapIndexedNotNull { index, detection ->
                val category = detection.categories.firstOrNull() ?: return@mapIndexedNotNull null
                val box = detection.boundingBox
                DetectedObject(
                    objectId = "frame${frame.frameId}-det$index",
                    label = CocoLabelMap.toObjectLabel(category.index),
                    boundingBox = com.visionaid.ai.detection.BoundingBox(
                        left = (box.left / bitmap.width).coerceIn(0f, 1f),
                        top = (box.top / bitmap.height).coerceIn(0f, 1f),
                        right = (box.right / bitmap.width).coerceIn(0f, 1f),
                        bottom = (box.bottom / bitmap.height).coerceIn(0f, 1f)
                    ),
                    confidenceScore = category.score
                )
            }

            ToolResult.Success(
                data = DetectionOutput(objects = objects, frameId = frame.frameId),
                confidence = overallConfidence(objects.map { it.confidenceScore }),
                timestampMillis = frame.captureTimestampMillis,
                metadata = mapOf("inferenceLatencyMs" to latencyMs.toString())
            )
        } catch (e: Exception) {
            VisionAidLogger.e(TAG, "Inference failed for frame ${frame.frameId}", e)
            ToolResult.Failure(
                ToolError.InternalError("Inference failed: ${e.message}", e),
                frame.captureTimestampMillis
            )
        }
    }

    private fun overallConfidence(scores: List<Float>): Confidence {
        if (scores.isEmpty()) return Confidence.of(ConfidenceLevel.UNKNOWN)
        val avg = scores.average().toFloat()
        val level = when {
            avg >= 0.75f -> ConfidenceLevel.HIGH
            avg >= 0.5f -> ConfidenceLevel.MEDIUM
            else -> ConfidenceLevel.LOW
        }
        return Confidence.of(level, avg)
    }

    companion object {
        private const val TAG = "LiteRtObjectDetectionTool"

        /** Where the product owner must place the .tflite model file — see MODEL_REGISTRY.md. */
        const val MODEL_ASSET_PATH = "ssd_mobilenet_v2_fpnlite_320.tflite"
        const val MODEL_INPUT_SIZE = 320
    }
}
