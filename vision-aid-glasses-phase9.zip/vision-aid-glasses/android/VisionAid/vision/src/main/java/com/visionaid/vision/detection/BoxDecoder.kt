package com.visionaid.vision.detection

import com.visionaid.ai.detection.BoundingBox

/**
 * Pure, testable postprocessing logic separated from the TFLite Interpreter
 * itself, so it can be unit tested with synthetic arrays without needing a
 * real model file or Android runtime (the Interpreter requires both).
 *
 * The SSD MobileNetV2 FPN-Lite TFLite model with metadata already emits
 * decoded, NMS-applied boxes in [top, left, bottom, right] order, normalized
 * to 0..1 — this class validates and converts that output into our
 * [BoundingBox] contract (which uses [left, top, right, bottom] order) and
 * applies our own confidence-threshold + result-count limits on top of
 * whatever the model/TFLite Task Library already applied.
 */
object BoxDecoder {

    const val DEFAULT_MIN_CONFIDENCE = 0.5f
    const val MAX_RESULTS = 10

    /**
     * @param rawBoxes flat model output: one [top, left, bottom, right] per
     *   detection, all normalized 0..1.
     * @param rawScores one confidence score per detection, same ordering as [rawBoxes].
     * @param rawClasses one COCO class index per detection, same ordering.
     */
    fun decode(
        rawBoxes: List<FloatArray>,
        rawScores: List<Float>,
        rawClasses: List<Int>,
        minConfidence: Float = DEFAULT_MIN_CONFIDENCE
    ): List<Detection> {
        require(rawBoxes.size == rawScores.size && rawScores.size == rawClasses.size) {
            "rawBoxes, rawScores, and rawClasses must be the same length"
        }

        return rawBoxes.indices
            .filter { rawScores[it] >= minConfidence }
            .mapNotNull { i ->
                val box = rawBoxes[i]
                if (box.size != 4) return@mapNotNull null
                val (top, left, bottom, right) = box
                // Guard against degenerate/invalid boxes from a corrupted
                // model output rather than crashing the whole pipeline.
                if (left >= right || top >= bottom) return@mapNotNull null
                val clampedBox = BoundingBox(
                    left = left.coerceIn(0f, 1f),
                    top = top.coerceIn(0f, 1f),
                    right = right.coerceIn(0f, 1f),
                    bottom = bottom.coerceIn(0f, 1f)
                )
                Detection(box = clampedBox, confidenceScore = rawScores[i], cocoClassIndex = rawClasses[i])
            }
            .sortedByDescending { it.confidenceScore }
            .take(MAX_RESULTS)
    }

    private operator fun FloatArray.component1() = this[0]
    private operator fun FloatArray.component2() = this[1]
    private operator fun FloatArray.component3() = this[2]
    private operator fun FloatArray.component4() = this[3]

    data class Detection(
        val box: BoundingBox,
        val confidenceScore: Float,
        val cocoClassIndex: Int
    )
}
