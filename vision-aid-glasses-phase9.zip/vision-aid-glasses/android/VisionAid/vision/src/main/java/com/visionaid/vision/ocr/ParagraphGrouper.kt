package com.visionaid.vision.ocr

/**
 * Groups reading-order-sorted lines into paragraphs based on vertical gap
 * size: a gap noticeably larger than the typical line-to-line spacing marks
 * a new paragraph. Pure, Android-independent, fully unit-testable.
 */
object ParagraphGrouper {

    /** A gap larger than (median line spacing * this multiplier) starts a new paragraph. */
    const val PARAGRAPH_GAP_MULTIPLIER = 1.8f

    /** Fallback gap threshold (as a fraction of frame height) when fewer than 2 lines exist to infer spacing from. */
    const val DEFAULT_GAP_THRESHOLD = 0.03f

    fun group(orderedLines: List<RawTextLine>): List<String> {
        if (orderedLines.isEmpty()) return emptyList()
        if (orderedLines.size == 1) return listOf(orderedLines.first().text)

        val gaps = orderedLines.zipWithNext { a, b -> (b.top - a.bottom).coerceAtLeast(0f) }
        val medianGap = gaps.sorted().let { sorted ->
            val mid = sorted.size / 2
            if (sorted.size % 2 == 0) (sorted[mid - 1] + sorted[mid]) / 2f else sorted[mid]
        }
        val threshold = if (medianGap > 0f) medianGap * PARAGRAPH_GAP_MULTIPLIER else DEFAULT_GAP_THRESHOLD

        val paragraphs = mutableListOf<StringBuilder>()
        paragraphs.add(StringBuilder(orderedLines.first().text))

        for (i in 1 until orderedLines.size) {
            val gap = gaps[i - 1]
            if (gap > threshold) {
                paragraphs.add(StringBuilder(orderedLines[i].text))
            } else {
                paragraphs.last().append(" ").append(orderedLines[i].text)
            }
        }

        return paragraphs.map { it.toString() }
    }
}
