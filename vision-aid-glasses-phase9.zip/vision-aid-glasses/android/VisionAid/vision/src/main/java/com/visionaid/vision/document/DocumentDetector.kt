package com.visionaid.vision.document

import android.graphics.Bitmap

/**
 * Locates a document's four corners within a camera frame.
 *
 * HONEST LIMITATION, stated up front rather than discovered later: a
 * robust, general-purpose document-edge detector (finding a page's
 * boundary against a cluttered background under variable lighting) is a
 * substantial computer-vision task, typically built on a library like
 * OpenCV (contour detection, Canny edges, perspective-quadrilateral
 * fitting). Adding a full OpenCV dependency was judged out of proportion
 * for this phase versus the value delivered, so [SimpleDocumentDetector]
 * below implements a much simpler heuristic instead. This is the same kind
 * of documented, deliberate trade-off as Phase 4's greedy tracker or
 * Phase 5's monocular depth heuristic — not a hidden shortcut.
 */
interface DocumentDetector {
    fun detectCorners(bitmap: Bitmap): DocumentCorners
}

/**
 * Heuristic-only document detector: currently always returns the full
 * frame as the "document" (see [DocumentCorners.fullFrame]), i.e. it
 * assumes the user has already framed the document to fill the camera view
 * — a reasonable assumption for a blind/low-vision user being guided by
 * voice to "hold the page steady and centered," but NOT real edge
 * detection. Upgrading this to genuine corner detection (e.g. via OpenCV
 * or a lightweight learned model) is a documented future improvement, not
 * part of Phase 8's scope.
 */
class SimpleDocumentDetector : DocumentDetector {
    override fun detectCorners(bitmap: Bitmap): DocumentCorners = DocumentCorners.fullFrame()
}
