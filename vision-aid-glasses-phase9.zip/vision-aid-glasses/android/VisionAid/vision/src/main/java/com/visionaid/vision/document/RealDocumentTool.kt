package com.visionaid.vision.document

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolError
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.document.DocumentOutput
import com.visionaid.ai.document.DocumentTool
import com.visionaid.ai.document.Paragraph
import com.visionaid.vision.detection.FramePreprocessor
import com.visionaid.vision.ocr.ParagraphGrouper
import com.visionaid.vision.ocr.TesseractOcrEngine
import com.visionaid.vision.ocr.TextOrderer

/**
 * Real implementation of Phase 2's [DocumentTool]. Full pipeline per the
 * roadmap: camera frame -> document detection -> perspective correction ->
 * image enhancement -> OCR -> text ordering -> paragraph extraction.
 *
 * See [DocumentDetector] for the honest limitation on document-edge
 * detection, and MODEL_REGISTRY.md for the OCR engine's license/dependency
 * decision.
 */
class RealDocumentTool(
    private val documentDetector: DocumentDetector,
    private val ocrEngine: TesseractOcrEngine,
    private val correctedOutputWidth: Int = 1000,
    private val correctedOutputHeight: Int = 1400
) : DocumentTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    private var paragraphs: List<Paragraph> = emptyList()
    private var currentIndex: Int = 0

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun loadDocument(frame: FrameContext): ToolResult<DocumentOutput> {
        if (!ocrEngine.isLanguageAvailable(frame.locale) && !ocrEngine.ensureLanguageInstalled(frame.locale)) {
            return ToolResult.Failure(ToolError.ModelNotLoaded, frame.captureTimestampMillis)
        }

        val originalBitmap = FramePreprocessor.decodeToBitmap(frame.imageData)
            ?: return ToolResult.Failure(ToolError.InvalidInput("Could not decode frame as an image"), frame.captureTimestampMillis)

        val corners = documentDetector.detectCorners(originalBitmap)
        val corrected = PerspectiveCorrector.correct(originalBitmap, corners, correctedOutputWidth, correctedOutputHeight)
        val enhanced = ImageEnhancer.enhance(corrected)

        val rawLines = ocrEngine.recognize(enhanced, frame.locale)
            ?: return ToolResult.Failure(ToolError.InternalError("OCR recognition failed"), frame.captureTimestampMillis)

        if (rawLines.isEmpty()) {
            paragraphs = emptyList()
            currentIndex = 0
            return ToolResult.Success(
                data = DocumentOutput(paragraphs = emptyList(), currentIndex = 0),
                confidence = Confidence.unknown(),
                timestampMillis = frame.captureTimestampMillis
            )
        }

        val orderedLines = TextOrderer.order(rawLines)
        val paragraphTexts = ParagraphGrouper.group(orderedLines)

        paragraphs = paragraphTexts.mapIndexed { index, text -> Paragraph(text = text, index = index) }
        currentIndex = 0

        val avgConfidence = rawLines.map { it.confidenceScore }.average().toFloat()
        val confidenceLevel = when {
            avgConfidence >= 0.8f -> ConfidenceLevel.HIGH
            avgConfidence >= 0.5f -> ConfidenceLevel.MEDIUM
            else -> ConfidenceLevel.LOW
        }

        return ToolResult.Success(
            data = DocumentOutput(paragraphs = paragraphs, currentIndex = currentIndex),
            confidence = Confidence.of(confidenceLevel, avgConfidence),
            timestampMillis = frame.captureTimestampMillis
        )
    }

    override suspend fun readNext(): ToolResult<Paragraph> {
        if (currentIndex >= paragraphs.lastIndex || paragraphs.isEmpty()) {
            return ToolResult.Failure(ToolError.InvalidInput("No next paragraph"), System.currentTimeMillis())
        }
        currentIndex++
        return ToolResult.Success(paragraphs[currentIndex], Confidence.of(ConfidenceLevel.MEDIUM), System.currentTimeMillis())
    }

    override suspend fun readPrevious(): ToolResult<Paragraph> {
        if (currentIndex <= 0 || paragraphs.isEmpty()) {
            return ToolResult.Failure(ToolError.InvalidInput("No previous paragraph"), System.currentTimeMillis())
        }
        currentIndex--
        return ToolResult.Success(paragraphs[currentIndex], Confidence.of(ConfidenceLevel.MEDIUM), System.currentTimeMillis())
    }

    override suspend fun readAll(): ToolResult<DocumentOutput> {
        return ToolResult.Success(
            data = DocumentOutput(paragraphs = paragraphs, currentIndex = currentIndex),
            confidence = Confidence.of(ConfidenceLevel.MEDIUM),
            timestampMillis = System.currentTimeMillis()
        )
    }
}
