package com.visionaid.vision.depth

/**
 * Hardware capability abstraction, per the roadmap's explicit Phase 5
 * instruction: "Do not assume the selected glasses provide two synchronized
 * cameras. Create a hardware capability abstraction."
 *
 * The actual glasses model is still TBD (see PRODUCT_SPEC.md Section 9), so
 * this profile defaults to [DepthCapability.UNKNOWN] and the real depth
 * pipeline must degrade safely under that default — never assume stereo is
 * available just because it might be, once hardware is chosen.
 */
data class CameraHardwareProfile(
    val depthCapability: DepthCapability = DepthCapability.UNKNOWN,
    val calibration: CalibrationConfig? = null
)

enum class DepthCapability {
    /** Two synchronized cameras confirmed present and calibrated for stereo matching. */
    STEREO_CALIBRATED,
    /** Only a single camera confirmed available; monocular techniques only. */
    MONOCULAR_ONLY,
    /** Not yet determined — the glasses model hasn't been selected/inspected yet (Phase 19). */
    UNKNOWN
}
