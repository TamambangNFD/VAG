package com.visionaid.vision.camera

import android.content.Context
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.lifecycle.LifecycleOwner
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.LocaleTag
import com.visionaid.core.logging.VisionAidLogger
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

/**
 * Wraps CameraX to produce [FrameContext] instances for
 * [com.visionaid.vision.detection.LiteRtObjectDetectionTool] (or any other
 * frame-consuming tool). This is the "camera frame" half of the roadmap's
 * Phase 3 pipeline: "camera frame -> preprocessing -> inference ->
 * postprocessing -> ObjectDetectionTool".
 *
 * Frames are throttled to [targetFps] rather than processed at the sensor's
 * native rate, since running inference on every single sensor frame would
 * be wasteful — Phase 25 (Power Optimization) will make this configurable
 * and adaptive; for now it's a fixed, conservative default.
 *
 * This class does not itself call any AI tool — it only produces
 * [FrameContext]s via [onFrame]. Wiring it to a specific tool is the
 * caller's job (kept this way so the same frame source can feed multiple
 * tools in later phases without duplicating camera setup).
 */
class CameraFrameSource(
    private val context: Context,
    private val targetFps: Int = 5
) {
    private val frameIdCounter = AtomicLong(0)
    private var lastFrameTimestampMillis = 0L
    private val analysisExecutor = Executors.newSingleThreadExecutor()

    private var onFrame: ((FrameContext) -> Unit)? = null

    fun start(
        lifecycleOwner: LifecycleOwner,
        locale: LocaleTag,
        onFrame: (FrameContext) -> Unit
    ) {
        this.onFrame = onFrame
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()

                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()

                analysis.setAnalyzer(analysisExecutor) { imageProxy ->
                    handleFrame(imageProxy, locale)
                }

                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    analysis
                )
                VisionAidLogger.i(TAG, "Camera bound successfully, target FPS: $targetFps")
            } catch (e: Exception) {
                VisionAidLogger.e(TAG, "Failed to bind camera", e)
            }
        }, androidx.core.content.ContextCompat.getMainExecutor(context))
    }

    private fun handleFrame(imageProxy: ImageProxy, locale: LocaleTag) {
        val now = System.currentTimeMillis()
        val minIntervalMillis = 1000L / targetFps
        if (now - lastFrameTimestampMillis < minIntervalMillis) {
            imageProxy.close()
            return
        }
        lastFrameTimestampMillis = now

        try {
            val jpegBytes = imageProxyToJpeg(imageProxy)
            if (jpegBytes != null) {
                val frame = FrameContext(
                    frameId = frameIdCounter.incrementAndGet(),
                    imageData = jpegBytes,
                    captureTimestampMillis = now,
                    locale = locale
                )
                onFrame?.invoke(frame)
            }
        } catch (e: Exception) {
            VisionAidLogger.e(TAG, "Failed to process camera frame", e)
        } finally {
            imageProxy.close()
        }
    }

    /**
     * Converts a YUV_420_888 [ImageProxy] (CameraX's default analysis
     * format) to a JPEG byte array. JPEG is used as the interchange format
     * between the camera and preprocessing stage for simplicity in Phase 3;
     * a future performance pass (Phase 25/26) may switch to passing raw
     * planes directly to avoid the encode/decode round-trip.
     */
    private fun imageProxyToJpeg(imageProxy: ImageProxy): ByteArray? {
        if (imageProxy.format != ImageFormat.YUV_420_888) {
            VisionAidLogger.w(TAG, "Unexpected image format: ${imageProxy.format}")
            return null
        }
        val yBuffer = imageProxy.planes[0].buffer
        val uBuffer = imageProxy.planes[1].buffer
        val vBuffer = imageProxy.planes[2].buffer

        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()

        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)

        val yuvImage = YuvImage(nv21, ImageFormat.NV21, imageProxy.width, imageProxy.height, null)
        val outputStream = ByteArrayOutputStream()
        yuvImage.compressToJpeg(Rect(0, 0, imageProxy.width, imageProxy.height), 90, outputStream)
        return outputStream.toByteArray()
    }

    fun stop() {
        onFrame = null
    }

    companion object {
        private const val TAG = "CameraFrameSource"
    }
}
