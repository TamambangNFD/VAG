package com.visionaid.vision.magnification

import android.graphics.Bitmap
import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolError
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.magnification.DisplayTarget
import com.visionaid.ai.magnification.MagnificationRequest
import com.visionaid.ai.magnification.MagnificationTool
import com.visionaid.ai.magnification.MagnifiedOutput
import com.visionaid.core.logging.VisionAidLogger
import com.visionaid.vision.detection.FramePreprocessor
import java.io.ByteArrayOutputStream

/**
 * Real implementation of Phase 9's [MagnificationTool].
 *
 * Per the roadmap: "If the selected glasses do not expose a suitable
 * display API, implement a phone-side test mode and clearly document the
 * hardware limitation." Glasses hardware is still TBD (no model selected,
 * no display API confirmed — see PRODUCT_SPEC.md Section 9), so this
 * implementation ALWAYS outputs [DisplayTarget.PHONE_TEST_MODE] regardless
 * of [DisplayHardwareProfile], the same honest-fallback pattern Phase 5
 * used for unimplemented stereo depth. There is currently no code anywhere
 * in this project that renders to an actual glasses display — building
 * that requires Phase 19's SDK inspection first.
 */
class RealMagnificationTool(
    private val hardwareProfile: DisplayHardwareProfile,
    private val outputWidth: Int = 1024,
    private val outputHeight: Int = 768
) : MagnificationTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    private var brightnessDelta = 0f
    private var contrastDelta = 0f

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun magnify(frame: FrameContext, request: MagnificationRequest): ToolResult<MagnifiedOutput> {
        val sourceBitmap = FramePreprocessor.decodeToBitmap(frame.imageData)
            ?: return ToolResult.Failure(ToolError.InvalidInput("Could not decode frame as an image"), frame.captureTimestampMillis)

        val cropRect = RegionCropper.computeCropRect(request.zoomLevel, request.regionOfInterest)

        val processed = MagnificationImageProcessor.process(
            source = sourceBitmap,
            cropRect = cropRect,
            outputWidth = outputWidth,
            outputHeight = outputHeight,
            brightnessDelta = brightnessDelta,
            contrastDelta = contrastDelta,
            textFocusedMode = request.textFocusedMode
        )

        val outputTarget = resolveOutputTarget()
        val outputBytes = encodeToJpeg(processed)

        return ToolResult.Success(
            data = MagnifiedOutput(
                imageData = outputBytes,
                appliedZoomLevel = request.zoomLevel,
                outputTarget = outputTarget
            ),
            confidence = Confidence.of(ConfidenceLevel.HIGH), // pure image processing, no model uncertainty
            timestampMillis = frame.captureTimestampMillis,
            metadata = mapOf(
                "note" to "Digital zoom enlarges captured pixels; it cannot recover detail the camera did not capture."
            )
        )
    }

    private fun resolveOutputTarget(): DisplayTarget {
        if (hardwareProfile.displayCapability == DisplayCapability.GLASSES_DISPLAY_IMPLEMENTED) {
            // This branch is unreachable today — no hardware profile in
            // this codebase ever sets this value, because no real glasses
            // display rendering code exists yet. Kept here so the intent
            // is explicit once Phase 19 adds real hardware integration.
            VisionAidLogger.w(TAG, "GLASSES_DISPLAY_IMPLEMENTED declared but no rendering code exists — falling back to phone test mode.")
        }
        return DisplayTarget.PHONE_TEST_MODE
    }

    private fun encodeToJpeg(bitmap: Bitmap): ByteArray {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
        return stream.toByteArray()
    }

    override fun setBrightnessAdjustment(delta: Float) {
        brightnessDelta = delta.coerceIn(-1f, 1f)
    }

    override fun setContrastAdjustment(delta: Float) {
        contrastDelta = delta.coerceIn(-1f, 1f)
    }

    companion object {
        private const val TAG = "RealMagnificationTool"
    }
}
