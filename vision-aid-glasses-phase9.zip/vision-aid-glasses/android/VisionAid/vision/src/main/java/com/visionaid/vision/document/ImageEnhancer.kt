package com.visionaid.vision.document

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min

/**
 * Simple grayscale + contrast-stretch enhancement to improve OCR accuracy
 * on photographed (vs. scanned) documents — uneven lighting, low contrast,
 * etc. Pure pixel manipulation, no external image-processing library.
 *
 * This is a basic global contrast stretch, not adaptive thresholding or
 * shadow removal — a documented simplification, consistent with this
 * phase's other pragmatic trade-offs (see DocumentDetector's KDoc).
 */
object ImageEnhancer {

    fun enhance(bitmap: Bitmap): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        val grayValues = IntArray(pixels.size)
        var minGray = 255
        var maxGray = 0
        for (i in pixels.indices) {
            val p = pixels[i]
            val gray = (Color.red(p) * 0.299 + Color.green(p) * 0.587 + Color.blue(p) * 0.114).toInt()
            grayValues[i] = gray
            minGray = min(minGray, gray)
            maxGray = max(maxGray, gray)
        }

        val range = (maxGray - minGray).coerceAtLeast(1)
        for (i in pixels.indices) {
            val stretched = ((grayValues[i] - minGray) * 255 / range).coerceIn(0, 255)
            pixels[i] = Color.rgb(stretched, stretched, stretched)
        }

        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        output.setPixels(pixels, 0, width, 0, 0, width, height)
        return output
    }
}
