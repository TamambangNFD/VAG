package com.visionaid.vision.tracking

import com.visionaid.ai.detection.BoundingBox

/**
 * Associates the previous frame's active tracks with the current frame's
 * detections using greedy IoU matching, restricted to same-label pairs.
 *
 * DESIGN NOTE / KNOWN LIMITATION: this is greedy, not globally optimal (a
 * Hungarian-algorithm assignment would be optimal but is unnecessary
 * complexity for a first cut on mobile hardware, per the roadmap's
 * "suitable lightweight tracker" guidance — see MockObjectTrackingTool's
 * successor, [com.visionaid.vision.tracking.IouObjectTrackingTool]). Greedy
 * matching can occasionally mis-assign when two same-label objects overlap
 * heavily and swap positions between frames — documented as an expected
 * failure case in AI_TOOL_ARCHITECTURE.md / this phase's HANDOFF.md, not
 * silently hidden.
 */
object GreedyTrackMatcher {

    data class TrackCandidate(val trackIndex: Int, val label: com.visionaid.ai.detection.ObjectLabel, val box: BoundingBox)
    data class DetectionCandidate(val detectionIndex: Int, val label: com.visionaid.ai.detection.ObjectLabel, val box: BoundingBox)

    data class MatchResult(
        /** trackIndex -> detectionIndex */
        val matches: List<Pair<Int, Int>>,
        val unmatchedTrackIndices: List<Int>,
        val unmatchedDetectionIndices: List<Int>
    )

    fun match(
        tracks: List<TrackCandidate>,
        detections: List<DetectionCandidate>,
        minIou: Float = 0.3f
    ): MatchResult {
        data class Candidate(val trackIdx: Int, val detIdx: Int, val iou: Float)

        val candidates = mutableListOf<Candidate>()
        for (track in tracks) {
            for (detection in detections) {
                if (track.label != detection.label) continue
                val iou = IouCalculator.iou(track.box, detection.box)
                if (iou >= minIou) {
                    candidates.add(Candidate(track.trackIndex, detection.detectionIndex, iou))
                }
            }
        }

        val sortedCandidates = candidates.sortedByDescending { it.iou }
        val usedTracks = mutableSetOf<Int>()
        val usedDetections = mutableSetOf<Int>()
        val matches = mutableListOf<Pair<Int, Int>>()

        for (candidate in sortedCandidates) {
            if (candidate.trackIdx in usedTracks || candidate.detIdx in usedDetections) continue
            matches.add(candidate.trackIdx to candidate.detIdx)
            usedTracks.add(candidate.trackIdx)
            usedDetections.add(candidate.detIdx)
        }

        val unmatchedTracks = tracks.map { it.trackIndex }.filter { it !in usedTracks }
        val unmatchedDetections = detections.map { it.detectionIndex }.filter { it !in usedDetections }

        return MatchResult(matches, unmatchedTracks, unmatchedDetections)
    }
}
