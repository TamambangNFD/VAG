package com.visionaid.vision.face

import com.visionaid.ai.common.ConfidenceLevel

/**
 * Pure, testable embedding-comparison math. Kept independent of any
 * specific [FaceEmbeddingModel] implementation so it can be unit tested
 * with synthetic vectors now, before any real embedding model exists.
 */
object EmbeddingSimilarity {

    /** Below this cosine similarity, a face is reported as unknown (personId = null). */
    const val RECOGNITION_THRESHOLD = 0.75f

    fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        require(a.size == b.size) { "Embeddings must be the same length to compare (${a.size} vs ${b.size})" }
        var dot = 0f
        var normA = 0f
        var normB = 0f
        for (i in a.indices) {
            dot += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        if (normA == 0f || normB == 0f) return 0f
        return dot / (kotlin.math.sqrt(normA) * kotlin.math.sqrt(normB))
    }

    /**
     * Finds the best-matching stored profile for a given embedding, or null
     * if nothing clears [RECOGNITION_THRESHOLD] — never returns a "best
     * guess" below threshold, per the roadmap's "never claim identity when
     * confidence is below the configured threshold" rule.
     */
    fun findBestMatch(
        queryEmbedding: FloatArray,
        storedProfiles: Map<String, FloatArray>
    ): MatchResult? {
        val best = storedProfiles.entries
            .map { (personId, embedding) -> personId to cosineSimilarity(queryEmbedding, embedding) }
            .maxByOrNull { it.second }
            ?: return null

        if (best.second < RECOGNITION_THRESHOLD) return null
        return MatchResult(personId = best.first, similarity = best.second, confidence = confidenceFor(best.second))
    }

    private fun confidenceFor(similarity: Float): ConfidenceLevel = when {
        similarity >= 0.90f -> ConfidenceLevel.HIGH
        similarity >= 0.80f -> ConfidenceLevel.MEDIUM
        else -> ConfidenceLevel.LOW // still above RECOGNITION_THRESHOLD (0.75) but not by much
    }

    data class MatchResult(val personId: String, val similarity: Float, val confidence: ConfidenceLevel)
}
