package com.visionaid.vision.depth

import com.visionaid.ai.depth.DistanceBand
import com.visionaid.ai.detection.DetectedObject

/**
 * SAFETY-CRITICAL logic (roadmap Section 0.4). Pure, Android-independent
 * distance estimation using the classic pinhole-camera "known object size"
 * technique: distance ≈ (real_height_m × normalizedFocalLength) /
 * bbox_height_normalized.
 *
 * This is a monocular, single-frame heuristic — NOT a measurement. It is
 * used only when no stereo capability is available (which, until glasses
 * hardware is selected in Phase 19, is the assumed default). Kept dependency
 * -free from Android/TFLite so it is fully unit-testable without a device.
 *
 * CONSERVATIVE-BY-DESIGN DECISIONS (do not "fix" these without re-reading
 * Section 0.4 of the roadmap first):
 * - No calibration -> UNKNOWN for everything. Never guess a focal length.
 * - No reference height for the object's label -> UNKNOWN for that object.
 *   Never substitute a generic/average height across unrelated classes.
 * - Bounding box height outside [minReliableBoxHeight, maxReliableBoxHeight]
 *   -> UNKNOWN. Very small boxes (far/noisy detection) and very large boxes
 *   (likely clipped by the frame edge) produce unreliable size-based
 *   estimates.
 * - A margin around each NEAR/MEDIUM band boundary is mapped to UNKNOWN
 *   rather than confidently committing to one side. This directly
 *   implements the roadmap's "prefer UNKNOWN over false precision" rule at
 *   exactly the point where a wrong call is most likely (right at a
 *   threshold) and most consequential (NEAR vs. MEDIUM is the difference
 *   that matters for an obstacle warning).
 */
object MonocularSizeBasedDepthEstimator {

    const val NEAR_MAX_METERS = 1.5f
    const val MEDIUM_MAX_METERS = 4.0f

    /** Fractional margin around each band boundary that is treated as UNKNOWN rather than committed. */
    const val BOUNDARY_MARGIN_FRACTION = 0.15f

    fun estimate(
        detectedObjects: List<DetectedObject>,
        calibration: CalibrationConfig?
    ): Map<String, DistanceEstimate> {
        if (calibration == null) {
            return detectedObjects.associate {
                it.objectId to DistanceEstimate.unknown("No calibration configured for this device")
            }
        }

        return detectedObjects.associate { obj ->
            obj.objectId to estimateOne(obj, calibration)
        }
    }

    private fun estimateOne(obj: DetectedObject, calibration: CalibrationConfig): DistanceEstimate {
        val referenceHeight = calibration.referenceHeightsMeters[obj.label]
            ?: return DistanceEstimate.unknown("No reliable reference size for label ${obj.label}")

        val bboxHeight = obj.boundingBox.bottom - obj.boundingBox.top
        if (bboxHeight < calibration.minReliableBoxHeight) {
            return DistanceEstimate.unknown("Bounding box too small to estimate reliably (object likely far or detection noisy)")
        }
        if (bboxHeight > calibration.maxReliableBoxHeight) {
            return DistanceEstimate.unknown("Bounding box too large to estimate reliably (object likely clipped or very close)")
        }

        val estimatedMeters = (referenceHeight * calibration.normalizedFocalLength) / bboxHeight

        val band = bandFor(estimatedMeters)
            ?: return DistanceEstimate.unknown(
                "Estimated distance (${"%.2f".format(estimatedMeters)}m) is within the uncertainty " +
                    "margin of a band boundary — refusing to commit to NEAR vs MEDIUM vs FAR"
            )

        return DistanceEstimate.of(estimatedMeters, band)
    }

    /** Returns null (meaning: treat as UNKNOWN) when the estimate falls within the boundary margin. */
    private fun bandFor(meters: Float): DistanceBand? {
        val nearMarginLow = NEAR_MAX_METERS * (1 - BOUNDARY_MARGIN_FRACTION)
        val nearMarginHigh = NEAR_MAX_METERS * (1 + BOUNDARY_MARGIN_FRACTION)
        val mediumMarginLow = MEDIUM_MAX_METERS * (1 - BOUNDARY_MARGIN_FRACTION)
        val mediumMarginHigh = MEDIUM_MAX_METERS * (1 + BOUNDARY_MARGIN_FRACTION)

        return when {
            meters < nearMarginLow -> DistanceBand.NEAR
            meters in nearMarginLow..nearMarginHigh -> null // ambiguous NEAR/MEDIUM boundary
            meters < mediumMarginLow -> DistanceBand.MEDIUM
            meters in mediumMarginLow..mediumMarginHigh -> null // ambiguous MEDIUM/FAR boundary
            else -> DistanceBand.FAR
        }
    }
}

data class DistanceEstimate(
    val band: DistanceBand,
    /** Internal estimate only — never surfaced to the user as a precise number at this phase. */
    val estimatedMeters: Float?,
    val reasonIfUnknown: String?
) {
    companion object {
        fun unknown(reason: String) = DistanceEstimate(DistanceBand.UNKNOWN, null, reason)
        fun of(meters: Float, band: DistanceBand) = DistanceEstimate(band, meters, null)
    }
}
