package com.visionaid.vision.ocr

/**
 * Sorts raw OCR lines into natural reading order: top-to-bottom, then
 * left-to-right within the same visual row. Pure, Android-independent logic
 * so it's fully unit-testable without a real OCR engine.
 *
 * "Same row" is determined by a vertical-overlap heuristic rather than
 * exact top-coordinate equality, since OCR line boxes for the same visual
 * line rarely have identical top values.
 */
object TextOrderer {

    /** Lines whose top values differ by less than this fraction of frame height are considered the same row. */
    const val ROW_GROUPING_TOLERANCE = 0.015f

    fun order(lines: List<RawTextLine>): List<RawTextLine> {
        if (lines.isEmpty()) return emptyList()

        val sortedByTop = lines.sortedBy { it.top }
        val rows = mutableListOf<MutableList<RawTextLine>>()

        for (line in sortedByTop) {
            val currentRow = rows.lastOrNull()
            if (currentRow != null && kotlin.math.abs(line.top - currentRow.first().top) <= ROW_GROUPING_TOLERANCE) {
                currentRow.add(line)
            } else {
                rows.add(mutableListOf(line))
            }
        }

        return rows.flatMap { row -> row.sortedBy { it.left } }
    }
}
