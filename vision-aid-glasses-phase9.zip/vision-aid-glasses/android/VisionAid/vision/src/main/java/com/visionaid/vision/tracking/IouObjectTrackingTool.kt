package com.visionaid.vision.tracking

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.detection.DetectedObject
import com.visionaid.ai.tracking.MovementDirection
import com.visionaid.ai.tracking.ObjectTrackingTool
import com.visionaid.ai.tracking.TrackedObject
import com.visionaid.ai.tracking.TrackingOutput
import com.visionaid.core.logging.VisionAidLogger

/**
 * Real implementation of Phase 2's [ObjectTrackingTool] using greedy
 * IoU-based association (see [GreedyTrackMatcher]) rather than a full
 * ByteTrack/Kalman-filter tracker — a deliberate, documented lightweight
 * choice appropriate for on-device mobile resource constraints, per the
 * roadmap's "ByteTrack or another suitable lightweight tracker" guidance.
 *
 * KNOWN LIMITATIONS (see also HANDOFF.md for this phase):
 * - No motion prediction: a fast-moving object that displaces more than
 *   roughly its own size between frames may fail to match (IoU below
 *   threshold) and will be assigned a new track ID. A Kalman-filter-based
 *   tracker (true ByteTrack) would predict position and handle this better;
 *   left as a documented upgrade path, not attempted in Phase 4.
 * - Greedy (not globally optimal) matching can occasionally swap IDs when
 *   two same-label objects overlap heavily and cross paths.
 * - [MovementDirection.APPROACHING]/[RECEDING] are inferred from bounding
 *   box area growth/shrinkage as a heuristic, NOT from real depth — Phase 5
 *   (Depth) and Phase 6 (World Model) will supersede this with actual
 *   distance data. This heuristic must not be treated as depth-equivalent
 *   by any safety-critical consumer.
 */
class IouObjectTrackingTool(
    private val maxMissedFrames: Int = 5,
    private val minIouToMatch: Float = 0.3f,
    private val horizontalMovementThreshold: Float = 0.02f,
    private val areaChangeThreshold: Float = 0.05f
) : ObjectTrackingTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    private data class TrackState(
        val trackId: String,
        var lastDetection: DetectedObject,
        var framesTracked: Int,
        var missedFrames: Int
    )

    private val activeTracks = mutableListOf<TrackState>()
    private var nextTrackIdNumber = 1

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun update(
        detections: List<DetectedObject>,
        frameTimestampMillis: Long
    ): ToolResult<TrackingOutput> {
        val trackCandidates = activeTracks.mapIndexed { index, track ->
            GreedyTrackMatcher.TrackCandidate(index, track.lastDetection.label, track.lastDetection.boundingBox)
        }
        val detectionCandidates = detections.mapIndexed { index, detection ->
            GreedyTrackMatcher.DetectionCandidate(index, detection.label, detection.boundingBox)
        }

        val matchResult = GreedyTrackMatcher.match(trackCandidates, detectionCandidates, minIouToMatch)

        val outputTracks = mutableListOf<TrackedObject>()

        // Matched: update existing tracks.
        for ((trackIdx, detIdx) in matchResult.matches) {
            val track = activeTracks[trackIdx]
            val newDetection = detections[detIdx]
            val movement = estimateMovement(track.lastDetection, newDetection)

            track.lastDetection = newDetection
            track.framesTracked += 1
            track.missedFrames = 0

            outputTracks.add(
                TrackedObject(
                    trackId = track.trackId,
                    detectedObject = newDetection,
                    movement = movement,
                    framesTracked = track.framesTracked
                )
            )
        }

        // Unmatched tracks: object possibly occluded or left the frame.
        val tracksToRemove = mutableListOf<TrackState>()
        for (trackIdx in matchResult.unmatchedTrackIndices) {
            val track = activeTracks[trackIdx]
            track.missedFrames += 1
            if (track.missedFrames > maxMissedFrames) {
                tracksToRemove.add(track)
                VisionAidLogger.d(TAG, "Dropping track ${track.trackId} after ${track.missedFrames} missed frames")
            }
            // Tracks within tolerance are NOT included in this frame's
            // output (nothing new was observed for them) but are retained
            // internally so a brief occlusion doesn't create a new ID.
        }
        activeTracks.removeAll(tracksToRemove)

        // Unmatched detections: new objects entering the frame.
        for (detIdx in matchResult.unmatchedDetectionIndices) {
            val detection = detections[detIdx]
            val newTrackId = "track-${nextTrackIdNumber++}"
            activeTracks.add(TrackState(newTrackId, detection, framesTracked = 1, missedFrames = 0))
            outputTracks.add(
                TrackedObject(
                    trackId = newTrackId,
                    detectedObject = detection,
                    movement = MovementDirection.UNKNOWN, // no prior frame to compare against yet
                    framesTracked = 1
                )
            )
        }

        return ToolResult.Success(
            data = TrackingOutput(tracks = outputTracks),
            confidence = Confidence.of(ConfidenceLevel.MEDIUM),
            timestampMillis = frameTimestampMillis,
            metadata = mapOf("activeTrackCount" to activeTracks.size.toString())
        )
    }

    private fun estimateMovement(previous: DetectedObject, current: DetectedObject): MovementDirection {
        val prevCenterX = IouCalculator.centerX(previous.boundingBox)
        val currCenterX = IouCalculator.centerX(current.boundingBox)
        val dx = currCenterX - prevCenterX

        val prevArea = IouCalculator.area(previous.boundingBox)
        val currArea = IouCalculator.area(current.boundingBox)
        val relativeAreaChange = if (prevArea > 0f) (currArea - prevArea) / prevArea else 0f

        // Area growth is a heuristic proxy for "approaching" pending real
        // depth data (Phase 5) — see class KDoc.
        return when {
            relativeAreaChange > areaChangeThreshold -> MovementDirection.APPROACHING
            relativeAreaChange < -areaChangeThreshold -> MovementDirection.RECEDING
            dx > horizontalMovementThreshold -> MovementDirection.LEFT_TO_RIGHT
            dx < -horizontalMovementThreshold -> MovementDirection.RIGHT_TO_LEFT
            else -> MovementDirection.STATIONARY
        }
    }

    override fun reset() {
        activeTracks.clear()
        nextTrackIdNumber = 1
    }

    companion object {
        private const val TAG = "IouObjectTrackingTool"
    }
}
