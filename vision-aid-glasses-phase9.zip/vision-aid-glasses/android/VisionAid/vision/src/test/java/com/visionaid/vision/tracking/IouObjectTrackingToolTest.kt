package com.visionaid.vision.tracking

import com.visionaid.ai.detection.BoundingBox
import com.visionaid.ai.detection.DetectedObject
import com.visionaid.ai.detection.ObjectLabel
import com.visionaid.ai.tracking.MovementDirection
import com.visionaid.ai.common.ToolResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Exercises [IouObjectTrackingTool] against recorded, hand-authored
 * detection sequences (rather than a live camera/model), per the roadmap
 * Phase 4 requirement: "Create tests using recorded detection sequences."
 */
class IouObjectTrackingToolTest {

    private fun person(id: String, left: Float, top: Float, right: Float, bottom: Float) = DetectedObject(
        objectId = id,
        label = ObjectLabel.PERSON,
        boundingBox = BoundingBox(left, top, right, bottom),
        confidenceScore = 0.8f
    )

    @Test
    fun `a person walking left to right keeps the same trackId across frames`() = runBlocking {
        val tool = IouObjectTrackingTool()

        // Simulated 5-frame sequence: person drifts rightward slightly each frame.
        val frame1 = tool.update(listOf(person("d1", 0.10f, 0.20f, 0.30f, 0.60f)), 1000L) as ToolResult.Success
        val frame2 = tool.update(listOf(person("d1", 0.13f, 0.20f, 0.33f, 0.60f)), 1033L) as ToolResult.Success
        val frame3 = tool.update(listOf(person("d1", 0.16f, 0.20f, 0.36f, 0.60f)), 1066L) as ToolResult.Success

        val id1 = frame1.data.tracks.first().trackId
        val id2 = frame2.data.tracks.first().trackId
        val id3 = frame3.data.tracks.first().trackId

        assertEquals(id1, id2)
        assertEquals(id2, id3)
        assertEquals(MovementDirection.LEFT_TO_RIGHT, frame3.data.tracks.first().movement)
    }

    @Test
    fun `framesTracked increments correctly across a recorded sequence`() = runBlocking {
        val tool = IouObjectTrackingTool()
        tool.update(listOf(person("d1", 0.1f, 0.1f, 0.3f, 0.5f)), 1000L)
        tool.update(listOf(person("d1", 0.11f, 0.1f, 0.31f, 0.5f)), 1033L)
        val third = tool.update(listOf(person("d1", 0.12f, 0.1f, 0.32f, 0.5f)), 1066L) as ToolResult.Success

        assertEquals(3, third.data.tracks.first().framesTracked)
    }

    @Test
    fun `a brief occlusion (one missed frame) does not create a new trackId`() = runBlocking {
        val tool = IouObjectTrackingTool()
        val frame1 = tool.update(listOf(person("d1", 0.1f, 0.1f, 0.3f, 0.5f)), 1000L) as ToolResult.Success
        val idBeforeOcclusion = frame1.data.tracks.first().trackId

        // Frame 2: object briefly occluded, no detection at all.
        tool.update(emptyList(), 1033L)

        // Frame 3: object reappears in roughly the same place.
        val frame3 = tool.update(listOf(person("d1", 0.11f, 0.1f, 0.31f, 0.5f)), 1066L) as ToolResult.Success

        assertEquals(idBeforeOcclusion, frame3.data.tracks.first().trackId)
    }

    @Test
    fun `an object missed for longer than the tolerance gets a new trackId on reappearance`() = runBlocking {
        val tool = IouObjectTrackingTool(maxMissedFrames = 2)
        val frame1 = tool.update(listOf(person("d1", 0.1f, 0.1f, 0.3f, 0.5f)), 1000L) as ToolResult.Success
        val originalId = frame1.data.tracks.first().trackId

        // Missed for more frames than the tolerance allows.
        tool.update(emptyList(), 1033L)
        tool.update(emptyList(), 1066L)
        tool.update(emptyList(), 1099L)
        tool.update(emptyList(), 1132L)

        val reappear = tool.update(listOf(person("d1", 0.1f, 0.1f, 0.3f, 0.5f)), 1165L) as ToolResult.Success

        assertTrue(reappear.data.tracks.first().trackId != originalId)
    }

    @Test
    fun `a new object entering the frame gets a fresh trackId with UNKNOWN movement`() = runBlocking {
        val tool = IouObjectTrackingTool()
        tool.update(listOf(person("d1", 0.1f, 0.1f, 0.3f, 0.5f)), 1000L)

        // Second object enters in frame 2, far from the first.
        val frame2 = tool.update(
            listOf(
                person("d1", 0.1f, 0.1f, 0.3f, 0.5f),
                person("d2", 0.7f, 0.1f, 0.9f, 0.5f)
            ),
            1033L
        ) as ToolResult.Success

        val newTrack = frame2.data.tracks.first { it.detectedObject.objectId == "d2" }
        assertEquals(MovementDirection.UNKNOWN, newTrack.movement)
        assertEquals(1, newTrack.framesTracked)
    }

    @Test
    fun `two people never share the same trackId (no duplicate IDs)`() = runBlocking {
        val tool = IouObjectTrackingTool()
        val result = tool.update(
            listOf(
                person("d1", 0.0f, 0.0f, 0.2f, 0.4f),
                person("d2", 0.6f, 0.0f, 0.8f, 0.4f)
            ),
            1000L
        ) as ToolResult.Success

        val ids = result.data.tracks.map { it.trackId }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test
    fun `reset clears all track history`() = runBlocking {
        val tool = IouObjectTrackingTool()
        tool.update(listOf(person("d1", 0.1f, 0.1f, 0.3f, 0.5f)), 1000L)
        tool.reset()

        val afterReset = tool.update(listOf(person("d1", 0.1f, 0.1f, 0.3f, 0.5f)), 2000L) as ToolResult.Success
        assertEquals(1, afterReset.data.tracks.first().framesTracked)
        assertEquals("track-1", afterReset.data.tracks.first().trackId)
    }

    @Test
    fun `growing bounding box area is reported as APPROACHING`() = runBlocking {
        val tool = IouObjectTrackingTool()
        tool.update(listOf(person("d1", 0.30f, 0.30f, 0.40f, 0.40f)), 1000L) // small box
        val second = tool.update(listOf(person("d1", 0.20f, 0.20f, 0.50f, 0.50f)), 1033L) as ToolResult.Success // much bigger box

        assertEquals(MovementDirection.APPROACHING, second.data.tracks.first().movement)
    }
}
