package com.visionaid.vision.ocr

import org.junit.Assert.assertEquals
import org.junit.Test

class ParagraphGrouperTest {

    private fun line(text: String, top: Float, bottom: Float) = RawTextLine(text, 0.9f, top, 0.1f, bottom)

    @Test
    fun `consecutive lines with normal spacing form one paragraph`() {
        val lines = listOf(
            line("Line one.", 0.10f, 0.13f),
            line("Line two.", 0.14f, 0.17f),
            line("Line three.", 0.18f, 0.21f)
        )
        val paragraphs = ParagraphGrouper.group(lines)
        assertEquals(1, paragraphs.size)
        assertEquals("Line one. Line two. Line three.", paragraphs.first())
    }

    @Test
    fun `a large gap starts a new paragraph`() {
        val lines = listOf(
            line("Paragraph one line one.", 0.10f, 0.13f),
            line("Paragraph one line two.", 0.14f, 0.17f),
            // Big gap here relative to the ~0.01 gaps above.
            line("Paragraph two starts here.", 0.30f, 0.33f)
        )
        val paragraphs = ParagraphGrouper.group(lines)
        assertEquals(2, paragraphs.size)
        assertEquals("Paragraph one line one. Paragraph one line two.", paragraphs[0])
        assertEquals("Paragraph two starts here.", paragraphs[1])
    }

    @Test
    fun `single line returns a single paragraph`() {
        val paragraphs = ParagraphGrouper.group(listOf(line("Only line.", 0.1f, 0.13f)))
        assertEquals(listOf("Only line."), paragraphs)
    }

    @Test
    fun `empty input returns empty output`() {
        assertEquals(emptyList<String>(), ParagraphGrouper.group(emptyList()))
    }

    @Test
    fun `gap threshold constant is a real multiplier greater than 1`() {
        assert(ParagraphGrouper.PARAGRAPH_GAP_MULTIPLIER > 1.0f)
    }
}
