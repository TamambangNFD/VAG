package com.visionaid.vision.tracking

import com.visionaid.ai.detection.BoundingBox
import org.junit.Assert.assertEquals
import org.junit.Test

class IouCalculatorTest {

    @Test
    fun `identical boxes have IoU of 1`() {
        val box = BoundingBox(0.1f, 0.1f, 0.5f, 0.5f)
        assertEquals(1.0f, IouCalculator.iou(box, box), 0.001f)
    }

    @Test
    fun `non-overlapping boxes have IoU of 0`() {
        val a = BoundingBox(0.0f, 0.0f, 0.2f, 0.2f)
        val b = BoundingBox(0.5f, 0.5f, 0.7f, 0.7f)
        assertEquals(0.0f, IouCalculator.iou(a, b), 0.001f)
    }

    @Test
    fun `partially overlapping boxes have IoU between 0 and 1`() {
        val a = BoundingBox(0.0f, 0.0f, 0.4f, 0.4f)
        val b = BoundingBox(0.2f, 0.2f, 0.6f, 0.6f)
        val iou = IouCalculator.iou(a, b)
        assert(iou > 0f && iou < 1f)
    }
}
