package com.visionaid.vision.document

import org.junit.Assert.assertEquals
import org.junit.Test

class DocumentCornersTest {

    @Test
    fun `fullFrame covers the entire normalized frame`() {
        val corners = DocumentCorners.fullFrame()
        assertEquals(0f, corners.topLeftX)
        assertEquals(0f, corners.topLeftY)
        assertEquals(1f, corners.bottomRightX)
        assertEquals(1f, corners.bottomRightY)
    }
}
