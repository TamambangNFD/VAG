package com.visionaid.vision.face

import com.visionaid.ai.detection.BoundingBox
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Locks in the deliberate "no embedding model yet" behavior — a regression
 * here (someone wiring in an unvetted model without updating this test and
 * MODEL_REGISTRY.md) would be a real provenance/licensing compliance
 * failure, not just a test failure.
 */
class NoFaceEmbeddingModelAvailableTest {

    @Test
    fun `always reports unavailable`() {
        assertFalse(NoFaceEmbeddingModelAvailable().isAvailable())
    }

    @Test
    fun `never generates an embedding`() {
        val model = NoFaceEmbeddingModelAvailable()
        val result = model.generateEmbedding(ByteArray(0), BoundingBox(0.1f, 0.1f, 0.5f, 0.5f))
        assertNull(result)
    }
}
