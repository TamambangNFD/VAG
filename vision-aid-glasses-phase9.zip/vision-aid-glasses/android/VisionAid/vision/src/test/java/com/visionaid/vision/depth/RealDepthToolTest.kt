package com.visionaid.vision.depth

import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.depth.DistanceBand
import com.visionaid.ai.detection.BoundingBox
import com.visionaid.ai.detection.DetectedObject
import com.visionaid.ai.detection.ObjectLabel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Safety-critical tests for the tool-level wiring: hardware-capability
 * routing and confidence capping.
 */
class RealDepthToolTest {

    private fun frame() = FrameContext(1L, ByteArray(0), 1000L)
    private fun person(boxHeight: Float) = DetectedObject(
        "obj-1", ObjectLabel.PERSON,
        BoundingBox(0.3f, 0.5f - boxHeight / 2, 0.5f, 0.5f + boxHeight / 2),
        0.9f
    )

    @Test
    fun `stereo capability falls back to UNKNOWN, never fabricates a stereo result`() = runBlocking {
        val profile = CameraHardwareProfile(depthCapability = DepthCapability.STEREO_CALIBRATED)
        val tool = RealDepthTool(profile)

        val result = tool.estimateDistance(frame(), listOf(person(0.85f))) as ToolResult.Success

        assertEquals(DistanceBand.UNKNOWN, result.data.distances.getValue("obj-1"))
        assertEquals(ConfidenceLevel.UNKNOWN, result.confidence.level)
        assertEquals("stereo_not_yet_implemented", result.metadata["estimationMethod"])
    }

    @Test
    fun `monocular path with no calibration reports UNKNOWN with UNKNOWN confidence`() = runBlocking {
        val profile = CameraHardwareProfile(depthCapability = DepthCapability.UNKNOWN, calibration = null)
        val tool = RealDepthTool(profile)

        val result = tool.estimateDistance(frame(), listOf(person(0.85f))) as ToolResult.Success

        assertEquals(DistanceBand.UNKNOWN, result.data.distances.getValue("obj-1"))
        assertEquals(ConfidenceLevel.UNKNOWN, result.confidence.level)
    }

    @Test
    fun `monocular path with valid calibration never exceeds LOW confidence`() = runBlocking {
        // Even a clean, unambiguous estimate must be capped at LOW —
        // this heuristic is unvalidated against real-world measurements
        // until Phase 29/31.
        val calibration = CalibrationConfig(normalizedFocalLength = 0.5f)
        val profile = CameraHardwareProfile(depthCapability = DepthCapability.MONOCULAR_ONLY, calibration = calibration)
        val tool = RealDepthTool(profile)

        val result = tool.estimateDistance(frame(), listOf(person(0.85f))) as ToolResult.Success

        assertEquals(DistanceBand.NEAR, result.data.distances.getValue("obj-1"))
        assertEquals(ConfidenceLevel.LOW, result.confidence.level)
        assertTrue(
            "Confidence must never be MEDIUM or HIGH for this unvalidated heuristic",
            result.confidence.level != ConfidenceLevel.MEDIUM && result.confidence.level != ConfidenceLevel.HIGH
        )
    }

    @Test
    fun `availability is always AVAILABLE regardless of hardware profile`() {
        val tool = RealDepthTool(CameraHardwareProfile())
        assertEquals(com.visionaid.ai.common.ToolAvailability.AVAILABLE, tool.availability())
    }
}
