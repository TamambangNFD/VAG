package com.visionaid.vision.tracking

import com.visionaid.ai.detection.BoundingBox
import com.visionaid.ai.detection.ObjectLabel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GreedyTrackMatcherTest {

    @Test
    fun `matches overlapping same-label boxes`() {
        val track = GreedyTrackMatcher.TrackCandidate(0, ObjectLabel.PERSON, BoundingBox(0.1f, 0.1f, 0.5f, 0.5f))
        val detection = GreedyTrackMatcher.DetectionCandidate(0, ObjectLabel.PERSON, BoundingBox(0.12f, 0.12f, 0.52f, 0.52f))

        val result = GreedyTrackMatcher.match(listOf(track), listOf(detection))

        assertEquals(listOf(0 to 0), result.matches)
        assertTrue(result.unmatchedTrackIndices.isEmpty())
        assertTrue(result.unmatchedDetectionIndices.isEmpty())
    }

    @Test
    fun `does not match different labels even with perfect overlap`() {
        val track = GreedyTrackMatcher.TrackCandidate(0, ObjectLabel.PERSON, BoundingBox(0.1f, 0.1f, 0.5f, 0.5f))
        val detection = GreedyTrackMatcher.DetectionCandidate(0, ObjectLabel.CAR, BoundingBox(0.1f, 0.1f, 0.5f, 0.5f))

        val result = GreedyTrackMatcher.match(listOf(track), listOf(detection))

        assertTrue(result.matches.isEmpty())
        assertEquals(listOf(0), result.unmatchedTrackIndices)
        assertEquals(listOf(0), result.unmatchedDetectionIndices)
    }

    @Test
    fun `unrelated far-apart boxes are left unmatched, not force-matched`() {
        val track = GreedyTrackMatcher.TrackCandidate(0, ObjectLabel.PERSON, BoundingBox(0.0f, 0.0f, 0.1f, 0.1f))
        val detection = GreedyTrackMatcher.DetectionCandidate(0, ObjectLabel.PERSON, BoundingBox(0.8f, 0.8f, 0.9f, 0.9f))

        val result = GreedyTrackMatcher.match(listOf(track), listOf(detection))

        assertTrue(result.matches.isEmpty())
        assertEquals(listOf(0), result.unmatchedTrackIndices)
        assertEquals(listOf(0), result.unmatchedDetectionIndices)
    }

    @Test
    fun `each track and detection is used at most once`() {
        val trackA = GreedyTrackMatcher.TrackCandidate(0, ObjectLabel.PERSON, BoundingBox(0.10f, 0.10f, 0.50f, 0.50f))
        val trackB = GreedyTrackMatcher.TrackCandidate(1, ObjectLabel.PERSON, BoundingBox(0.11f, 0.11f, 0.51f, 0.51f))
        val detection = GreedyTrackMatcher.DetectionCandidate(0, ObjectLabel.PERSON, BoundingBox(0.10f, 0.10f, 0.50f, 0.50f))

        val result = GreedyTrackMatcher.match(listOf(trackA, trackB), listOf(detection))

        assertEquals(1, result.matches.size)
        assertEquals(1, result.unmatchedTrackIndices.size)
    }
}
