package com.visionaid.vision.magnification

import com.visionaid.ai.detection.BoundingBox
import com.visionaid.ai.magnification.ZoomLevel
import org.junit.Assert.assertEquals
import org.junit.Test

class RegionCropperTest {

    @Test
    fun `no region of interest crops centered on the frame`() {
        val rect = RegionCropper.computeCropRect(ZoomLevel.X2, null)
        val centerX = (rect.left + rect.right) / 2f
        val centerY = (rect.top + rect.bottom) / 2f
        assertEquals(0.5f, centerX, 0.001f)
        assertEquals(0.5f, centerY, 0.001f)
    }

    @Test
    fun `crop size matches 1 over zoom factor`() {
        val rect2x = RegionCropper.computeCropRect(ZoomLevel.X2, null)
        assertEquals(0.5f, rect2x.right - rect2x.left, 0.001f)

        val rect4x = RegionCropper.computeCropRect(ZoomLevel.X4, null)
        assertEquals(0.25f, rect4x.right - rect4x.left, 0.001f)

        val rect8x = RegionCropper.computeCropRect(ZoomLevel.X8, null)
        assertEquals(0.125f, rect8x.right - rect8x.left, 0.001f)
    }

    @Test
    fun `region of interest near the top-left edge shifts the crop rather than overflowing`() {
        val roi = BoundingBox(0.0f, 0.0f, 0.05f, 0.05f) // center near (0.025, 0.025)
        val rect = RegionCropper.computeCropRect(ZoomLevel.X4, roi) // crop size 0.25

        assert(rect.left >= 0f) { "Crop must not extend past the left edge" }
        assert(rect.top >= 0f) { "Crop must not extend past the top edge" }
        assertEquals(0.25f, rect.right - rect.left, 0.001f) // still full crop size
    }

    @Test
    fun `region of interest near the bottom-right edge shifts the crop rather than overflowing`() {
        val roi = BoundingBox(0.95f, 0.95f, 1.0f, 1.0f)
        val rect = RegionCropper.computeCropRect(ZoomLevel.X4, roi)

        assert(rect.right <= 1f) { "Crop must not extend past the right edge" }
        assert(rect.bottom <= 1f) { "Crop must not extend past the bottom edge" }
        assertEquals(0.25f, rect.right - rect.left, 0.001f)
    }

    @Test
    fun `region of interest center is respected when it fits without clamping`() {
        val roi = BoundingBox(0.4f, 0.4f, 0.5f, 0.5f) // center (0.45, 0.45)
        val rect = RegionCropper.computeCropRect(ZoomLevel.X8, roi) // crop size 0.125

        val centerX = (rect.left + rect.right) / 2f
        val centerY = (rect.top + rect.bottom) / 2f
        assertEquals(0.45f, centerX, 0.001f)
        assertEquals(0.45f, centerY, 0.001f)
    }

    @Test
    fun `resulting crop is always within the 0 to 1 frame bounds`() {
        val extremeRoi = BoundingBox(0.99f, 0.0f, 1.0f, 0.01f)
        val rect = RegionCropper.computeCropRect(ZoomLevel.X8, extremeRoi)

        assert(rect.left in 0f..1f)
        assert(rect.top in 0f..1f)
        assert(rect.right in 0f..1f)
        assert(rect.bottom in 0f..1f)
    }
}
