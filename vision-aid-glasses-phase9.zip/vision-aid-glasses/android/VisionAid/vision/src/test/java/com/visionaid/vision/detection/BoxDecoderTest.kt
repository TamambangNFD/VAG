package com.visionaid.vision.detection

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BoxDecoderTest {

    @Test
    fun `filters out detections below the confidence threshold`() {
        val boxes = listOf(floatArrayOf(0.1f, 0.1f, 0.5f, 0.5f), floatArrayOf(0.2f, 0.2f, 0.6f, 0.6f))
        val scores = listOf(0.9f, 0.2f)
        val classes = listOf(0, 1)

        val result = BoxDecoder.decode(boxes, scores, classes, minConfidence = 0.5f)

        assertEquals(1, result.size)
        assertEquals(0.9f, result.first().confidenceScore)
    }

    @Test
    fun `rejects degenerate boxes with zero or negative area`() {
        val boxes = listOf(floatArrayOf(0.5f, 0.5f, 0.5f, 0.5f)) // top==bottom, left==right
        val scores = listOf(0.9f)
        val classes = listOf(0)

        val result = BoxDecoder.decode(boxes, scores, classes)

        assertTrue(result.isEmpty())
    }

    @Test
    fun `caps results at MAX_RESULTS, keeping highest confidence`() {
        val count = BoxDecoder.MAX_RESULTS + 5
        val boxes = List(count) { floatArrayOf(0.1f, 0.1f, 0.5f, 0.5f) }
        val scores = List(count) { i -> 0.5f + i * 0.01f }
        val classes = List(count) { 0 }

        val result = BoxDecoder.decode(boxes, scores, classes, minConfidence = 0f)

        assertEquals(BoxDecoder.MAX_RESULTS, result.size)
        // Highest score should be first (sortedByDescending)
        assertEquals(scores.max(), result.first().confidenceScore)
    }

    @Test
    fun `mismatched input lengths throw`() {
        try {
            BoxDecoder.decode(listOf(floatArrayOf(0f, 0f, 1f, 1f)), listOf(0.5f, 0.6f), listOf(0))
            assert(false) { "Expected IllegalArgumentException" }
        } catch (e: IllegalArgumentException) {
            // expected
        }
    }

    @Test
    fun `clamps out-of-range coordinates instead of rejecting them`() {
        val boxes = listOf(floatArrayOf(-0.1f, -0.1f, 1.1f, 1.1f))
        val scores = listOf(0.9f)
        val classes = listOf(0)

        val result = BoxDecoder.decode(boxes, scores, classes)

        assertEquals(1, result.size)
        assertEquals(0f, result.first().box.left)
        assertEquals(0f, result.first().box.top)
        assertEquals(1f, result.first().box.right)
        assertEquals(1f, result.first().box.bottom)
    }
}
