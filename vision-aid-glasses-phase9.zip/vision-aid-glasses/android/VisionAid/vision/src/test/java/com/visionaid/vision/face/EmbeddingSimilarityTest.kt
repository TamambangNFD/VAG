package com.visionaid.vision.face

import com.visionaid.ai.common.ConfidenceLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertNotNull
import org.junit.Test
import kotlin.math.sqrt

class EmbeddingSimilarityTest {

    @Test
    fun `identical vectors have similarity 1`() {
        val v = floatArrayOf(0.5f, 0.5f, 0.5f, 0.5f)
        assertEquals(1.0f, EmbeddingSimilarity.cosineSimilarity(v, v), 0.0001f)
    }

    @Test
    fun `orthogonal vectors have similarity 0`() {
        val a = floatArrayOf(1f, 0f)
        val b = floatArrayOf(0f, 1f)
        assertEquals(0.0f, EmbeddingSimilarity.cosineSimilarity(a, b), 0.0001f)
    }

    @Test
    fun `opposite vectors have similarity -1`() {
        val a = floatArrayOf(1f, 0f)
        val b = floatArrayOf(-1f, 0f)
        assertEquals(-1.0f, EmbeddingSimilarity.cosineSimilarity(a, b), 0.0001f)
    }

    @Test
    fun `zero vector produces similarity 0, not a division error`() {
        val a = floatArrayOf(0f, 0f, 0f)
        val b = floatArrayOf(1f, 2f, 3f)
        assertEquals(0.0f, EmbeddingSimilarity.cosineSimilarity(a, b), 0.0001f)
    }

    @Test
    fun `mismatched lengths throw`() {
        try {
            EmbeddingSimilarity.cosineSimilarity(floatArrayOf(1f, 2f), floatArrayOf(1f))
            assert(false) { "Expected IllegalArgumentException" }
        } catch (e: IllegalArgumentException) {
            // expected
        }
    }

    @Test
    fun `findBestMatch returns null when nothing clears the threshold`() {
        val query = floatArrayOf(1f, 0f, 0f)
        val stored = mapOf("person-1" to floatArrayOf(0f, 1f, 0f)) // orthogonal, similarity 0
        assertNull(EmbeddingSimilarity.findBestMatch(query, stored))
    }

    @Test
    fun `findBestMatch returns null on an empty profile store`() {
        assertNull(EmbeddingSimilarity.findBestMatch(floatArrayOf(1f, 0f), emptyMap()))
    }

    @Test
    fun `findBestMatch returns the closest match above threshold`() {
        val query = floatArrayOf(1f, 0f, 0f)
        val stored = mapOf(
            "far-person" to floatArrayOf(0f, 1f, 0f),      // similarity 0
            "close-person" to floatArrayOf(0.99f, 0.01f, 0f) // similarity ~1, clears threshold
        )
        val match = EmbeddingSimilarity.findBestMatch(query, stored)
        assertNotNull(match)
        assertEquals("close-person", match!!.personId)
    }

    @Test
    fun `confidence scales with similarity strength above threshold`() {
        val query = floatArrayOf(1f, 0f)
        // similarity exactly 1.0 -> HIGH
        val highMatch = EmbeddingSimilarity.findBestMatch(query, mapOf("p1" to floatArrayOf(1f, 0f)))
        assertEquals(ConfidenceLevel.HIGH, highMatch!!.confidence)
    }

    @Test
    fun `threshold constant is a real, sensible value`() {
        assertEquals(0.75f, EmbeddingSimilarity.RECOGNITION_THRESHOLD)
        assert(EmbeddingSimilarity.RECOGNITION_THRESHOLD in 0f..1f)
    }
}
