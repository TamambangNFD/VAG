package com.visionaid.vision.depth

import com.visionaid.ai.depth.DistanceBand
import com.visionaid.ai.detection.BoundingBox
import com.visionaid.ai.detection.DetectedObject
import com.visionaid.ai.detection.ObjectLabel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

/**
 * Safety-critical tests. Every "should be UNKNOWN" case here is a
 * deliberate conservative-behavior assertion, not just a coverage exercise
 * — a regression that makes any of these produce a confident band instead
 * of UNKNOWN would be a real safety regression per Section 0.4.
 *
 * All test cases use a PERSON (reference height 1.7m per
 * CalibrationConfig.DEFAULT_REFERENCE_HEIGHTS) with the formula:
 *   distance_m = referenceHeight_m * normalizedFocalLength / boxHeightNormalized
 * Each case's chosen focal length / box height is computed explicitly in
 * comments so the expected band is traceable, not guessed.
 */
class MonocularSizeBasedDepthEstimatorTest {

    private fun personWithBoxHeight(height: Float) = DetectedObject(
        objectId = "obj-1",
        label = ObjectLabel.PERSON,
        boundingBox = BoundingBox(0.3f, 0.5f - height / 2, 0.5f, 0.5f + height / 2),
        confidenceScore = 0.9f
    )

    @Test
    fun `no calibration means everything is UNKNOWN`() {
        val result = MonocularSizeBasedDepthEstimator.estimate(listOf(personWithBoxHeight(0.5f)), calibration = null)
        assertEquals(DistanceBand.UNKNOWN, result.getValue("obj-1").band)
        assertNotNull(result.getValue("obj-1").reasonIfUnknown)
    }

    @Test
    fun `label with no reference height is UNKNOWN`() {
        val bottle = DetectedObject("obj-2", ObjectLabel.BOTTLE, BoundingBox(0.1f, 0.1f, 0.2f, 0.3f), 0.8f)
        val calibration = CalibrationConfig(normalizedFocalLength = 1.0f)
        val result = MonocularSizeBasedDepthEstimator.estimate(listOf(bottle), calibration)
        assertEquals(DistanceBand.UNKNOWN, result.getValue("obj-2").band)
    }

    @Test
    fun `bounding box too small is UNKNOWN, not FAR`() {
        // A tiny box could plausibly be estimated as "very far" numerically,
        // but this must still be reported as UNKNOWN — the safe behavior —
        // because a box this small is unreliable, not just distant.
        val calibration = CalibrationConfig(normalizedFocalLength = 1.0f, minReliableBoxHeight = 0.02f)
        val result = MonocularSizeBasedDepthEstimator.estimate(listOf(personWithBoxHeight(0.005f)), calibration)
        assertEquals(DistanceBand.UNKNOWN, result.getValue("obj-1").band)
    }

    @Test
    fun `bounding box too large (clipped) is UNKNOWN, not NEAR`() {
        val calibration = CalibrationConfig(normalizedFocalLength = 1.0f, maxReliableBoxHeight = 0.95f)
        val result = MonocularSizeBasedDepthEstimator.estimate(listOf(personWithBoxHeight(0.99f)), calibration)
        assertEquals(DistanceBand.UNKNOWN, result.getValue("obj-1").band)
    }

    @Test
    fun `a clearly near estimate is classified NEAR`() {
        // focal=0.5, boxHeight=0.85 -> distance = 1.7*0.5/0.85 = 1.0m.
        // NEAR's lower margin boundary is 1.5*(1-0.15)=1.275, so 1.0m is
        // well inside confidently-NEAR territory, not near any boundary.
        val calibration = CalibrationConfig(normalizedFocalLength = 0.5f)
        val result = MonocularSizeBasedDepthEstimator.estimate(listOf(personWithBoxHeight(0.85f)), calibration)
        assertEquals(DistanceBand.NEAR, result.getValue("obj-1").band)
    }

    @Test
    fun `a clearly medium estimate is classified MEDIUM`() {
        // focal=1.0, boxHeight=0.85 -> distance = 1.7*1.0/0.85 = 2.0m.
        // MEDIUM's range here is (1.725, 3.4) after margins — 2.0m sits
        // comfortably inside it.
        val calibration = CalibrationConfig(normalizedFocalLength = 1.0f)
        val result = MonocularSizeBasedDepthEstimator.estimate(listOf(personWithBoxHeight(0.85f)), calibration)
        assertEquals(DistanceBand.MEDIUM, result.getValue("obj-1").band)
    }

    @Test
    fun `a clearly far estimate is classified FAR`() {
        // focal=1.0, boxHeight=0.1 -> distance = 1.7*1.0/0.1 = 17.0m, far
        // beyond FAR's lower margin boundary of 4.0*1.15=4.6.
        val calibration = CalibrationConfig(normalizedFocalLength = 1.0f, minReliableBoxHeight = 0.02f)
        val result = MonocularSizeBasedDepthEstimator.estimate(listOf(personWithBoxHeight(0.1f)), calibration)
        assertEquals(DistanceBand.FAR, result.getValue("obj-1").band)
    }

    @Test
    fun `an estimate right at the NEAR-MEDIUM boundary is UNKNOWN, not guessed`() {
        // focal=0.5, boxHeight=0.5667 -> distance = 1.7*0.5/0.5667 = 1.5m,
        // exactly NEAR_MAX_METERS — the ambiguous boundary itself.
        val calibration = CalibrationConfig(normalizedFocalLength = 0.5f)
        val result = MonocularSizeBasedDepthEstimator.estimate(listOf(personWithBoxHeight(0.5667f)), calibration)
        assertEquals(DistanceBand.UNKNOWN, result.getValue("obj-1").band)
    }

    @Test
    fun `boundary margin constant is a real, non-zero conservative buffer`() {
        assertEquals(0.15f, MonocularSizeBasedDepthEstimator.BOUNDARY_MARGIN_FRACTION)
        assert(MonocularSizeBasedDepthEstimator.BOUNDARY_MARGIN_FRACTION > 0f)
    }

    @Test
    fun `empty detection list produces empty output, not an error`() {
        val calibration = CalibrationConfig(normalizedFocalLength = 1.0f)
        val result = MonocularSizeBasedDepthEstimator.estimate(emptyList(), calibration)
        assert(result.isEmpty())
    }
}
