package com.visionaid.vision.detection

import com.visionaid.ai.detection.ObjectLabel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CocoLabelMapTest {

    @Test
    fun `maps known COCO indices to correct ObjectLabel`() {
        assertEquals(ObjectLabel.PERSON, CocoLabelMap.toObjectLabel(0))
        assertEquals(ObjectLabel.BICYCLE, CocoLabelMap.toObjectLabel(1))
        assertEquals(ObjectLabel.CAR, CocoLabelMap.toObjectLabel(2))
        assertEquals(ObjectLabel.BOTTLE, CocoLabelMap.toObjectLabel(39))
        assertEquals(ObjectLabel.TABLE, CocoLabelMap.toObjectLabel(60))
    }

    @Test
    fun `unmapped COCO index falls back to OTHER rather than being dropped`() {
        assertEquals(ObjectLabel.OTHER, CocoLabelMap.toObjectLabel(999))
    }

    @Test
    fun `never claims support for roadmap labels this model cannot produce`() {
        // This is the most important test in this file: it locks in the
        // honesty requirement that STAIRS, POLE, ROAD, SIDEWALK, WALL, and
        // DOOR are never silently mapped from an unrelated COCO class.
        val unsupported = CocoLabelMap.UNSUPPORTED_ROADMAP_LABELS
        assertTrue(unsupported.contains(ObjectLabel.STAIRS))
        assertTrue(unsupported.contains(ObjectLabel.POLE))
        assertTrue(unsupported.contains(ObjectLabel.ROAD))
        assertTrue(unsupported.contains(ObjectLabel.SIDEWALK))
        assertTrue(unsupported.contains(ObjectLabel.WALL))
        assertTrue(unsupported.contains(ObjectLabel.DOOR))

        // And no COCO index (0-89, the full standard set) maps to any of
        // these labels.
        for (i in 0..89) {
            assertTrue(
                "COCO index $i must not map to an unsupported roadmap label",
                CocoLabelMap.toObjectLabel(i) !in unsupported
            )
        }
    }
}
