package com.visionaid.vision.ocr

import org.junit.Assert.assertEquals
import org.junit.Test

class TextOrdererTest {

    private fun line(text: String, top: Float, left: Float) = RawTextLine(text, 0.9f, top, left, top + 0.03f)

    @Test
    fun `orders top-to-bottom for lines on different rows`() {
        val lines = listOf(line("second", 0.3f, 0.1f), line("first", 0.1f, 0.1f))
        val ordered = TextOrderer.order(lines)
        assertEquals(listOf("first", "second"), ordered.map { it.text })
    }

    @Test
    fun `orders left-to-right within the same row`() {
        val lines = listOf(line("world", 0.1f, 0.5f), line("hello", 0.1f, 0.1f))
        val ordered = TextOrderer.order(lines)
        assertEquals(listOf("hello", "world"), ordered.map { it.text })
    }

    @Test
    fun `two-column layout reads correctly (left column first, both rows, then right column)`() {
        // A simplistic two-column-like layout where each row is processed
        // together: row 1 (left, right), row 2 (left, right).
        val lines = listOf(
            line("row1-right", 0.10f, 0.6f),
            line("row1-left", 0.10f, 0.1f),
            line("row2-right", 0.20f, 0.6f),
            line("row2-left", 0.20f, 0.1f)
        )
        val ordered = TextOrderer.order(lines)
        assertEquals(listOf("row1-left", "row1-right", "row2-left", "row2-right"), ordered.map { it.text })
    }

    @Test
    fun `empty input returns empty output`() {
        assertEquals(emptyList<RawTextLine>(), TextOrderer.order(emptyList()))
    }

    @Test
    fun `lines within row tolerance are grouped despite slightly different top values`() {
        val lines = listOf(
            line("b", 0.101f, 0.5f), // within 0.015 tolerance of 0.1
            line("a", 0.100f, 0.1f)
        )
        val ordered = TextOrderer.order(lines)
        assertEquals(listOf("a", "b"), ordered.map { it.text })
    }
}
