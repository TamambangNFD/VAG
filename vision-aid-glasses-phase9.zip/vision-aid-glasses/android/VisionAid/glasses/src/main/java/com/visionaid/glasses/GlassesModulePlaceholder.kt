package com.visionaid.glasses

/**
 * Placeholder establishing the "glasses" module boundary in Phase 1.
 *
 * Purpose: Vendor-abstracted GlassesDevice interface for Vuzix/Rokid integration (Phase 19-20). Depends on core only; no vendor SDK is referenced until Phase 19.
 *
 * INTENTIONALLY EMPTY OF LOGIC. This module exists so that:
 *  1. Its Gradle dependency boundary is fixed early (other modules depend on
 *     this modules public API surface, not its internals).
 *  2. Later phases add real classes here without needing to restructure the
 *     project or touch unrelated modules.
 *
 * Do not add AI models, camera code, or business logic here during Phase 1 --
 * that is explicitly out of scope per the Phase 1 spec in
 * Vision_Aid_Glasses_Master_Roadmap.md.
 */
object GlassesModulePlaceholder {
    const val MODULE_NAME = "glasses"
}
