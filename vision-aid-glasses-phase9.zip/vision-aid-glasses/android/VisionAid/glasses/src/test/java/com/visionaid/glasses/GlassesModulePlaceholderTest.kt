package com.visionaid.glasses

import org.junit.Assert.assertEquals
import org.junit.Test

class GlassesModulePlaceholderTest {
    @Test
    fun `module name is correct`() {
        assertEquals("glasses", GlassesModulePlaceholder.MODULE_NAME)
    }
}
