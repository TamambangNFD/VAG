package com.visionaid.documents

import org.junit.Assert.assertEquals
import org.junit.Test

class DocumentsModulePlaceholderTest {
    @Test
    fun `module name is correct`() {
        assertEquals("documents", DocumentsModulePlaceholder.MODULE_NAME)
    }
}
