package com.visionaid.safety

/**
 * Placeholder establishing the "safety" module boundary in Phase 1.
 *
 * Purpose: Safety-critical obstacle avoidance, traffic safety, and emergency interruption (Phases 5, 16-18). Depends on core, vision, ai. SAFETY-CRITICAL MODULE per Section 0.4 of the roadmap.
 *
 * INTENTIONALLY EMPTY OF LOGIC. This module exists so that:
 *  1. Its Gradle dependency boundary is fixed early (other modules depend on
 *     this modules public API surface, not its internals).
 *  2. Later phases add real classes here without needing to restructure the
 *     project or touch unrelated modules.
 *
 * Do not add AI models, camera code, or business logic here during Phase 1 --
 * that is explicitly out of scope per the Phase 1 spec in
 * Vision_Aid_Glasses_Master_Roadmap.md.
 */
object SafetyModulePlaceholder {
    const val MODULE_NAME = "safety"
}
