package com.visionaid.safety

import org.junit.Assert.assertEquals
import org.junit.Test

class SafetyModulePlaceholderTest {
    @Test
    fun `module name is correct`() {
        assertEquals("safety", SafetyModulePlaceholder.MODULE_NAME)
    }
}
