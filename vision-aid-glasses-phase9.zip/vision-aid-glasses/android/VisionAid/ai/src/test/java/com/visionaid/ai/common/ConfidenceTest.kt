package com.visionaid.ai.common

import org.junit.Assert.assertThrows
import org.junit.Test

class ConfidenceTest {

    @Test
    fun `unknown factory produces UNKNOWN level with null score`() {
        val c = Confidence.unknown()
        assert(c.level == ConfidenceLevel.UNKNOWN)
        assert(c.score == null)
    }

    @Test
    fun `score outside 0-1 range is rejected`() {
        assertThrows(IllegalArgumentException::class.java) {
            Confidence(ConfidenceLevel.HIGH, 1.5f)
        }
    }
}
