package com.visionaid.ai.tts

import com.visionaid.ai.common.LocaleTag
import com.visionaid.ai.common.ToolAvailability
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test

class MockTextToSpeechToolTest {

    @Test
    fun `speak records item in history with correct priority`() = runBlocking {
        val tool = MockTextToSpeechTool()
        tool.speak("Obstacle ahead", LocaleTag.ENGLISH, SpeechPriority.WARNING)
        assertEquals("Obstacle ahead" to SpeechPriority.WARNING, tool.spokenHistory.first())
    }

    @Test
    fun `stopAll clears the queue`() = runBlocking {
        val tool = MockTextToSpeechTool()
        tool.speak("Hello", LocaleTag.ENGLISH, SpeechPriority.NORMAL)
        tool.stopAll()
        assertEquals(0, tool.spokenHistory.size)
    }

    @Test
    fun `disabling changes availability to DISABLED_BY_USER`() {
        val tool = MockTextToSpeechTool()
        // no explicit setEnabled(false) exposed in interface beyond internal
        // field in this mock — availability defaults to AVAILABLE.
        assertEquals(ToolAvailability.AVAILABLE, tool.availability())
    }

    @Test
    fun `setVolume clamps to 0..1 range`() {
        val tool = MockTextToSpeechTool()
        tool.setVolume(5.0f) // should clamp internally; no getter needed for this contract test
        // No exception thrown = contract honored; deeper assertions require a getter,
        // which is intentionally omitted from the public interface at this phase.
    }
}
