package com.visionaid.ai.common

import com.visionaid.ai.detection.BoundingBox
import org.junit.Assert.assertThrows
import org.junit.Test

class BoundingBoxTest {

    @Test
    fun `zero-area box is rejected`() {
        assertThrows(IllegalArgumentException::class.java) {
            BoundingBox(0.5f, 0.5f, 0.5f, 0.5f)
        }
    }

    @Test
    fun `out-of-range coordinate is rejected`() {
        assertThrows(IllegalArgumentException::class.java) {
            BoundingBox(-0.1f, 0f, 0.5f, 0.5f)
        }
    }
}
