package com.visionaid.ai.speech

import com.visionaid.ai.common.LocaleTag
import com.visionaid.ai.common.ToolResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test

class MockSpeechRecognitionToolTest {

    private val tool = MockSpeechRecognitionTool()

    @Test
    fun `transcribes differently per locale, proving locale is explicit not hard-coded`() = runBlocking {
        val english = tool.transcribe(ByteArray(0), LocaleTag.ENGLISH) as ToolResult.Success
        val french = tool.transcribe(ByteArray(0), LocaleTag.FRENCH) as ToolResult.Success

        assertEquals(LocaleTag.ENGLISH, english.data.locale)
        assertEquals(LocaleTag.FRENCH, french.data.locale)
        assert(english.data.transcript != french.data.transcript)
    }
}
