package com.visionaid.ai.tracking

import com.visionaid.ai.detection.BoundingBox
import com.visionaid.ai.detection.DetectedObject
import com.visionaid.ai.detection.ObjectLabel
import com.visionaid.ai.common.ToolResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test

class MockObjectTrackingToolTest {

    private fun sampleObject(id: String) = DetectedObject(
        objectId = id,
        label = ObjectLabel.PERSON,
        boundingBox = BoundingBox(0.1f, 0.1f, 0.5f, 0.5f),
        confidenceScore = 0.8f
    )

    @Test
    fun `same objectId across frames keeps the same trackId`() = runBlocking {
        val tool = MockObjectTrackingTool()
        val first = tool.update(listOf(sampleObject("obj-1")), 1000L) as ToolResult.Success
        val second = tool.update(listOf(sampleObject("obj-1")), 1033L) as ToolResult.Success

        assertEquals(first.data.tracks.first().trackId, second.data.tracks.first().trackId)
    }

    @Test
    fun `framesTracked increments across updates`() = runBlocking {
        val tool = MockObjectTrackingTool()
        tool.update(listOf(sampleObject("obj-1")), 1000L)
        val second = tool.update(listOf(sampleObject("obj-1")), 1033L) as ToolResult.Success

        assertEquals(2, second.data.tracks.first().framesTracked)
    }

    @Test
    fun `reset clears track history`() = runBlocking {
        val tool = MockObjectTrackingTool()
        tool.update(listOf(sampleObject("obj-1")), 1000L)
        tool.reset()
        val afterReset = tool.update(listOf(sampleObject("obj-1")), 2000L) as ToolResult.Success

        assertEquals(1, afterReset.data.tracks.first().framesTracked)
    }
}
