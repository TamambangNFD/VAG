package com.visionaid.ai.safety

import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.detection.BoundingBox
import com.visionaid.ai.detection.DetectedObject
import com.visionaid.ai.detection.ObjectLabel
import com.visionaid.ai.tracking.MovementDirection
import com.visionaid.ai.tracking.TrackedObject
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

/**
 * Safety-critical test: this mock has no real safety pipeline, so it must
 * never report SAFE_CANDIDATE — that would be exactly the false-confidence
 * failure mode Section 0.4 of the roadmap prohibits.
 */
class MockSafetyToolTest {

    private val tool = MockSafetyTool()

    private fun sampleTrack() = TrackedObject(
        trackId = "track-1",
        detectedObject = DetectedObject(
            "obj-1", ObjectLabel.VEHICLE, BoundingBox(0.1f, 0.1f, 0.5f, 0.5f), 0.9f
        ),
        movement = MovementDirection.APPROACHING,
        framesTracked = 5
    )

    @Test
    fun `never reports SAFE_CANDIDATE with no real pipeline behind it`() = runBlocking {
        val result = tool.assess(listOf(sampleTrack()), emptyMap()) as ToolResult.Success
        assertNotEquals(SafetyState.SAFE_CANDIDATE, result.data.state)
        assertEquals(SafetyState.UNKNOWN, result.data.state)
    }

    @Test
    fun `confidence is UNKNOWN, not fabricated`() = runBlocking {
        val result = tool.assess(listOf(sampleTrack()), emptyMap()) as ToolResult.Success
        assertEquals(ConfidenceLevel.UNKNOWN, result.confidence.level)
    }

    @Test
    fun `reason explains the decision traceably`() = runBlocking {
        val result = tool.assess(listOf(sampleTrack()), emptyMap()) as ToolResult.Success
        assertEquals(true, result.data.reason.isNotBlank())
    }
}
