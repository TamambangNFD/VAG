package com.visionaid.ai.navigation

import com.visionaid.ai.common.ToolResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertTrue
import org.junit.Test

class MockNavigationToolTest {

    private val tool = MockNavigationTool()

    @Test
    fun `computeRoute returns at least one step`() = runBlocking {
        val result = tool.computeRoute(0.0, 0.0, "pharmacy") as ToolResult.Success
        assertTrue(result.data.steps.isNotEmpty())
    }

    @Test
    fun `last step direction is a valid TurnDirection`() = runBlocking {
        val result = tool.computeRoute(0.0, 0.0, "pharmacy") as ToolResult.Success
        assertTrue(TurnDirection.entries.contains(result.data.steps.last().direction))
    }
}
