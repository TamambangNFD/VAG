package com.visionaid.ai.currency

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.ToolResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class MockCurrencyRecognitionToolTest {

    private val tool = MockCurrencyRecognitionTool()
    private fun frame() = FrameContext(1L, ByteArray(0), 1000L)

    @Test
    fun `reports XAF currency`() = runBlocking {
        val result = tool.recognizeCurrency(frame()) as ToolResult.Success
        assertEquals(CurrencyCode.XAF, result.data.currency)
    }

    @Test
    fun `denomination is present when image quality is sufficient`() = runBlocking {
        val result = tool.recognizeCurrency(frame()) as ToolResult.Success
        assertNotNull(result.data.denomination)
        assertEquals(true, result.data.imageQualitySufficient)
    }
}
