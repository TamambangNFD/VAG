package com.visionaid.ai.ocr

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.LocaleTag
import com.visionaid.ai.common.ToolResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertTrue
import org.junit.Test

class MockOCRToolTest {

    private val tool = MockOCRTool()

    @Test
    fun `recognizes text differently per locale, proving locale is threaded through`() = runBlocking {
        val englishFrame = FrameContext(1L, ByteArray(0), 1000L, LocaleTag.ENGLISH)
        val frenchFrame = FrameContext(2L, ByteArray(0), 1000L, LocaleTag.FRENCH)

        val englishResult = tool.recognizeText(englishFrame) as ToolResult.Success
        val frenchResult = tool.recognizeText(frenchFrame) as ToolResult.Success

        assertTrue(englishResult.data.textBlocks.first().text != frenchResult.data.textBlocks.first().text)
    }
}
