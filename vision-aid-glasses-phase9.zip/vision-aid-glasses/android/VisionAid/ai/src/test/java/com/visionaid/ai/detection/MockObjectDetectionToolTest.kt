package com.visionaid.ai.detection

import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.ToolResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MockObjectDetectionToolTest {

    private val tool = MockObjectDetectionTool()
    private fun frame() = FrameContext(frameId = 1L, imageData = ByteArray(0), captureTimestampMillis = 1000L)

    @Test
    fun `detect returns success with at least one object`() = runBlocking {
        val result = tool.detect(frame())
        assertTrue(result is ToolResult.Success)
        val success = result as ToolResult.Success
        assertTrue(success.data.objects.isNotEmpty())
    }

    @Test
    fun `detect reports MEDIUM confidence for mock data`() = runBlocking {
        val result = tool.detect(frame()) as ToolResult.Success
        assertEquals(ConfidenceLevel.MEDIUM, result.confidence.level)
    }

    @Test
    fun `bounding boxes are normalized`() = runBlocking {
        val result = tool.detect(frame()) as ToolResult.Success
        result.data.objects.forEach { obj ->
            assertTrue(obj.boundingBox.left in 0f..1f)
            assertTrue(obj.boundingBox.right in 0f..1f)
        }
    }
}
