package com.visionaid.ai.worldmodel

import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.depth.DistanceBand
import com.visionaid.ai.detection.BoundingBox
import com.visionaid.ai.detection.DetectedObject
import com.visionaid.ai.detection.ObjectLabel
import com.visionaid.ai.tracking.MovementDirection
import com.visionaid.ai.tracking.TrackedObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Tests against synthetic scenes (hand-authored combinations of tracked
 * objects + distances), per the phase spec's "Create tests using synthetic
 * scenes" requirement.
 */
class LocalWorldModelTest {

    private fun track(
        id: String,
        label: ObjectLabel,
        centerX: Float,
        movement: MovementDirection = MovementDirection.STATIONARY
    ) = TrackedObject(
        trackId = id,
        detectedObject = DetectedObject(id, label, BoundingBox(centerX - 0.05f, 0.2f, centerX + 0.05f, 0.8f), 0.85f),
        movement = movement,
        framesTracked = 3
    )

    private fun freshModel() = LocalWorldModel()

    @Test
    fun `synthetic scene - pole ahead is classified CENTER and NEAR`() {
        val model = freshModel()
        model.update(
            trackedObjects = listOf(track("pole-1", ObjectLabel.POLE, centerX = 0.5f)),
            distances = mapOf("pole-1" to DistanceBand.NEAR),
            detectionConfidence = ConfidenceLevel.HIGH,
            trackingConfidence = ConfidenceLevel.MEDIUM,
            depthConfidence = ConfidenceLevel.LOW,
            timestampMillis = 1000L
        )

        val obj = model.allObjects().single()
        assertEquals(HorizontalPosition.CENTER, obj.horizontalPosition)
        assertEquals(DistanceBand.NEAR, obj.distanceBand)
        // Weakest-link confidence: LOW is the weakest of HIGH/MEDIUM/LOW.
        assertEquals(ConfidenceLevel.LOW, obj.confidence)
    }

    @Test
    fun `synthetic scene - person left, car right, both classified correctly`() {
        val model = freshModel()
        model.update(
            trackedObjects = listOf(
                track("person-1", ObjectLabel.PERSON, centerX = 0.1f),
                track("car-1", ObjectLabel.CAR, centerX = 0.9f)
            ),
            distances = mapOf("person-1" to DistanceBand.MEDIUM, "car-1" to DistanceBand.FAR),
            detectionConfidence = ConfidenceLevel.HIGH,
            trackingConfidence = ConfidenceLevel.HIGH,
            depthConfidence = ConfidenceLevel.LOW,
            timestampMillis = 1000L
        )

        assertEquals(listOf("person-1"), model.objectsByPosition(HorizontalPosition.LEFT).map { it.trackId })
        assertEquals(listOf("car-1"), model.objectsByPosition(HorizontalPosition.RIGHT).map { it.trackId })
        assertTrue(model.objectsByPosition(HorizontalPosition.CENTER).isEmpty())
    }

    @Test
    fun `nearestObstacle picks the closest known-distance object, ignoring UNKNOWN`() {
        val model = freshModel()
        model.update(
            trackedObjects = listOf(
                track("far-1", ObjectLabel.OTHER, centerX = 0.5f), // FAR
                track("near-1", ObjectLabel.PERSON, centerX = 0.5f), // NEAR
                track("unknown-1", ObjectLabel.BOTTLE, centerX = 0.5f) // UNKNOWN distance
            ),
            distances = mapOf(
                "far-1" to DistanceBand.FAR,
                "near-1" to DistanceBand.NEAR,
                "unknown-1" to DistanceBand.UNKNOWN
            ),
            detectionConfidence = ConfidenceLevel.HIGH,
            trackingConfidence = ConfidenceLevel.HIGH,
            depthConfidence = ConfidenceLevel.LOW,
            timestampMillis = 1000L
        )

        assertEquals("near-1", model.nearestObstacle()?.trackId)
    }

    @Test
    fun `nearestObstacle returns null when every object has UNKNOWN distance`() {
        val model = freshModel()
        model.update(
            trackedObjects = listOf(track("obj-1", ObjectLabel.BOTTLE, centerX = 0.5f)),
            distances = mapOf("obj-1" to DistanceBand.UNKNOWN),
            detectionConfidence = ConfidenceLevel.HIGH,
            trackingConfidence = ConfidenceLevel.HIGH,
            depthConfidence = ConfidenceLevel.UNKNOWN,
            timestampMillis = 1000L
        )

        assertNull(model.nearestObstacle())
    }

    @Test
    fun `movingObjects excludes STATIONARY and UNKNOWN movement`() {
        val model = freshModel()
        model.update(
            trackedObjects = listOf(
                track("stationary-1", ObjectLabel.CHAIR, 0.5f, MovementDirection.STATIONARY),
                track("unknown-move-1", ObjectLabel.BAG, 0.5f, MovementDirection.UNKNOWN),
                track("approaching-1", ObjectLabel.CAR, 0.5f, MovementDirection.APPROACHING),
                track("walking-1", ObjectLabel.PERSON, 0.5f, MovementDirection.LEFT_TO_RIGHT)
            ),
            distances = emptyMap(),
            detectionConfidence = ConfidenceLevel.HIGH,
            trackingConfidence = ConfidenceLevel.HIGH,
            depthConfidence = ConfidenceLevel.UNKNOWN,
            timestampMillis = 1000L
        )

        val movingIds = model.movingObjects().map { it.trackId }.toSet()
        assertEquals(setOf("approaching-1", "walking-1"), movingIds)
    }

    @Test
    fun `objectsWithinDistance MEDIUM includes NEAR and MEDIUM but not FAR or UNKNOWN`() {
        val model = freshModel()
        model.update(
            trackedObjects = listOf(
                track("near-1", ObjectLabel.PERSON, 0.5f),
                track("medium-1", ObjectLabel.CAR, 0.5f),
                track("far-1", ObjectLabel.CAR, 0.5f),
                track("unknown-1", ObjectLabel.BAG, 0.5f)
            ),
            distances = mapOf(
                "near-1" to DistanceBand.NEAR,
                "medium-1" to DistanceBand.MEDIUM,
                "far-1" to DistanceBand.FAR,
                "unknown-1" to DistanceBand.UNKNOWN
            ),
            detectionConfidence = ConfidenceLevel.HIGH,
            trackingConfidence = ConfidenceLevel.HIGH,
            depthConfidence = ConfidenceLevel.LOW,
            timestampMillis = 1000L
        )

        val ids = model.objectsWithinDistance(DistanceBand.MEDIUM).map { it.trackId }.toSet()
        assertEquals(setOf("near-1", "medium-1"), ids)
    }

    @Test
    fun `update replaces the previous frame's snapshot entirely`() {
        val model = freshModel()
        model.update(
            trackedObjects = listOf(track("gone-1", ObjectLabel.PERSON, 0.5f)),
            distances = mapOf("gone-1" to DistanceBand.NEAR),
            detectionConfidence = ConfidenceLevel.HIGH,
            trackingConfidence = ConfidenceLevel.HIGH,
            depthConfidence = ConfidenceLevel.LOW,
            timestampMillis = 1000L
        )
        model.update(
            trackedObjects = listOf(track("new-1", ObjectLabel.CAR, 0.5f)),
            distances = mapOf("new-1" to DistanceBand.FAR),
            detectionConfidence = ConfidenceLevel.HIGH,
            trackingConfidence = ConfidenceLevel.HIGH,
            depthConfidence = ConfidenceLevel.LOW,
            timestampMillis = 1033L
        )

        val ids = model.allObjects().map { it.trackId }
        assertEquals(listOf("new-1"), ids)
    }

    @Test
    fun `clear removes all objects`() {
        val model = freshModel()
        model.update(
            trackedObjects = listOf(track("obj-1", ObjectLabel.PERSON, 0.5f)),
            distances = mapOf("obj-1" to DistanceBand.NEAR),
            detectionConfidence = ConfidenceLevel.HIGH,
            trackingConfidence = ConfidenceLevel.HIGH,
            depthConfidence = ConfidenceLevel.LOW,
            timestampMillis = 1000L
        )
        model.clear()
        assertTrue(model.allObjects().isEmpty())
    }

    @Test
    fun `an object missing from the distances map defaults to UNKNOWN, not a crash`() {
        val model = freshModel()
        model.update(
            trackedObjects = listOf(track("no-distance-1", ObjectLabel.PERSON, 0.5f)),
            distances = emptyMap(),
            detectionConfidence = ConfidenceLevel.HIGH,
            trackingConfidence = ConfidenceLevel.HIGH,
            depthConfidence = ConfidenceLevel.UNKNOWN,
            timestampMillis = 1000L
        )
        assertEquals(DistanceBand.UNKNOWN, model.allObjects().single().distanceBand)
    }
}
