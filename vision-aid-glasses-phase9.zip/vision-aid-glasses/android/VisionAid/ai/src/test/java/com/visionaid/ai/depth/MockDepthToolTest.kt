package com.visionaid.ai.depth

import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.detection.BoundingBox
import com.visionaid.ai.detection.DetectedObject
import com.visionaid.ai.detection.ObjectLabel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Safety-critical test: explicitly asserts the mock NEVER returns a
 * confident distance band, since it has no real depth logic behind it.
 */
class MockDepthToolTest {

    private val tool = MockDepthTool()
    private fun frame() = FrameContext(frameId = 1L, imageData = ByteArray(0), captureTimestampMillis = 1000L)
    private fun person(id: String) = DetectedObject(id, ObjectLabel.PERSON, BoundingBox(0.1f, 0.1f, 0.3f, 0.6f), 0.8f)

    @Test
    fun `always returns UNKNOWN for every detected object`() = runBlocking {
        val objects = listOf(person("obj-1"), person("obj-2"))
        val result = tool.estimateDistance(frame(), objects) as ToolResult.Success
        result.data.distances.values.forEach {
            assertEquals(DistanceBand.UNKNOWN, it)
        }
    }

    @Test
    fun `confidence is UNKNOWN, never a fabricated confident value`() = runBlocking {
        val result = tool.estimateDistance(frame(), listOf(person("obj-1"))) as ToolResult.Success
        assertEquals(ConfidenceLevel.UNKNOWN, result.confidence.level)
    }

    @Test
    fun `distances map contains an entry for every detected object`() = runBlocking {
        val objects = listOf(person("obj-1"), person("obj-2"), person("obj-3"))
        val result = tool.estimateDistance(frame(), objects) as ToolResult.Success
        assertTrue(result.data.distances.keys.containsAll(objects.map { it.objectId }))
    }
}
