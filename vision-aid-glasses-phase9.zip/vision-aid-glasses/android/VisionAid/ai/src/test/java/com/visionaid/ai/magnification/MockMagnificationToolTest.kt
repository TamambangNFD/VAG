package com.visionaid.ai.magnification

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.ToolResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class MockMagnificationToolTest {

    private fun frame() = FrameContext(1L, byteArrayOf(1, 2, 3), 1000L)

    @Test
    fun `always reports PHONE_TEST_MODE, never claims glasses display`() = runBlocking {
        val tool = MockMagnificationTool()
        val result = tool.magnify(frame(), MagnificationRequest(ZoomLevel.X4)) as ToolResult.Success
        assertEquals(DisplayTarget.PHONE_TEST_MODE, result.data.outputTarget)
    }

    @Test
    fun `applied zoom level matches the request`() = runBlocking {
        val tool = MockMagnificationTool()
        val result = tool.magnify(frame(), MagnificationRequest(ZoomLevel.X8)) as ToolResult.Success
        assertEquals(ZoomLevel.X8, result.data.appliedZoomLevel)
    }

    @Test
    fun `brightness and contrast adjustments clamp to -1 and 1`() = runBlocking {
        val tool = MockMagnificationTool()
        tool.setBrightnessAdjustment(5f)
        tool.setContrastAdjustment(-5f)
        val result = tool.magnify(frame(), MagnificationRequest(ZoomLevel.X2)) as ToolResult.Success
        assertEquals("1.0", result.metadata["brightnessDelta"])
        assertEquals("-1.0", result.metadata["contrastDelta"])
    }
}
