package com.visionaid.ai.document

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.ToolResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MockDocumentToolTest {

    private fun frame() = FrameContext(1L, ByteArray(0), 1000L)

    @Test
    fun `loadDocument resets to first paragraph`() = runBlocking {
        val tool = MockDocumentTool()
        val result = tool.loadDocument(frame()) as ToolResult.Success
        assertEquals(0, result.data.currentIndex)
    }

    @Test
    fun `readNext advances index and readPrevious goes back`() = runBlocking {
        val tool = MockDocumentTool()
        tool.loadDocument(frame())
        val next = tool.readNext() as ToolResult.Success
        assertEquals(1, next.data.index)

        val prev = tool.readPrevious() as ToolResult.Success
        assertEquals(0, prev.data.index)
    }

    @Test
    fun `readNext past the last paragraph fails instead of wrapping`() = runBlocking {
        val tool = MockDocumentTool()
        tool.loadDocument(frame())
        tool.readNext() // now at last paragraph (index 1 of 2)
        val result = tool.readNext()
        assertTrue(result is ToolResult.Failure)
    }

    @Test
    fun `readAll returns every paragraph`() = runBlocking {
        val tool = MockDocumentTool()
        tool.loadDocument(frame())
        val all = tool.readAll() as ToolResult.Success
        assertEquals(2, all.data.paragraphs.size)
    }
}
