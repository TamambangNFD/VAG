package com.visionaid.ai.depth

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.detection.DetectedObject

/**
 * Deterministic mock. Always reports UNKNOWN for every object, by design —
 * this is a safety-critical tool and the safe default for an unimplemented
 * mock is UNKNOWN, never a fabricated NEAR/MEDIUM/FAR value. Phase 5's real
 * implementation lives in the `vision` module
 * (`RealDepthTool`/`MonocularSizeBasedDepthEstimator`); this mock remains
 * for tests elsewhere that need a DepthTool without pulling in real
 * calibration/estimation logic.
 */
class MockDepthTool : DepthTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun estimateDistance(
        frame: FrameContext,
        detectedObjects: List<DetectedObject>
    ): ToolResult<DepthOutput> {
        val distances = detectedObjects.associate { it.objectId to DistanceBand.UNKNOWN }
        return ToolResult.Success(
            data = DepthOutput(distances = distances),
            confidence = Confidence.unknown(),
            timestampMillis = frame.captureTimestampMillis
        )
    }
}
