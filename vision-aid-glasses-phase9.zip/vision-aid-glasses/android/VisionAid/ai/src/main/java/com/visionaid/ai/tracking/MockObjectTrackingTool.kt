package com.visionaid.ai.tracking

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.detection.DetectedObject

/**
 * Deterministic mock: assigns a stable track ID per unique objectId seen so
 * far and always reports STATIONARY movement. Real association logic
 * (Phase 4, e.g. ByteTrack) replaces this.
 */
class MockObjectTrackingTool : ObjectTrackingTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    private val knownTrackIds = mutableMapOf<String, String>()
    private val frameCounts = mutableMapOf<String, Int>()

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun update(
        detections: List<DetectedObject>,
        frameTimestampMillis: Long
    ): ToolResult<TrackingOutput> {
        val tracks = detections.map { detection ->
            val trackId = knownTrackIds.getOrPut(detection.objectId) {
                "track-${knownTrackIds.size + 1}"
            }
            val count = (frameCounts[trackId] ?: 0) + 1
            frameCounts[trackId] = count

            TrackedObject(
                trackId = trackId,
                detectedObject = detection,
                movement = MovementDirection.STATIONARY,
                framesTracked = count
            )
        }
        return ToolResult.Success(
            data = TrackingOutput(tracks = tracks),
            confidence = Confidence.of(ConfidenceLevel.MEDIUM),
            timestampMillis = frameTimestampMillis
        )
    }

    override fun reset() {
        knownTrackIds.clear()
        frameCounts.clear()
    }
}
