package com.visionaid.ai.detection

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Detects and classifies objects in a single camera frame.
 *
 * Input contract: a single [FrameContext] (one camera frame).
 * Output contract: [ToolResult] wrapping a [DetectionOutput] — zero or more
 * [DetectedObject]s, each independently confidence-scored. An empty list is
 * a valid, successful result ("no objects of interest found"), not a
 * failure.
 *
 * Offline capability: OFFLINE_ONLY. Object detection must never depend on
 * network access (Phase 3 implements this with an on-device model).
 */
interface ObjectDetectionTool {

    val operationMode: OperationMode // always OFFLINE_ONLY for this tool

    fun availability(): ToolAvailability

    suspend fun detect(frame: FrameContext): ToolResult<DetectionOutput>
}

data class DetectionOutput(
    val objects: List<DetectedObject>,
    val frameId: Long
)

data class DetectedObject(
    val objectId: String,
    val label: ObjectLabel,
    val boundingBox: BoundingBox,
    val confidenceScore: Float
)

/**
 * Closed set matching the roadmap's Phase 3 initial object list. Using an
 * enum (with an OTHER escape hatch) rather than a raw String label keeps
 * downstream consumers (WorldModel, Safety) from having to string-match.
 */
enum class ObjectLabel {
    PERSON, CAR, MOTORCYCLE, BICYCLE, CHAIR, TABLE, DOOR, STAIRS,
    POLE, ROAD, SIDEWALK, BAG, BOTTLE, WALL, VEHICLE, OTHER
}

/** Normalized (0.0-1.0) bounding box coordinates, independent of frame resolution. */
data class BoundingBox(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    init {
        require(left in 0f..1f && top in 0f..1f && right in 0f..1f && bottom in 0f..1f) {
            "BoundingBox coordinates must be normalized to 0.0..1.0"
        }
        require(left < right && top < bottom) { "BoundingBox must have positive area" }
    }
}
