package com.visionaid.ai.document

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Higher-level document reading built on top of OCRTool: adds page/paragraph
 * structure and stateful "read next/previous" navigation, per roadmap
 * Phase 8 commands ("Read this", "Read next", "Read previous", "Read all").
 *
 * Input contract: a [FrameContext] for [loadDocument]; no input for
 * navigation calls, which operate on the currently loaded document.
 * Output contract: [DocumentOutput] with ordered [Paragraph]s.
 *
 * Offline capability: OFFLINE_ONLY.
 */
interface DocumentTool {

    val operationMode: OperationMode

    fun availability(): ToolAvailability

    suspend fun loadDocument(frame: FrameContext): ToolResult<DocumentOutput>

    suspend fun readNext(): ToolResult<Paragraph>

    suspend fun readPrevious(): ToolResult<Paragraph>

    suspend fun readAll(): ToolResult<DocumentOutput>
}

data class DocumentOutput(
    val paragraphs: List<Paragraph>,
    val currentIndex: Int
)

data class Paragraph(
    val text: String,
    val index: Int
)
