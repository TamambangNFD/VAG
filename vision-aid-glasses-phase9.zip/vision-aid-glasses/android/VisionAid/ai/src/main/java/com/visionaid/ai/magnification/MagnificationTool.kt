package com.visionaid.ai.magnification

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.detection.BoundingBox

/**
 * Low Vision Mode's digital magnification pipeline: camera frame -> crop
 * (region of interest) -> enhancement -> scaling -> display.
 *
 * IMPORTANT, per the roadmap's explicit instruction: digital zoom cannot
 * recover detail the camera sensor did not capture. This tool enlarges and
 * enhances contrast/brightness of the existing pixel data — it does not
 * "sharpen" or hallucinate detail. Implementations must not claim otherwise
 * in any user-facing text.
 *
 * Output target is abstracted from any specific glasses SDK — see
 * [MagnifiedOutput.outputTarget] and `vision/magnification/DisplayHardwareProfile`
 * for why this currently always resolves to [DisplayTarget.PHONE_TEST_MODE]
 * (glasses hardware/display API is still TBD — Phase 19).
 *
 * Offline capability: OFFLINE_ONLY — pure on-device image processing, no
 * model, no network.
 */
interface MagnificationTool {

    val operationMode: OperationMode

    fun availability(): ToolAvailability

    suspend fun magnify(frame: FrameContext, request: MagnificationRequest): ToolResult<MagnifiedOutput>

    fun setBrightnessAdjustment(delta: Float)

    fun setContrastAdjustment(delta: Float)
}

enum class ZoomLevel(val factor: Int) { X2(2), X4(4), X8(8) }

/**
 * @param regionOfInterest a normalized [BoundingBox] whose center point is
 *   used as the zoom target. Null means center of frame.
 */
data class MagnificationRequest(
    val zoomLevel: ZoomLevel,
    val regionOfInterest: BoundingBox? = null,
    val textFocusedMode: Boolean = false
)

data class MagnifiedOutput(
    val imageData: ByteArray,
    val appliedZoomLevel: ZoomLevel,
    val outputTarget: DisplayTarget
)

enum class DisplayTarget { GLASSES_DISPLAY, PHONE_TEST_MODE }
