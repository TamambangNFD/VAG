package com.visionaid.ai.common

/**
 * Declares how a tool relates to network connectivity. Every tool interface
 * exposes its [OperationMode] so the future Agent (Phase 13) and Network
 * Capability Manager (Phase 22) can reason about what remains available
 * offline. Per the roadmap, the majority of tools must be OFFLINE_ONLY or
 * OFFLINE_WITH_ONLINE_ENHANCEMENT — ONLINE_ONLY is reserved for genuinely
 * optional Phase 22+ enhancements and must never be required for a core
 * assistive function.
 */
enum class OperationMode {
    OFFLINE_ONLY,
    OFFLINE_WITH_ONLINE_ENHANCEMENT,
    ONLINE_ONLY
}
