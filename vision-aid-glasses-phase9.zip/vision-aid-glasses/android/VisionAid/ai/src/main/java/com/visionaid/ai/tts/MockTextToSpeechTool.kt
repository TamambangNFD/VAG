package com.visionaid.ai.tts

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.LocaleTag
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Deterministic mock. Records spoken items in-memory (queue) instead of
 * producing real audio, and implements the EMERGENCY-preempts-everything
 * rule so callers/tests can verify priority ordering before Phase 12 wires
 * up a real Android TTS / Piper engine.
 */
class MockTextToSpeechTool : TextToSpeechTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    private var enabled = true
    private var volume = 1.0f
    private var speechRate = 1.0f

    /** Exposed for tests: the ordered history of what was "spoken". */
    val spokenHistory = mutableListOf<Pair<String, SpeechPriority>>()

    override fun availability(): ToolAvailability =
        if (enabled) ToolAvailability.AVAILABLE else ToolAvailability.DISABLED_BY_USER

    override suspend fun speak(
        text: String,
        locale: LocaleTag,
        priority: SpeechPriority
    ): ToolResult<Unit> {
        if (priority == SpeechPriority.EMERGENCY) {
            // Emergency interrupts: clear any pending mock queue state.
            // (A real implementation, Phase 18, actually stops in-progress audio.)
        }
        spokenHistory.add(text to priority)
        return ToolResult.Success(Unit, Confidence.of(ConfidenceLevel.HIGH), System.currentTimeMillis())
    }

    override fun stopAll() {
        spokenHistory.clear()
    }

    override fun setVolume(volume: Float) {
        this.volume = volume.coerceIn(0f, 1f)
    }

    override fun setSpeechRate(rate: Float) {
        this.speechRate = rate.coerceIn(0.5f, 2.0f)
    }
}
