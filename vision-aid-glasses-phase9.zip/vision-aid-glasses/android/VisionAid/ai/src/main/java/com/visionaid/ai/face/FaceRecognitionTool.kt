package com.visionaid.ai.face

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Local, offline face detection/enrollment/recognition.
 *
 * Input contract: a [FrameContext] for [recognize]; a [FrameContext], a
 * person name, and explicit consent confirmation for [enroll].
 * Output contract: [RecognitionOutput] — zero or more [RecognizedFace]
 * results. A face below the confidence threshold is reported as
 * [RecognizedFace.personId] == null with confidence LOW/UNKNOWN, never as a
 * guessed identity (roadmap Phase 7: "never claim identity when confidence
 * is below the configured threshold").
 *
 * PHASE 7 INTERFACE CHANGE: [enroll] now takes an explicit
 * [consentConfirmed] parameter rather than relying on a doc-comment promise
 * that the caller captured consent beforehand. A structural parameter can
 * be enforced in code (every implementation must reject enrollment when
 * false); a comment cannot. This is a deliberate strengthening of the
 * biometric-data privacy requirement, not a cosmetic change — implementations
 * MUST return a [com.visionaid.ai.common.ToolError.InvalidInput] failure
 * when [consentConfirmed] is false, never silently proceeding.
 *
 * Privacy: face embeddings/images are never uploaded — see
 * PRIVACY.md at the repo root for the full data-handling policy, and
 * MODEL_REGISTRY.md for why no face-embedding/identification model has
 * been integrated yet (a documented dataset-provenance gap, not an
 * oversight).
 *
 * Offline capability: OFFLINE_ONLY. Face data is never uploaded.
 */
interface FaceRecognitionTool {

    val operationMode: OperationMode

    fun availability(): ToolAvailability

    suspend fun recognize(frame: FrameContext): ToolResult<RecognitionOutput>

    suspend fun enroll(
        frame: FrameContext,
        personName: String,
        consentConfirmed: Boolean
    ): ToolResult<EnrollmentOutput>

    suspend fun rename(personId: String, newName: String): ToolResult<Unit>

    suspend fun remove(personId: String): ToolResult<Unit>

    fun setEnabled(enabled: Boolean)
}

data class RecognitionOutput(
    val faces: List<RecognizedFace>
)

data class RecognizedFace(
    /** Null when confidence is below the recognition threshold — an unknown face. */
    val personId: String?,
    val personName: String?,
    val boundingBoxLeft: Float,
    val boundingBoxTop: Float,
    val boundingBoxRight: Float,
    val boundingBoxBottom: Float
)

data class EnrollmentOutput(
    val personId: String,
    val personName: String
)
