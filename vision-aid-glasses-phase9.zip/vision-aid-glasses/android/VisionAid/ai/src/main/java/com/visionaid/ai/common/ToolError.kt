package com.visionaid.ai.common

/**
 * Structured failure reasons for a single tool invocation. Distinct from
 * [ToolAvailability], which describes the tool's overall state — a tool can
 * be AVAILABLE and still fail a specific request (e.g. malformed input).
 *
 * Tools never throw for ordinary "nothing found" or "low confidence"
 * outcomes — those are successful results with UNKNOWN/LOW confidence, not
 * errors. Reserve [ToolError] for genuine failures.
 */
sealed class ToolError {
    data object NoInputProvided : ToolError()
    data object ModelNotLoaded : ToolError()
    data object HardwareUnavailable : ToolError()
    data object Timeout : ToolError()
    data class InvalidInput(val reason: String) : ToolError()
    data class InternalError(val message: String, val cause: Throwable? = null) : ToolError()
}
