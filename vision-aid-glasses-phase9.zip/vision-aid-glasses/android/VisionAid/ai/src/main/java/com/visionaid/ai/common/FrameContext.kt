package com.visionaid.ai.common

/**
 * Shared input envelope for any tool that operates on a camera frame.
 * Tools that don't need a frame (e.g. NavigationTool) do not use this type.
 *
 * [imageData] is intentionally opaque (ByteArray) at this phase — Phase 3
 * onward defines the actual pixel format/encoding once a real model is
 * selected. Do not assume a specific format here.
 */
data class FrameContext(
    val frameId: Long,
    val imageData: ByteArray,
    val captureTimestampMillis: Long,
    val locale: LocaleTag = LocaleTag.ENGLISH
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is FrameContext) return false
        return frameId == other.frameId &&
            imageData.contentEquals(other.imageData) &&
            captureTimestampMillis == other.captureTimestampMillis &&
            locale == other.locale
    }

    override fun hashCode(): Int {
        var result = frameId.hashCode()
        result = 31 * result + imageData.contentHashCode()
        result = 31 * result + captureTimestampMillis.hashCode()
        result = 31 * result + locale.hashCode()
        return result
    }
}

/**
 * Locale is always an explicit parameter (Section 0.5 of the roadmap) —
 * never hard-coded into a tool. Mirrors core's SupportedLanguage but kept
 * local to the ai module to avoid a hard dependency direction from core
 * back into ai; the two are kept in sync manually until a shared module is
 * justified.
 */
enum class LocaleTag(val bcp47Tag: String) {
    ENGLISH("en"),
    FRENCH("fr")
}
