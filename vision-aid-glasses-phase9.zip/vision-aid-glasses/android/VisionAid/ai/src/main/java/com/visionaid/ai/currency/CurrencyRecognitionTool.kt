package com.visionaid.ai.currency

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Identifies banknote/coin denomination. Initial target: Cameroon CFA franc
 * (XAF), per roadmap Phase 10 and Section 0.5. Designed so additional
 * currencies can be added without changing this interface.
 *
 * Input contract: a [FrameContext].
 * Output contract: [CurrencyOutput] — a [Denomination] or, when confidence
 * is insufficient or the image quality is too poor to judge, an explicit
 * unknown result. A low-confidence result must never be reported as
 * certain (roadmap: "Never state a low-confidence result as certain").
 *
 * Offline capability: OFFLINE_ONLY.
 */
interface CurrencyRecognitionTool {

    val operationMode: OperationMode

    fun availability(): ToolAvailability

    suspend fun recognizeCurrency(frame: FrameContext): ToolResult<CurrencyOutput>
}

data class CurrencyOutput(
    val denomination: Denomination?,
    val currency: CurrencyCode,
    val imageQualitySufficient: Boolean
)

enum class CurrencyCode { XAF /* Cameroon CFA franc */ }

data class Denomination(
    val currency: CurrencyCode,
    val value: Int,
    val isCoin: Boolean
)
