package com.visionaid.ai.navigation

import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * GPS/map-based routing. Does not take a camera frame — operates on
 * coordinates.
 *
 * Input contract: current position + destination (free-text query, resolved
 * internally in later phases).
 * Output contract: [RouteOutput] with turn-by-turn [RouteStep]s, or a
 * failure if no route can be computed offline.
 *
 * Offline capability: OFFLINE_WITH_ONLINE_ENHANCEMENT — basic routing must
 * work with offline map data (roadmap Phase 15); live traffic-aware routing
 * is an optional Phase 22+ enhancement layered on top, never a dependency.
 */
interface NavigationTool {

    val operationMode: OperationMode

    fun availability(): ToolAvailability

    suspend fun computeRoute(
        currentLatitude: Double,
        currentLongitude: Double,
        destinationQuery: String
    ): ToolResult<RouteOutput>
}

data class RouteOutput(
    val steps: List<RouteStep>,
    val totalDistanceMeters: Double
)

data class RouteStep(
    val instruction: String,
    val distanceMeters: Double,
    val direction: TurnDirection
)

enum class TurnDirection { STRAIGHT, LEFT, RIGHT, ARRIVED }
