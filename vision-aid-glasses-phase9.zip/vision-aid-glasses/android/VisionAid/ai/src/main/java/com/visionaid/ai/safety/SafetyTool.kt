package com.visionaid.ai.safety

import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.depth.DistanceBand
import com.visionaid.ai.tracking.TrackedObject

/**
 * SAFETY-CRITICAL (roadmap Section 0.4). Placeholder contract for the
 * obstacle-avoidance / traffic-safety decision layer that Phases 16-17 will
 * implement in full. Defined now so the Agent (Phase 13) and Situation
 * Engine (Phase 24) can be built against a stable interface.
 *
 * A general-purpose LLM/VLM must NEVER be the sole implementation behind
 * this interface. When uncertain, implementations must return
 * [SafetyState.UNKNOWN] or [SafetyState.CAUTION] — never [SafetyState.SAFE].
 *
 * Input contract: currently tracked objects plus their distance bands.
 * Output contract: a single, explainable [SafetyOutput] with a [reason]
 * string tracing the decision back to specific inputs (roadmap Phase 17:
 * "Every decision must include... reason for the state").
 *
 * Offline capability: OFFLINE_ONLY. This is non-negotiable for a
 * safety-critical function.
 */
interface SafetyTool {

    val operationMode: OperationMode // must be OFFLINE_ONLY

    fun availability(): ToolAvailability

    suspend fun assess(
        trackedObjects: List<TrackedObject>,
        distances: Map<String, DistanceBand>
    ): ToolResult<SafetyOutput>
}

data class SafetyOutput(
    val state: SafetyState,
    val reason: String,
    val relevantObjectIds: List<String>
)

/**
 * Mirrors the roadmap Phase 17 state machine. Deliberately has no
 * "definitely safe" value with full certainty — SAFE_CANDIDATE is the
 * strongest positive state, reflecting that the system never guarantees
 * safety (Section 12 of PRODUCT_SPEC.md).
 */
enum class SafetyState {
    SAFE_CANDIDATE, CAUTION, DANGER, STOP, UNKNOWN
}
