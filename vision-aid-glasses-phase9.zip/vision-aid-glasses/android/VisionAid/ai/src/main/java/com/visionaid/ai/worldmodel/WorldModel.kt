package com.visionaid.ai.worldmodel

import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.depth.DistanceBand
import com.visionaid.ai.tracking.TrackedObject

/**
 * Local, real-time representation of the user's immediate surroundings,
 * combining object detection, tracking, and depth into one queryable model
 * — per roadmap Phase 6. Deliberately a plain deterministic data structure,
 * not an AI model: "Prioritize deterministic, explainable data structures
 * over complex AI" is an explicit phase requirement.
 *
 * Does NOT generate natural-language responses (that's the Agent, Phase 13)
 * and does NOT make safety decisions (that's Phases 16-17) — this is purely
 * "what do we currently believe is out there," queryable in a few
 * structured ways.
 */
interface WorldModel {

    /**
     * Feeds one frame's combined perception results into the model,
     * replacing the previous frame's snapshot. Confidence levels are the
     * ones already computed by the contributing tools' [com.visionaid.ai.common.ToolResult]s —
     * WorldModel does not re-derive confidence, it combines what it's given
     * conservatively (weakest signal wins).
     */
    fun update(
        trackedObjects: List<TrackedObject>,
        distances: Map<String, DistanceBand>,
        detectionConfidence: ConfidenceLevel,
        trackingConfidence: ConfidenceLevel,
        depthConfidence: ConfidenceLevel,
        timestampMillis: Long
    )

    /** All objects currently known to the model, from the most recent [update]. */
    fun allObjects(): List<WorldObject>

    /**
     * The single closest known obstacle, if any. Only considers objects
     * with a non-UNKNOWN [DistanceBand] — an object at an unknown distance
     * can never be claimed to be "nearest," per the conservative design
     * principle carried over from Phase 5. Among tied bands (e.g. two NEAR
     * objects), the choice is a stable but otherwise arbitrary tie-break,
     * since no finer-grained distance exists at this phase — documented,
     * not hidden.
     */
    fun nearestObstacle(): WorldObject?

    /** Objects whose horizontal position is CENTER — i.e. roughly in the user's walking path. */
    fun objectsInPath(): List<WorldObject>

    fun objectsByPosition(position: HorizontalPosition): List<WorldObject>

    /** Objects whose movement is anything other than STATIONARY or UNKNOWN. */
    fun movingObjects(): List<WorldObject>

    /**
     * Objects at or nearer than [maxBand] (NEAR < MEDIUM < FAR). Objects at
     * UNKNOWN distance are never included — we cannot confirm they're
     * within any specific range.
     */
    fun objectsWithinDistance(maxBand: DistanceBand): List<WorldObject>

    /** Clears all state, e.g. on camera restart or mode change. */
    fun clear()
}
