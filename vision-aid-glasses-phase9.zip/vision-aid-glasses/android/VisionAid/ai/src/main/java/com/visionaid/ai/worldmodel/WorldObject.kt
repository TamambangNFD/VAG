package com.visionaid.ai.worldmodel

import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.depth.DistanceBand
import com.visionaid.ai.detection.DetectedObject
import com.visionaid.ai.tracking.MovementDirection

/**
 * A single object as currently understood by the [WorldModel]: detection +
 * tracking + depth combined into one queryable record. This is the roadmap
 * Phase 6 example structure ("Pole, distance: 1.1m, position: center,
 * movement: stationary, confidence: high") made concrete.
 */
data class WorldObject(
    val trackId: String,
    val detectedObject: DetectedObject,
    val distanceBand: DistanceBand,
    val movement: MovementDirection,
    val horizontalPosition: HorizontalPosition,
    /**
     * Weakest-link confidence across detection, tracking, and depth for
     * this object — deliberately conservative: the combined record is only
     * as trustworthy as its least confident contributing signal.
     */
    val confidence: ConfidenceLevel,
    val lastUpdatedTimestampMillis: Long,
    val framesTracked: Int
)

/**
 * Coarse horizontal position of an object's bounding-box center within the
 * frame. Thresholds are intentionally simple (thirds of the frame) —
 * exact ergonomics (how wide "center"/the walking path actually is) belong
 * to Phase 16 (Obstacle Avoidance) tuning, not this phase.
 */
enum class HorizontalPosition { LEFT, CENTER, RIGHT }
