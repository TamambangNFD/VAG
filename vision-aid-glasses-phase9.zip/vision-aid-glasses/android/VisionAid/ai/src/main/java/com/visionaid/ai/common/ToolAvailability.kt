package com.visionaid.ai.common

/**
 * Reports whether a tool is currently able to do its job at all, independent
 * of any single request's result. Callers (the future Agent, Phase 13) must
 * check this before invoking a tool and communicate a graceful fallback
 * message rather than a raw error when a tool is unavailable.
 */
enum class ToolAvailability {
    AVAILABLE,
    UNAVAILABLE_HARDWARE_MISSING,
    UNAVAILABLE_MODEL_NOT_LOADED,
    UNAVAILABLE_PERMISSION_DENIED,
    DISABLED_BY_USER,
    ERROR
}
