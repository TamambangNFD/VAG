package com.visionaid.ai.speech

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.LocaleTag
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Deterministic mock. Returns a fixed canned command per locale, ignoring
 * the actual audio bytes, so the Agent's command-routing logic (Phase 13)
 * can be developed before Phase 11 adds a real offline ASR engine.
 */
class MockSpeechRecognitionTool : SpeechRecognitionTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun transcribe(
        audioData: ByteArray,
        locale: LocaleTag
    ): ToolResult<SpeechRecognitionOutput> {
        val transcript = when (locale) {
            LocaleTag.FRENCH -> "Qu'est-ce qu'il y a devant moi ?"
            LocaleTag.ENGLISH -> "What is in front of me?"
        }
        return ToolResult.Success(
            data = SpeechRecognitionOutput(transcript = transcript, locale = locale),
            confidence = Confidence.of(ConfidenceLevel.HIGH, 0.95f),
            timestampMillis = System.currentTimeMillis()
        )
    }
}
