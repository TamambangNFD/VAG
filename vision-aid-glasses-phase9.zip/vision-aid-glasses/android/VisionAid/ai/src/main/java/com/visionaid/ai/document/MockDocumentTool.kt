package com.visionaid.ai.document

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolError
import com.visionaid.ai.common.ToolResult

/**
 * Deterministic mock with two canned paragraphs and simple stateful
 * next/previous navigation, so the Agent's "Read next"/"Read previous"
 * commands can be developed before Phase 8 adds real document detection,
 * perspective correction, and OCR.
 */
class MockDocumentTool : DocumentTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    private val paragraphs = listOf(
        Paragraph("This is the first mock paragraph of the document.", 0),
        Paragraph("This is the second mock paragraph of the document.", 1)
    )
    private var currentIndex = 0

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun loadDocument(frame: FrameContext): ToolResult<DocumentOutput> {
        currentIndex = 0
        return ToolResult.Success(
            data = DocumentOutput(paragraphs = paragraphs, currentIndex = currentIndex),
            confidence = Confidence.of(ConfidenceLevel.HIGH),
            timestampMillis = frame.captureTimestampMillis
        )
    }

    override suspend fun readNext(): ToolResult<Paragraph> {
        if (currentIndex >= paragraphs.lastIndex) {
            return ToolResult.Failure(ToolError.InvalidInput("No next paragraph"), System.currentTimeMillis())
        }
        currentIndex++
        return ToolResult.Success(paragraphs[currentIndex], Confidence.of(ConfidenceLevel.HIGH), System.currentTimeMillis())
    }

    override suspend fun readPrevious(): ToolResult<Paragraph> {
        if (currentIndex <= 0) {
            return ToolResult.Failure(ToolError.InvalidInput("No previous paragraph"), System.currentTimeMillis())
        }
        currentIndex--
        return ToolResult.Success(paragraphs[currentIndex], Confidence.of(ConfidenceLevel.HIGH), System.currentTimeMillis())
    }

    override suspend fun readAll(): ToolResult<DocumentOutput> {
        return ToolResult.Success(
            data = DocumentOutput(paragraphs = paragraphs, currentIndex = currentIndex),
            confidence = Confidence.of(ConfidenceLevel.HIGH),
            timestampMillis = System.currentTimeMillis()
        )
    }
}
