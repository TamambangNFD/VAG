package com.visionaid.ai.ocr

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Extracts text from a camera frame. Lower-level than DocumentTool — OCRTool
 * returns raw recognized text; DocumentTool (below) adds structure (pages,
 * paragraphs, "read next/previous").
 *
 * Input contract: a [FrameContext].
 * Output contract: [OcrOutput] with recognized text blocks, each carrying
 * its own confidence. An empty block list is a valid result ("no text
 * found").
 *
 * Offline capability: OFFLINE_ONLY. Must support French and English output
 * at minimum (Section 0.5) — locale comes from [FrameContext.locale] and is
 * never hard-coded.
 */
interface OCRTool {

    val operationMode: OperationMode

    fun availability(): ToolAvailability

    suspend fun recognizeText(frame: FrameContext): ToolResult<OcrOutput>
}

data class OcrOutput(
    val textBlocks: List<TextBlock>
)

data class TextBlock(
    val text: String,
    val confidenceScore: Float,
    val readingOrderIndex: Int
)
