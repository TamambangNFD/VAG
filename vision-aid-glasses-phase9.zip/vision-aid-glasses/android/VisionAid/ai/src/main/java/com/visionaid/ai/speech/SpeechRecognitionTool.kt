package com.visionaid.ai.speech

import com.visionaid.ai.common.LocaleTag
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Offline speech-to-text. Does not take a camera frame — operates on raw
 * audio input.
 *
 * Input contract: raw audio bytes (opaque at this phase — Phase 11 defines
 * the actual sample format once an engine like whisper.cpp is selected) plus
 * an explicit [LocaleTag].
 * Output contract: [SpeechRecognitionOutput] with the transcribed text.
 *
 * Offline capability: OFFLINE_ONLY. Locale is always explicit — never
 * hard-coded (Section 0.5).
 */
interface SpeechRecognitionTool {

    val operationMode: OperationMode

    fun availability(): ToolAvailability

    suspend fun transcribe(
        audioData: ByteArray,
        locale: LocaleTag
    ): ToolResult<SpeechRecognitionOutput>
}

data class SpeechRecognitionOutput(
    val transcript: String,
    val locale: LocaleTag
)
