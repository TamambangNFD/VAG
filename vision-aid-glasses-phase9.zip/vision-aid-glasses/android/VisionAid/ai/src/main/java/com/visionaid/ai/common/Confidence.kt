package com.visionaid.ai.common

/**
 * Standard confidence representation used by every AI tool in the system.
 *
 * [level] is the primary signal every caller must check. [score] is an
 * optional raw numeric value (0.0f..1.0f) for tools/callers that want finer
 * granularity than the four discrete bands, but no caller may rely on
 * [score] alone — [level] is always populated and is what safety-sensitive
 * callers should branch on.
 *
 * UNKNOWN is a first-class outcome, not an error. A tool that cannot form a
 * confident judgement (bad lighting, occluded object, model uncertainty)
 * returns UNKNOWN rather than guessing — this is mandatory for the
 * safety-critical tools (see SafetyTool) but is available to every tool.
 */
data class Confidence(
    val level: ConfidenceLevel,
    val score: Float? = null
) {
    init {
        require(score == null || score in 0.0f..1.0f) {
            "Confidence score must be within 0.0..1.0 if provided, was $score"
        }
    }

    companion object {
        fun unknown() = Confidence(ConfidenceLevel.UNKNOWN)
        fun of(level: ConfidenceLevel, score: Float? = null) = Confidence(level, score)
    }
}

enum class ConfidenceLevel {
    /** The tool could not form a judgement it is willing to stand behind. */
    UNKNOWN,
    LOW,
    MEDIUM,
    HIGH
}
