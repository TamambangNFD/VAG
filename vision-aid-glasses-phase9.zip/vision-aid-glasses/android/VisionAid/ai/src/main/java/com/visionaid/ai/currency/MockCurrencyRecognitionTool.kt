package com.visionaid.ai.currency

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Deterministic mock. Always reports a 1000 XAF banknote at MEDIUM
 * confidence with sufficient image quality. Phase 10 replaces this with a
 * real trained/licensed model (see MODEL_REGISTRY.md and
 * datasets/DATASET_PROVENANCE.md requirements).
 */
class MockCurrencyRecognitionTool : CurrencyRecognitionTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun recognizeCurrency(frame: FrameContext): ToolResult<CurrencyOutput> {
        return ToolResult.Success(
            data = CurrencyOutput(
                denomination = Denomination(currency = CurrencyCode.XAF, value = 1000, isCoin = false),
                currency = CurrencyCode.XAF,
                imageQualitySufficient = true
            ),
            confidence = Confidence.of(ConfidenceLevel.MEDIUM),
            timestampMillis = frame.captureTimestampMillis
        )
    }
}
