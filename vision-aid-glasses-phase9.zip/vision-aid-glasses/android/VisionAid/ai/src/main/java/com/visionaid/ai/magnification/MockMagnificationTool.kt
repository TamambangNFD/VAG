package com.visionaid.ai.magnification

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Deterministic mock. Returns the original frame bytes unchanged, tagged
 * with the requested zoom level and always [DisplayTarget.PHONE_TEST_MODE]
 * — so Agent/UI flows can be developed against a stable contract before
 * Phase 9's real image-processing pipeline (`vision/magnification/RealMagnificationTool`)
 * is wired in.
 */
class MockMagnificationTool : MagnificationTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    private var brightnessDelta = 0f
    private var contrastDelta = 0f

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun magnify(frame: FrameContext, request: MagnificationRequest): ToolResult<MagnifiedOutput> {
        return ToolResult.Success(
            data = MagnifiedOutput(
                imageData = frame.imageData,
                appliedZoomLevel = request.zoomLevel,
                outputTarget = DisplayTarget.PHONE_TEST_MODE
            ),
            confidence = Confidence.of(ConfidenceLevel.HIGH),
            timestampMillis = frame.captureTimestampMillis,
            metadata = mapOf(
                "brightnessDelta" to brightnessDelta.toString(),
                "contrastDelta" to contrastDelta.toString(),
                "textFocusedMode" to request.textFocusedMode.toString()
            )
        )
    }

    override fun setBrightnessAdjustment(delta: Float) {
        brightnessDelta = delta.coerceIn(-1f, 1f)
    }

    override fun setContrastAdjustment(delta: Float) {
        contrastDelta = delta.coerceIn(-1f, 1f)
    }
}
