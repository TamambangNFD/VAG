package com.visionaid.ai.safety

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.depth.DistanceBand
import com.visionaid.ai.tracking.TrackedObject

/**
 * Deterministic mock. By design, ALWAYS returns UNKNOWN — a mock has no real
 * safety logic behind it, and per the roadmap's own rule ("prefer UNKNOWN
 * over false precision"), an unimplemented safety tool must never claim
 * SAFE_CANDIDATE or even CAUTION with fabricated confidence. Phases 16-17
 * replace this with the real deterministic pipeline; this mock exists only
 * to prove the Agent/Situation Engine can consume the contract.
 */
class MockSafetyTool : SafetyTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun assess(
        trackedObjects: List<TrackedObject>,
        distances: Map<String, DistanceBand>
    ): ToolResult<SafetyOutput> {
        return ToolResult.Success(
            data = SafetyOutput(
                state = SafetyState.UNKNOWN,
                reason = "Mock safety tool: no real safety pipeline implemented yet (Phases 16-17).",
                relevantObjectIds = trackedObjects.map { it.trackId }
            ),
            confidence = Confidence.unknown(),
            timestampMillis = System.currentTimeMillis()
        )
    }
}
