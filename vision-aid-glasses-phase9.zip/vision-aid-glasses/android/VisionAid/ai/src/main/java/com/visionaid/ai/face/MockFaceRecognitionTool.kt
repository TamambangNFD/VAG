package com.visionaid.ai.face

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolError
import com.visionaid.ai.common.ToolResult

/**
 * Deterministic mock. [recognize] always reports one unknown face (no
 * enrolled people exist in the mock). [enroll] "succeeds" by generating a
 * fake personId ONLY when [consentConfirmed] is true — enforcing the
 * structural consent requirement even in the mock, so any caller code
 * written against this mock is already correct once the real
 * implementation (`vision/face/RealFaceRecognitionTool`, Phase 7) replaces
 * it.
 */
class MockFaceRecognitionTool : FaceRecognitionTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    private var enabled = true
    private val enrolledPeople = mutableMapOf<String, String>() // personId -> name

    override fun availability(): ToolAvailability =
        if (enabled) ToolAvailability.AVAILABLE else ToolAvailability.DISABLED_BY_USER

    override suspend fun recognize(frame: FrameContext): ToolResult<RecognitionOutput> {
        val faces = listOf(
            RecognizedFace(
                personId = null,
                personName = null,
                boundingBoxLeft = 0.3f, boundingBoxTop = 0.2f,
                boundingBoxRight = 0.5f, boundingBoxBottom = 0.5f
            )
        )
        return ToolResult.Success(
            data = RecognitionOutput(faces = faces),
            confidence = Confidence.of(ConfidenceLevel.LOW),
            timestampMillis = frame.captureTimestampMillis
        )
    }

    override suspend fun enroll(
        frame: FrameContext,
        personName: String,
        consentConfirmed: Boolean
    ): ToolResult<EnrollmentOutput> {
        if (!consentConfirmed) {
            return ToolResult.Failure(
                ToolError.InvalidInput("Cannot enroll a face without explicit user consent"),
                timestampMillis = frame.captureTimestampMillis
            )
        }
        val personId = "mock-person-${enrolledPeople.size + 1}"
        enrolledPeople[personId] = personName
        return ToolResult.Success(
            data = EnrollmentOutput(personId = personId, personName = personName),
            confidence = Confidence.of(ConfidenceLevel.HIGH),
            timestampMillis = frame.captureTimestampMillis
        )
    }

    override suspend fun rename(personId: String, newName: String): ToolResult<Unit> {
        if (!enrolledPeople.containsKey(personId)) {
            return ToolResult.Failure(
                ToolError.InvalidInput("Unknown personId: $personId"),
                timestampMillis = System.currentTimeMillis()
            )
        }
        enrolledPeople[personId] = newName
        return ToolResult.Success(Unit, Confidence.of(ConfidenceLevel.HIGH), System.currentTimeMillis())
    }

    override suspend fun remove(personId: String): ToolResult<Unit> {
        enrolledPeople.remove(personId)
        return ToolResult.Success(Unit, Confidence.of(ConfidenceLevel.HIGH), System.currentTimeMillis())
    }

    override fun setEnabled(enabled: Boolean) {
        this.enabled = enabled
    }
}
