package com.visionaid.ai.tracking

import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.detection.DetectedObject

/**
 * Associates detections across frames into stable tracks.
 *
 * Input contract: the current frame's detections plus enough state to
 * associate them with previous frames — modeled here as a caller-supplied
 * list of this frame's [DetectedObject]s and the frame's timestamp. The
 * tool owns its own internal track history; callers do not pass previous
 * frames back in.
 * Output contract: [TrackingOutput] — one [TrackedObject] per active track,
 * each with a stable [TrackedObject.trackId] that persists across frames
 * for the same physical object.
 *
 * Offline capability: OFFLINE_ONLY.
 */
interface ObjectTrackingTool {

    val operationMode: OperationMode

    fun availability(): ToolAvailability

    /**
     * Feeds one frame's detections into the tracker and returns the updated
     * set of tracks. Must be called once per frame, in temporal order.
     */
    suspend fun update(
        detections: List<DetectedObject>,
        frameTimestampMillis: Long
    ): ToolResult<TrackingOutput>

    /** Clears all track history, e.g. on camera restart. */
    fun reset()
}

data class TrackingOutput(
    val tracks: List<TrackedObject>
)

data class TrackedObject(
    val trackId: String,
    val detectedObject: DetectedObject,
    val movement: MovementDirection,
    val framesTracked: Int
)

enum class MovementDirection {
    STATIONARY, LEFT_TO_RIGHT, RIGHT_TO_LEFT, APPROACHING, RECEDING, UNKNOWN
}
