package com.visionaid.ai.common

/**
 * Universal result envelope returned by every AI tool.
 *
 * - [Success] always carries [confidence] and [timestampMillis], even when
 *   [confidence] is UNKNOWN — a caller must never have to guess whether
 *   confidence was considered.
 * - [Failure] represents a genuine failure to execute the request at all
 *   (see [ToolError]), not a low-confidence or empty finding.
 *
 * [timestampMillis] is the capture/observation time (e.g. when the camera
 * frame was taken), not necessarily "now" — this matters for tools that
 * process buffered or delayed input.
 */
sealed class ToolResult<out T> {
    data class Success<T>(
        val data: T,
        val confidence: Confidence,
        val timestampMillis: Long,
        val metadata: Map<String, String> = emptyMap()
    ) : ToolResult<T>()

    data class Failure(
        val error: ToolError,
        val timestampMillis: Long
    ) : ToolResult<Nothing>()
}
