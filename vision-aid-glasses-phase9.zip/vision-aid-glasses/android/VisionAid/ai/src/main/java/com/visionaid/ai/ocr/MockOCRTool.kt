package com.visionaid.ai.ocr

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.LocaleTag
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Deterministic mock. Returns one canned text block, phrased differently
 * depending on [FrameContext.locale], to prove locale is actually threaded
 * through the pipeline rather than hard-coded. Phase 8 replaces this with a
 * real offline OCR engine.
 */
class MockOCRTool : OCRTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun recognizeText(frame: FrameContext): ToolResult<OcrOutput> {
        val text = when (frame.locale) {
            LocaleTag.FRENCH -> "Texte simulé reconnu à l'écran."
            LocaleTag.ENGLISH -> "Mock recognized text on screen."
        }
        return ToolResult.Success(
            data = OcrOutput(
                textBlocks = listOf(TextBlock(text = text, confidenceScore = 0.9f, readingOrderIndex = 0))
            ),
            confidence = Confidence.of(ConfidenceLevel.HIGH, 0.9f),
            timestampMillis = frame.captureTimestampMillis
        )
    }
}
