package com.visionaid.ai.navigation

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Deterministic mock. Always returns a fixed two-step route regardless of
 * input, so the Agent (Phase 13) can be developed against a stable contract
 * before Phase 15 adds real offline map/routing data.
 */
class MockNavigationTool : NavigationTool {

    override val operationMode = OperationMode.OFFLINE_WITH_ONLINE_ENHANCEMENT

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun computeRoute(
        currentLatitude: Double,
        currentLongitude: Double,
        destinationQuery: String
    ): ToolResult<RouteOutput> {
        val steps = listOf(
            RouteStep("Walk straight for 100 meters", 100.0, TurnDirection.STRAIGHT),
            RouteStep("Turn left, destination is ahead", 20.0, TurnDirection.LEFT)
        )
        return ToolResult.Success(
            data = RouteOutput(steps = steps, totalDistanceMeters = 120.0),
            confidence = Confidence.of(ConfidenceLevel.MEDIUM),
            timestampMillis = System.currentTimeMillis()
        )
    }
}
