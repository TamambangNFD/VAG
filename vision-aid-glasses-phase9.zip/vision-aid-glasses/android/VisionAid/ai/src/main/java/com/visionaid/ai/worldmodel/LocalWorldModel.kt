package com.visionaid.ai.worldmodel

import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.depth.DistanceBand
import com.visionaid.ai.tracking.MovementDirection
import com.visionaid.ai.tracking.TrackedObject

/**
 * Deterministic, in-memory [WorldModel] implementation. Pure Kotlin — no
 * Android/platform dependency — so it's fully unit-testable with synthetic
 * scenes, per the phase spec's explicit testing requirement.
 */
class LocalWorldModel(
    /** Bounding-box center-x thresholds for LEFT/CENTER/RIGHT, as fractions of frame width. */
    private val leftBoundary: Float = 0.33f,
    private val rightBoundary: Float = 0.66f
) : WorldModel {

    private var currentObjects: List<WorldObject> = emptyList()

    // Ordering used for "nearest"/"within distance" comparisons. UNKNOWN is
    // deliberately excluded from ranking entirely (handled separately, not
    // given a rank) rather than treated as "farthest" or "nearest" — an
    // unknown distance is not comparable to a known one.
    private val bandRank = mapOf(
        DistanceBand.NEAR to 0,
        DistanceBand.MEDIUM to 1,
        DistanceBand.FAR to 2
    )

    override fun update(
        trackedObjects: List<TrackedObject>,
        distances: Map<String, DistanceBand>,
        detectionConfidence: ConfidenceLevel,
        trackingConfidence: ConfidenceLevel,
        depthConfidence: ConfidenceLevel,
        timestampMillis: Long
    ) {
        currentObjects = trackedObjects.map { tracked ->
            val band = distances[tracked.trackId] ?: DistanceBand.UNKNOWN
            // Weakest-link confidence: relies on ConfidenceLevel's declared
            // ordinal ordering (UNKNOWN < LOW < MEDIUM < HIGH), so minOf
            // naturally yields the least-confident of the three inputs.
            val combinedConfidence = minOf(detectionConfidence, trackingConfidence, depthConfidence)

            WorldObject(
                trackId = tracked.trackId,
                detectedObject = tracked.detectedObject,
                distanceBand = band,
                movement = tracked.movement,
                horizontalPosition = positionOf(tracked),
                confidence = combinedConfidence,
                lastUpdatedTimestampMillis = timestampMillis,
                framesTracked = tracked.framesTracked
            )
        }
    }

    private fun positionOf(tracked: TrackedObject): HorizontalPosition {
        val box = tracked.detectedObject.boundingBox
        val centerX = (box.left + box.right) / 2f
        return when {
            centerX < leftBoundary -> HorizontalPosition.LEFT
            centerX > rightBoundary -> HorizontalPosition.RIGHT
            else -> HorizontalPosition.CENTER
        }
    }

    override fun allObjects(): List<WorldObject> = currentObjects

    override fun nearestObstacle(): WorldObject? =
        currentObjects
            .filter { it.distanceBand in bandRank.keys }
            .minByOrNull { bandRank.getValue(it.distanceBand) }

    override fun objectsInPath(): List<WorldObject> = objectsByPosition(HorizontalPosition.CENTER)

    override fun objectsByPosition(position: HorizontalPosition): List<WorldObject> =
        currentObjects.filter { it.horizontalPosition == position }

    override fun movingObjects(): List<WorldObject> =
        currentObjects.filter {
            it.movement != MovementDirection.STATIONARY && it.movement != MovementDirection.UNKNOWN
        }

    override fun objectsWithinDistance(maxBand: DistanceBand): List<WorldObject> {
        val maxRank = bandRank[maxBand] ?: return emptyList() // UNKNOWN passed as maxBand: nothing qualifies
        return currentObjects.filter { obj ->
            val rank = bandRank[obj.distanceBand] ?: return@filter false // exclude UNKNOWN objects
            rank <= maxRank
        }
    }

    override fun clear() {
        currentObjects = emptyList()
    }
}
