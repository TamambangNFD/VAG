package com.visionaid.ai.detection

import com.visionaid.ai.common.Confidence
import com.visionaid.ai.common.ConfidenceLevel
import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult

/**
 * Deterministic mock used to exercise the full data pipeline before a real
 * model exists (Phase 3 replaces this). Always reports one PERSON and one
 * POLE at fixed positions with MEDIUM confidence, so downstream consumers
 * (WorldModel, Safety, Agent) can be developed and tested against a stable
 * contract.
 */
class MockObjectDetectionTool : ObjectDetectionTool {

    override val operationMode = OperationMode.OFFLINE_ONLY

    override fun availability(): ToolAvailability = ToolAvailability.AVAILABLE

    override suspend fun detect(frame: FrameContext): ToolResult<DetectionOutput> {
        val objects = listOf(
            DetectedObject(
                objectId = "mock-person-1",
                label = ObjectLabel.PERSON,
                boundingBox = BoundingBox(0.40f, 0.20f, 0.60f, 0.90f),
                confidenceScore = 0.75f
            ),
            DetectedObject(
                objectId = "mock-pole-1",
                label = ObjectLabel.POLE,
                boundingBox = BoundingBox(0.10f, 0.30f, 0.15f, 0.95f),
                confidenceScore = 0.68f
            )
        )
        return ToolResult.Success(
            data = DetectionOutput(objects = objects, frameId = frame.frameId),
            confidence = Confidence.of(ConfidenceLevel.MEDIUM),
            timestampMillis = frame.captureTimestampMillis
        )
    }
}
