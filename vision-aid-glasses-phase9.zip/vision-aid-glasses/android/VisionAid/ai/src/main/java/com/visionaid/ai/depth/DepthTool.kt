package com.visionaid.ai.depth

import com.visionaid.ai.common.FrameContext
import com.visionaid.ai.common.OperationMode
import com.visionaid.ai.common.ToolAvailability
import com.visionaid.ai.common.ToolResult
import com.visionaid.ai.detection.DetectedObject

/**
 * SAFETY-CRITICAL (roadmap Section 0.4). Estimates distance to detected
 * objects.
 *
 * Input contract: a [FrameContext] and the [DetectedObject]s to estimate
 * distance for (obtained from ObjectDetectionTool).
 *
 * PHASE 5 INTERFACE CHANGE: this originally (Phase 2) took a plain
 * `List<String>` of object IDs. That was insufficient for any real
 * implementation — distance estimation needs each object's bounding box
 * (and label, for size-based heuristics), not just its ID. Changed here to
 * take the full [DetectedObject] list instead. This is a breaking change
 * from the Phase 2 mock signature; both `MockDepthTool` and its test were
 * updated in this same phase to match. No other phase depended on the old
 * signature yet, so no further migration was needed.
 *
 * Output contract: [DepthOutput] mapping each object's ID to a
 * [DistanceBand] — never a raw numeric distance at this phase. Precise
 * numeric distance requires calibration validated beyond Phase 5 and must
 * not be claimed as accurate before then, even where an internal estimate
 * in meters exists (see `vision` module's real implementation).
 *
 * This tool must NEVER be replaced by a general-purpose LLM/VLM as the sole
 * decision-maker, and must always prefer [DistanceBand.UNKNOWN] over a
 * confident-but-wrong estimate.
 *
 * Offline capability: OFFLINE_ONLY.
 */
interface DepthTool {

    val operationMode: OperationMode

    fun availability(): ToolAvailability

    suspend fun estimateDistance(
        frame: FrameContext,
        detectedObjects: List<DetectedObject>
    ): ToolResult<DepthOutput>
}

data class DepthOutput(
    val distances: Map<String, DistanceBand>
)

enum class DistanceBand {
    NEAR, MEDIUM, FAR,
    /** Insufficient evidence to classify. Must be preferred over guessing. */
    UNKNOWN
}
