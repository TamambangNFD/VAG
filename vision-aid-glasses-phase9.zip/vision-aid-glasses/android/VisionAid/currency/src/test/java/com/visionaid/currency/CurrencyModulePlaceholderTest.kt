package com.visionaid.currency

import org.junit.Assert.assertEquals
import org.junit.Test

class CurrencyModulePlaceholderTest {
    @Test
    fun `module name is correct`() {
        assertEquals("currency", CurrencyModulePlaceholder.MODULE_NAME)
    }
}
