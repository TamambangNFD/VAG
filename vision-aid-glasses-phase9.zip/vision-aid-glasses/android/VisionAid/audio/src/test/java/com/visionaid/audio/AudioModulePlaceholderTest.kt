package com.visionaid.audio

import org.junit.Assert.assertEquals
import org.junit.Test

class AudioModulePlaceholderTest {
    @Test
    fun `module name is correct`() {
        assertEquals("audio", AudioModulePlaceholder.MODULE_NAME)
    }
}
