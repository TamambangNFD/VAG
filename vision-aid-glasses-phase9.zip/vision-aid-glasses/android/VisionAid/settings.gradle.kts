pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "VisionAid"

include(":app")
include(":core")
include(":ai")
include(":vision")
include(":audio")
include(":navigation")
include(":safety")
include(":memory")
include(":documents")
include(":currency")
include(":glasses")
