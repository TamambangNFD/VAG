package com.visionaid.memory

import org.junit.Assert.assertEquals
import org.junit.Test

class MemoryModulePlaceholderTest {
    @Test
    fun `module name is correct`() {
        assertEquals("memory", MemoryModulePlaceholder.MODULE_NAME)
    }
}
