package com.visionaid.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.visionaid.core.logging.VisionAidLogger

/**
 * Phase 1 foundation activity.
 *
 * This screen exists only to prove the application compiles, launches, and
 * can request the runtime permissions required by later phases. It performs
 * no AI inference, no camera preview, and no glasses communication — those
 * are added in their respective phases.
 */
class MainActivity : AppCompatActivity() {

    private val requiredPermissions = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.ACCESS_FINE_LOCATION
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        VisionAidLogger.i(TAG, "Permission request result. All granted: $allGranted")
        updateStatus(allGranted)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val statusView = TextView(this).apply {
            textSize = 18f
            setPadding(48, 96, 48, 48)
        }
        setContentView(statusView)
        this.statusView = statusView

        VisionAidLogger.i(TAG, "MainActivity created.")
        requestMissingPermissions()
    }

    private fun requestMissingPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            updateStatus(true)
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun updateStatus(permissionsGranted: Boolean) {
        statusView?.text = buildString {
            append(getString(R.string.status_ready))
            append("\n\nPermissions granted: ")
            append(permissionsGranted)
            append("\nThis is the Phase 1 Android foundation only — no AI models are active yet.")
        }
    }

    private var statusView: TextView? = null

    companion object {
        private const val TAG = "MainActivity"
    }
}
