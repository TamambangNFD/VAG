package com.visionaid.app

import android.app.Application
import com.visionaid.core.config.SecretsConfig
import com.visionaid.core.logging.VisionAidLogger

/**
 * Application entry point.
 *
 * Phase 1 responsibility only: initialize cross-cutting foundation services
 * (logging, config). Does NOT initialize any AI model, camera pipeline, or
 * glasses connection — those arrive in later phases and must be wired
 * through the tool interfaces created in Phase 2 onward.
 */
class VisionAidApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        VisionAidLogger.initialize(applicationContext)
        VisionAidLogger.i(TAG, "Vision Aid Application starting (Phase 1 foundation).")

        // Confirms the secrets/config layer is wired up. No real secrets are
        // read yet — no online service exists until Phase 22 — but every
        // future phase must read credentials through this layer, never
        // hard-coded, per Section 0.3 of the roadmap.
        val offlineOnly = SecretsConfig.getBoolean(this, "VISIONAID_OFFLINE_ONLY", default = true)
        VisionAidLogger.i(TAG, "Offline-only mode: $offlineOnly")
    }

    companion object {
        private const val TAG = "VisionAidApplication"
    }
}
