package com.visionaid.core

import com.visionaid.core.settings.AppSettings
import com.visionaid.core.settings.SupportedLanguage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Phase 1 unit tests for the core module's data contracts.
 * (VisionAidLogger and SecretsConfig require an Android Context and are
 * covered by instrumented tests once the app module's test runner is
 * exercised on-device/emulator — see README.md "Testing" section.)
 */
class AppSettingsTest {

    @Test
    fun `default settings are offline-only`() {
        val settings = AppSettings()
        assertTrue(settings.offlineOnly)
    }

    @Test
    fun `default language is English`() {
        val settings = AppSettings()
        assertEquals(SupportedLanguage.ENGLISH, settings.preferredLanguage)
    }

    @Test
    fun `supported languages expose correct BCP-47 tags`() {
        assertEquals("en", SupportedLanguage.ENGLISH.bcp47Tag)
        assertEquals("fr", SupportedLanguage.FRENCH.bcp47Tag)
    }
}
