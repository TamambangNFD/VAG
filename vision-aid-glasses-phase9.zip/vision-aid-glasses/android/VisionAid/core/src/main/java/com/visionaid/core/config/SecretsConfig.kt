package com.visionaid.core.config

import android.content.Context
import com.visionaid.core.logging.VisionAidLogger

/**
 * Central config/secrets access layer, established in Phase 1 per Section 0.3
 * of the roadmap.
 *
 * RULES (apply to every future phase, not just this one):
 *  - No API key, token, or credential may ever be hard-coded in source.
 *  - Real values live in a git-ignored local source (e.g. local.properties,
 *    BuildConfig fields populated from local.properties, or an encrypted
 *    on-device store) — never committed.
 *  - `.env.example` / `local.properties.example` at the repo root document
 *    every key a later phase will need, with placeholder values only.
 *  - Phase 22 (Optional Internet Layer) is the first phase that will
 *    actually populate and read a real credential through this layer.
 *
 * This Phase 1 implementation is intentionally minimal: it reads simple
 * boolean/string flags that ship with safe defaults (e.g. offline-only mode).
 * It does NOT yet implement a full remote-secret-retrieval mechanism, since
 * no online service exists yet to secure credentials for.
 */
object SecretsConfig {

    private const val TAG = "SecretsConfig"

    fun getBoolean(context: Context, key: String, default: Boolean): Boolean {
        // Phase 1: reads from BuildConfig-style resolved flags only.
        // Later phases wire this to a real local.properties / encrypted
        // store lookup, once there is an actual secret to protect.
        VisionAidLogger.d(TAG, "Resolving config flag: $key (default=$default)")
        return default
    }

    fun getString(context: Context, key: String): String? {
        VisionAidLogger.w(
            TAG,
            "getString($key) called before any online service exists (Phase 22+). " +
                "Returning null — no credential is configured yet."
        )
        return null
    }
}
