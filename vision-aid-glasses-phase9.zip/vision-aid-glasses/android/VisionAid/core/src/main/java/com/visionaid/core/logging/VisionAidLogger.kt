package com.visionaid.core.logging

import android.content.Context
import android.util.Log

/**
 * Structured, privacy-conscious logging facade used across all modules.
 *
 * Rules this logger enforces for every future phase (per CODING_STANDARDS.md
 * and the roadmap's "log errors safely" / "avoid collecting unnecessary
 * personal data" requirements):
 *  - Never log raw camera frames, audio buffers, face embeddings, or GPS
 *    coordinates at INFO level or above.
 *  - Callers are responsible for redacting personal data before calling
 *    this logger; this class does not attempt to auto-scrub content.
 *  - No log content is transmitted off-device by this class.
 */
object VisionAidLogger {

    private const val GLOBAL_TAG_PREFIX = "VisionAid"
    private var initialized = false

    fun initialize(context: Context) {
        initialized = true
        i("Logger", "VisionAidLogger initialized.")
    }

    fun d(tag: String, message: String) = log(Log.DEBUG, tag, message)
    fun i(tag: String, message: String) = log(Log.INFO, tag, message)
    fun w(tag: String, message: String) = log(Log.WARN, tag, message)

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        if (throwable != null) {
            Log.e(scopedTag(tag), message, throwable)
        } else {
            Log.e(scopedTag(tag), message)
        }
    }

    private fun log(priority: Int, tag: String, message: String) {
        Log.println(priority, scopedTag(tag), message)
    }

    private fun scopedTag(tag: String) = "$GLOBAL_TAG_PREFIX:$tag"
}
