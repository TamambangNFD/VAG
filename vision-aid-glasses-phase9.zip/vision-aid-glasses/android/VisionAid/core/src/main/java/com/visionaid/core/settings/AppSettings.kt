package com.visionaid.core.settings

/**
 * Placeholder for application-wide user settings (speech speed, language,
 * preferred mode). Fully implemented storage/encryption arrives in Phase 21
 * (Local Memory); Phase 1 only defines the shape so later phases have a
 * stable contract to target.
 */
data class AppSettings(
    val preferredLanguage: SupportedLanguage = SupportedLanguage.ENGLISH,
    val speechRateMultiplier: Float = 1.0f,
    val offlineOnly: Boolean = true
)

/**
 * Locale is always passed as an explicit parameter across every tool
 * interface (Section 0.5 of the roadmap) — never hard-coded. This enum is
 * the shared representation every module (ASR, TTS, OCR) should use.
 */
enum class SupportedLanguage(val bcp47Tag: String) {
    ENGLISH("en"),
    FRENCH("fr")
}
