# Vision Aid Glasses — Depth Calibration & Limitations

**Phase:** 5 — Depth and Distance (**SAFETY-CRITICAL** — Section 0.4 of the roadmap)

This document exists because the roadmap's Phase 5 spec explicitly requires
documenting "calibration requirements, accuracy limitations and failure
conditions" before this subsystem is used for anything beyond development
testing.

## Current State: No Real Hardware, No Real Calibration

The target glasses hardware is still **TBD** (see `PRODUCT_SPEC.md` Section
9). This means:

- We do not know if the eventual hardware has two synchronized cameras
  (enabling real stereo depth) or only one.
- No real camera calibration (focal length, lens distortion, stereo
  baseline) has been performed on any actual device.
- **Every distance figure this code can currently produce is a heuristic
  estimate, not a measurement**, and is capped at `ConfidenceLevel.LOW` for
  exactly this reason — see `RealDepthTool`.

## Two Estimation Paths, Neither Fully Implemented Yet

### Stereo (planned, not built)
`CameraHardwareProfile.depthCapability == STEREO_CALIBRATED` is the trigger
for a real stereo block-matching pipeline. **This phase does not implement
stereo matching** — there is no real stereo hardware or calibration data to
build or validate it against yet. If this capability is ever declared before
real stereo matching exists, `RealDepthTool` deliberately falls back to
`UNKNOWN` for every object rather than fabricating an unvalidated pipeline.
Building real stereo matching is future work, gated on glasses hardware
selection (Phase 19).

### Monocular size-based heuristic (implemented, unvalidated)
`MonocularSizeBasedDepthEstimator` uses the classic pinhole-camera "known
object size" technique:

```
distance_m ≈ (reference_real_world_height_m × normalizedFocalLength) / bbox_height_normalized
```

**Calibration requirement:** `normalizedFocalLength` must come from an
actual calibration procedure (e.g. checkerboard calibration) performed on
the real target camera, expressed as (focal length in pixels ÷ image height
in pixels) so it's resolution-independent. **It must never be guessed,
hard-coded from a spec sheet, or estimated from marketing material.** No
such calibration has been performed — there is no real device yet.

## Accuracy Limitations (read before trusting any output)

1. **No real calibration exists yet.** Every number this code could produce
   today is illustrative only, from a placeholder `normalizedFocalLength`
   supplied by a test or a future integration — not a validated device
   value.
2. **Reference object sizes are population averages, not measurements.** A
   `PERSON` is assumed 1.7m tall; a real person could be a child, unusually
   tall or short, etc. This is an inherent, irreducible error source of
   single-frame monocular size-based estimation — no calibration fixes it.
   This is why several classes (`CAR`, `VEHICLE`, `BAG`, `BOTTLE`, `OTHER`)
   have **no** reference height at all: their real-world size varies too
   much for any single average to be meaningful, so they always report
   `UNKNOWN` rather than a misleading guess.
3. **Confidence is capped at LOW, permanently, for the monocular path**,
   even for a "clean-looking" estimate — this reflects the technique's
   unvalidated status, not a per-estimate judgment. This cap should only be
   raised after real-world field validation (roadmap Phase 29 and the
   formal Phase 31 Safety Validation), never as a code-review-only change.
4. **Boundary ambiguity is deliberately widened to UNKNOWN.** Any estimate
   within ±15% of the NEAR/MEDIUM or MEDIUM/FAR boundary (1.5m and 4.0m
   respectively) is reported as `UNKNOWN` rather than committed to either
   side. This trades away some "helpfulness" (fewer confident answers) for
   safety (fewer wrong answers right at the threshold that matters most).

## Failure Conditions — Always UNKNOWN, Never a Guess

| Condition | Result |
|---|---|
| No calibration configured on the device | `UNKNOWN` for every object |
| Object's label has no reference height (e.g. `CAR`, `BAG`) | `UNKNOWN` |
| Bounding box height < `minReliableBoxHeight` (default 2% of frame height) | `UNKNOWN` — box too small/noisy to trust |
| Bounding box height > `maxReliableBoxHeight` (default 95%) | `UNKNOWN` — likely clipped by frame edge or object very close |
| Estimated distance within the boundary margin of NEAR/MEDIUM or MEDIUM/FAR | `UNKNOWN` — ambiguous, not guessed |
| Stereo capability declared but stereo matching not implemented | `UNKNOWN` for every object, loudly logged |

## What Must Happen Before This Subsystem Is Trusted for Real Use

1. Glasses hardware selected (Phase 19) and its actual camera
   configuration (mono vs. stereo) confirmed via SDK inspection, not
   assumption.
2. Real calibration performed against that hardware.
3. Field testing (Phase 29) comparing estimated bands against ground-truth
   measured distances, across a range of real objects and conditions.
4. Formal safety validation (Phase 31) — **explicit human sign-off is
   required before this or any safety-critical phase can be marked complete
   in `VERIFICATION.md`, per Section 0.4 and Section 40 of the roadmap. This
   is not something a coding AI can self-certify, however well-tested the
   code looks.**

Until all of the above happens, treat every output of this subsystem as a
rough, low-confidence signal suitable for further development and testing
only — not as a safety guarantee.
